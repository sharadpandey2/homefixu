import {
  IsEmail,
  IsString,
  IsNotEmpty,
  MinLength,
  Matches,
  IsIn,
  Length,
} from 'class-validator';
import { Transform } from 'class-transformer';

const TECHNICIAN_DOMAINS = [
  'plumbing',
  'electrical',
  'pest_control',
  'hvac',
  'structural',
  'painting',
  'waterproofing',
  'appliance',
] as const;

const EXPERIENCE_RANGES = ['0-1', '1-3', '3-5', '5-10', '10+'] as const;

export type TechnicianDomain = (typeof TECHNICIAN_DOMAINS)[number];
export type ExperienceRange = (typeof EXPERIENCE_RANGES)[number];

export class TechnicianSignupDto {
  // ─── Auth credentials ───
  @IsString()
  @IsNotEmpty()
  @MinLength(2, { message: 'Name must be at least 2 characters' })
  name!: string;

  @IsEmail({}, { message: 'Invalid email format' })
  @Transform(({ value }) => String(value).toLowerCase().trim())
  email!: string;

  @IsString()
  @MinLength(8, { message: 'Password must be at least 8 characters' })
  password!: string;

  // ─── Technician profile ───
  @IsString()
  @Matches(/^\+?\d[\d\s-]{8,14}$/, { message: 'Invalid phone number' })
  phone!: string;

  @IsString()
  @IsIn(TECHNICIAN_DOMAINS, {
    message: `Domain must be one of: ${TECHNICIAN_DOMAINS.join(', ')}`,
  })
  domain!: TechnicianDomain;

  @IsString()
  @IsIn(EXPERIENCE_RANGES, {
    message: `Experience must be one of: ${EXPERIENCE_RANGES.join(', ')}`,
  })
  experienceYears!: ExperienceRange;

  @IsString()
  @IsNotEmpty()
  city!: string;

  @IsString()
  @Length(6, 6, { message: 'Pincode must be exactly 6 digits' })
  @Matches(/^\d{6}$/, { message: 'Pincode must contain only digits' })
  pincode!: string;
}

export interface TechnicianSignupResponse {
  message: string;
  userId: string;
  technicianId: string;
  role: 'technician';
  nextSteps: string[];
}