import {
  Injectable,
  ConflictException,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
  InternalServerErrorException,
  Logger,
} from '@nestjs/common';
import { eq, and, sql } from 'drizzle-orm';
import { randomBytes } from 'crypto';

import { db } from '@homebuddy-12/db';
import {
  technicians,
  technicianKyc,
  technicianAvailability,
  bookings,
  inspectionReports,
  services,
  properties,
  serviceDues,
} from '@homebuddy-12/db/schema';

import {
  RegisterTechnicianDto,
  UpdateTechnicianProfileDto,
  SubmitKycDto,
  UpdateAvailabilityDto,
  RejectBookingDto,
  CompleteBookingDto,
  CreateInspectionDto,
  KycStatus,
} from './dto/technician.dto';

import type {
  TechnicianProfileResponse,
  KycStatusResponse,
  RegisterTechnicianResponse,
  SubmitKycResponse,
  AvailabilityResponse,
  TechnicianBookingResponse,
  InspectionResponse,
} from './dto/technician.dto';

// ═══════════════════════════════════════════════════════════════════════════════
// UTILITIES
// ═══════════════════════════════════════════════════════════════════════════════

const generateId = (prefix: string): string =>
  `${prefix}_${randomBytes(8).toString('hex')}`;

const normalizePhone = (phone: string): string =>
  phone.replace(/\D/g, '').slice(-10);

const isValidKycStatus = (status: string): status is KycStatus => {
  return ['not_submitted', 'under_review', 'verified', 'rejected'].includes(status);
};

const TECH_TRANSITION_FROM: Record<string, string> = {
  accept: 'pending',
  reject: 'pending',
  start: 'confirmed',
  complete: 'in_progress',
};

@Injectable()
export class TechnicianService {
  private readonly logger = new Logger(TechnicianService.name);

  // ═══════════════════════════════════════════════════════════════════════════════
  // HELPER METHODS
  // ═══════════════════════════════════════════════════════════════════════════════

  private async findTechnicianByUser(userId: string) {
    const technician = await db.query.technicians.findFirst({
      where: eq(technicians.userId, userId),
    });
    if (!technician) {
      throw new NotFoundException('Technician profile not found. Please register first');
    }
    return technician;
  }

  private async findAssignedBooking(technicianId: string, bookingId: string) {
    const booking = await db.query.bookings.findFirst({
      where: and(
        eq(bookings.id, bookingId),
        eq(bookings.assignedTechnicianId, technicianId),
      ),
    });
    if (!booking) {
      throw new NotFoundException('Booking not found or not assigned to you');
    }
    return booking;
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 1. REGISTER
  // ═══════════════════════════════════════════════════════════════════════════════
  async registerTechnician(
    userId: string,
    dto: RegisterTechnicianDto,
  ): Promise<RegisterTechnicianResponse> {
    const normalizedPhone = normalizePhone(dto.phone);

    const existingTechnician = await db.query.technicians.findFirst({
      where: eq(technicians.userId, userId),
    });
    if (existingTechnician) {
      throw new ConflictException('You have already registered as a technician');
    }

    const duplicatePhone = await db.query.technicians.findFirst({
      where: eq(technicians.phone, normalizedPhone),
    });
    if (duplicatePhone) {
      throw new ConflictException('This phone number is already registered');
    }

    const duplicateEmail = await db.query.technicians.findFirst({
      where: eq(technicians.email, dto.email),
    });
    if (duplicateEmail) {
      throw new ConflictException('This email is already registered');
    }

    const result = await db.transaction(async (tx) => {
      const technicianId = generateId('tech');

      const [newTechnician] = await tx
        .insert(technicians)
        .values({
          id: technicianId,
          userId,
          name: dto.name,
          phone: normalizedPhone,
          email: dto.email,
          domain: dto.domain,
          experienceYears: dto.experienceYears,
          city: dto.city,
          pincode: dto.pincode,
          isActive: false,
          isVerified: false,
        })
        .returning();

      if (!newTechnician) {
        throw new InternalServerErrorException('Failed to create technician record');
      }

      await tx.insert(technicianKyc).values({
        id: generateId('kyc'),
        technicianId: newTechnician.id,
        fullName: dto.name,
        status: 'not_submitted',
      });

      await tx.insert(technicianAvailability).values({
        id: generateId('avail'),
        technicianId: newTechnician.id,
        workMonday: true,
        workTuesday: true,
        workWednesday: true,
        workThursday: true,
        workFriday: true,
        workSaturday: true,
        workSunday: false,
        startTime: '09:00',
        endTime: '18:00',
      });

      return newTechnician;
    });

    this.logger.log(`Technician registered: ${result.id} (userId: ${userId})`);

    return {
      message: 'Registration successful! Please complete KYC verification to activate your account.',
      technician: this.mapToProfileResponse(result),
      nextSteps: [
        'Complete KYC verification by submitting required documents',
        'Wait for admin review (typically 24-48 hours)',
        'Once verified, you will receive an Employee ID',
        'Set your availability and start accepting bookings',
      ],
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 2. GET PROFILE
  // ═══════════════════════════════════════════════════════════════════════════════
  async getProfile(userId: string): Promise<TechnicianProfileResponse> {
    const technician = await this.findTechnicianByUser(userId);
    return this.mapToProfileResponse(technician);
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 3. UPDATE PROFILE
  // ═══════════════════════════════════════════════════════════════════════════════
  async updateProfile(
    userId: string,
    dto: UpdateTechnicianProfileDto,
  ): Promise<TechnicianProfileResponse> {
    const technician = await this.findTechnicianByUser(userId);

    const normalizedPhone = dto.phone ? normalizePhone(dto.phone) : undefined;

    if (normalizedPhone && normalizedPhone !== technician.phone) {
      const duplicatePhone = await db.query.technicians.findFirst({
        where: eq(technicians.phone, normalizedPhone),
      });
      if (duplicatePhone && duplicatePhone.id !== technician.id) {
        throw new ConflictException('This phone number is already in use');
      }
    }

    const updateData: Record<string, any> = { updatedAt: new Date() };
    if (dto.name !== undefined) updateData.name = dto.name;
    if (dto.domain !== undefined) updateData.domain = dto.domain;
    if (dto.experienceYears !== undefined) updateData.experienceYears = dto.experienceYears;
    if (dto.city !== undefined) updateData.city = dto.city;
    if (dto.pincode !== undefined) updateData.pincode = dto.pincode;
    if (normalizedPhone !== undefined) updateData.phone = normalizedPhone;

    const [updatedTechnician] = await db
      .update(technicians)
      .set(updateData)
      .where(eq(technicians.id, technician.id))
      .returning();

    if (!updatedTechnician) {
      throw new InternalServerErrorException('Failed to update technician record');
    }

    this.logger.log(`Technician profile updated: ${updatedTechnician.id}`);
    return this.mapToProfileResponse(updatedTechnician);
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 4. SUBMIT KYC
  // ═══════════════════════════════════════════════════════════════════════════════
  async submitKyc(userId: string, dto: SubmitKycDto): Promise<SubmitKycResponse> {
    const technician = await this.findTechnicianByUser(userId);

    const existingKyc = await db.query.technicianKyc.findFirst({
      where: eq(technicianKyc.technicianId, technician.id),
    });
    if (!existingKyc) throw new NotFoundException('KYC record not found');

    if (existingKyc.status === 'verified') {
      throw new BadRequestException('KYC is already verified. No changes allowed');
    }
    if (existingKyc.status === 'under_review') {
      throw new BadRequestException('KYC is currently under review. Please wait for admin verification');
    }

    const [updatedKyc] = await db
      .update(technicianKyc)
      .set({
        fullName: dto.fullName,
        fatherName: dto.fatherName,
        dateOfBirth: dto.dateOfBirth,
        address: dto.address,
        aadhaarNumber: dto.aadhaarNumber,
        aadhaarFrontUrl: dto.aadhaarFrontUrl,
        aadhaarBackUrl: dto.aadhaarBackUrl,
        panNumber: dto.panNumber,
        panCardUrl: dto.panCardUrl,
        photoUrl: dto.photoUrl,
        addressProofUrl: dto.addressProofUrl,
        policeClearanceUrl: dto.policeClearanceUrl,
        status: 'under_review',
        updatedAt: new Date(),
      })
      .where(eq(technicianKyc.id, existingKyc.id))
      .returning();

    if (!updatedKyc) throw new InternalServerErrorException('Failed to update KYC record');

    this.logger.log(`[KYC SUBMISSION] Technician: ${technician.id}`);

    return {
      message: 'KYC documents submitted successfully! Your profile is now under review.',
      kycStatus: this.mapToKycStatusResponse(technician.id, updatedKyc),
      estimatedReviewTime: '24-48 hours',
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 5. GET KYC STATUS
  // ═══════════════════════════════════════════════════════════════════════════════
  async getKycStatus(userId: string): Promise<KycStatusResponse> {
    const technician = await this.findTechnicianByUser(userId);

    const kyc = await db.query.technicianKyc.findFirst({
      where: eq(technicianKyc.technicianId, technician.id),
    });
    if (!kyc) throw new NotFoundException('KYC record not found');

    return this.mapToKycStatusResponse(technician.id, kyc);
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 6. GET AVAILABILITY
  // ═══════════════════════════════════════════════════════════════════════════════
  async getAvailability(userId: string): Promise<AvailabilityResponse> {
    const technician = await this.findTechnicianByUser(userId);

    const availability = await db.query.technicianAvailability.findFirst({
      where: eq(technicianAvailability.technicianId, technician.id),
    });

    if (!availability) {
      throw new NotFoundException('Availability record not found');
    }

    return {
      technicianId: technician.id,
      workMonday: availability.workMonday,
      workTuesday: availability.workTuesday,
      workWednesday: availability.workWednesday,
      workThursday: availability.workThursday,
      workFriday: availability.workFriday,
      workSaturday: availability.workSaturday,
      workSunday: availability.workSunday,
      startTime: availability.startTime,
      endTime: availability.endTime,
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 7. UPDATE AVAILABILITY
  // ═══════════════════════════════════════════════════════════════════════════════
  async updateAvailability(
    userId: string,
    dto: UpdateAvailabilityDto,
  ): Promise<AvailabilityResponse> {
    const technician = await this.findTechnicianByUser(userId);

    const availability = await db.query.technicianAvailability.findFirst({
      where: eq(technicianAvailability.technicianId, technician.id),
    });
    if (!availability) {
      throw new NotFoundException('Availability record not found');
    }

    if (dto.startTime && dto.endTime && dto.startTime >= dto.endTime) {
      throw new BadRequestException('Start time must be before end time');
    }

    const updateData: Record<string, any> = { updatedAt: new Date() };
    if (dto.workMonday !== undefined) updateData.workMonday = dto.workMonday;
    if (dto.workTuesday !== undefined) updateData.workTuesday = dto.workTuesday;
    if (dto.workWednesday !== undefined) updateData.workWednesday = dto.workWednesday;
    if (dto.workThursday !== undefined) updateData.workThursday = dto.workThursday;
    if (dto.workFriday !== undefined) updateData.workFriday = dto.workFriday;
    if (dto.workSaturday !== undefined) updateData.workSaturday = dto.workSaturday;
    if (dto.workSunday !== undefined) updateData.workSunday = dto.workSunday;
    if (dto.startTime !== undefined) updateData.startTime = dto.startTime;
    if (dto.endTime !== undefined) updateData.endTime = dto.endTime;

    const [updated] = await db
      .update(technicianAvailability)
      .set(updateData)
      .where(eq(technicianAvailability.technicianId, technician.id))
      .returning();

    if (!updated) throw new InternalServerErrorException('Failed to update availability');

    this.logger.log(`Availability updated: technician ${technician.id}`);

    return {
      technicianId: technician.id,
      workMonday: updated.workMonday,
      workTuesday: updated.workTuesday,
      workWednesday: updated.workWednesday,
      workThursday: updated.workThursday,
      workFriday: updated.workFriday,
      workSaturday: updated.workSaturday,
      workSunday: updated.workSunday,
      startTime: updated.startTime,
      endTime: updated.endTime,
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 8. GET SCHEDULE
  // ═══════════════════════════════════════════════════════════════════════════════
  async getSchedule(
    userId: string,
    status?: string,
    date?: string,
  ): Promise<TechnicianBookingResponse[]> {
    const technician = await this.findTechnicianByUser(userId);

    const conditions: any[] = [eq(bookings.assignedTechnicianId, technician.id)];

    if (status) {
      conditions.push(eq(bookings.status, status as any));
    }

    if (date) {
      conditions.push(
        sql`DATE(${bookings.scheduledDate}) = ${date}::date`,
      );
    }

    const results = await db.query.bookings.findMany({
      where: and(...conditions),
      orderBy: (b, { asc: a }) => [a(b.scheduledDate)],
    });

    const formatted: TechnicianBookingResponse[] = [];

    for (const booking of results) {
      const service = await db.query.services.findFirst({
        where: eq(services.id, booking.serviceId),
      });
      const property = await db.query.properties.findFirst({
        where: eq(properties.id, booking.propertyId),
      });

      formatted.push({
        id: booking.id,
        status: booking.status,
        scheduledDate: booking.scheduledDate,
        scheduledSlot: booking.scheduledSlot,
        totalPricePaise: booking.totalPricePaise,
        notes: booking.notes,
        providerNotes: booking.providerNotes,
        completedAt: booking.completedAt,
        customer: {
          userId: booking.userId,
        },
        service: service
          ? {
              id: service.id,
              name: service.name,
              category: service.category,
              durationMinutes: service.durationMinutes,
            }
          : null,
        property: property
          ? {
              id: property.id,
              name: property.name,
              addressLine1: property.addressLine1,
              city: property.city,
              pincode: property.pincode,
            }
          : null,
      });
    }

    return formatted;
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 9. ACCEPT BOOKING
  // ═══════════════════════════════════════════════════════════════════════════════
  async acceptBooking(userId: string, bookingId: string) {
    const technician = await this.findTechnicianByUser(userId);

    if (!technician.isVerified) {
      throw new ForbiddenException('Your KYC is not verified yet. Cannot accept bookings');
    }

    const booking = await this.findAssignedBooking(technician.id, bookingId);

    if (booking.status !== TECH_TRANSITION_FROM.accept) {
      throw new BadRequestException(
        `Cannot accept a booking with status '${booking.status}'. Only pending bookings can be accepted`,
      );
    }

    const [updated] = await db
      .update(bookings)
      .set({ status: 'confirmed', updatedAt: new Date() })
      .where(eq(bookings.id, bookingId))
      .returning();

    if (!updated) throw new InternalServerErrorException('Failed to accept booking');

    this.logger.log(`Booking ${bookingId} accepted by technician ${technician.id}`);

    return {
      id: updated.id,
      status: updated.status,
      message: 'Booking accepted successfully',
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 10. REJECT BOOKING
  // ═══════════════════════════════════════════════════════════════════════════════
  async rejectBooking(userId: string, bookingId: string, dto: RejectBookingDto) {
    const technician = await this.findTechnicianByUser(userId);
    const booking = await this.findAssignedBooking(technician.id, bookingId);

    if (booking.status !== TECH_TRANSITION_FROM.reject) {
      throw new BadRequestException(
        `Cannot reject a booking with status '${booking.status}'. Only pending bookings can be rejected`,
      );
    }

    const providerNotes = `Rejected by technician: ${dto.reason}`;

    const [updated] = await db
      .update(bookings)
      .set({
        assignedTechnicianId: null,
        technicianName: null,
        technicianPhone: null,
        providerNotes,
        status: 'pending',
        updatedAt: new Date(),
      })
      .where(eq(bookings.id, bookingId))
      .returning();

    if (!updated) throw new InternalServerErrorException('Failed to reject booking');

    this.logger.log(`Booking ${bookingId} rejected by technician ${technician.id}: ${dto.reason}`);

    return {
      id: updated.id,
      status: updated.status,
      message: 'Booking rejected. It will be reassigned to another technician',
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 11. START SERVICE
  // ═══════════════════════════════════════════════════════════════════════════════
  async startService(userId: string, bookingId: string) {
    const technician = await this.findTechnicianByUser(userId);
    const booking = await this.findAssignedBooking(technician.id, bookingId);

    if (booking.status !== TECH_TRANSITION_FROM.start) {
      throw new BadRequestException(
        `Cannot start a booking with status '${booking.status}'. Only confirmed bookings can be started`,
      );
    }

    const [updated] = await db
      .update(bookings)
      .set({ status: 'in_progress', updatedAt: new Date() })
      .where(eq(bookings.id, bookingId))
      .returning();

    if (!updated) throw new InternalServerErrorException('Failed to start service');

    this.logger.log(`Booking ${bookingId} started by technician ${technician.id}`);

    return {
      id: updated.id,
      status: updated.status,
      message: 'Service started',
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 12. COMPLETE SERVICE
  // ═══════════════════════════════════════════════════════════════════════════════
  async completeService(userId: string, bookingId: string, dto: CompleteBookingDto) {
    const technician = await this.findTechnicianByUser(userId);
    const booking = await this.findAssignedBooking(technician.id, bookingId);

    if (booking.status !== TECH_TRANSITION_FROM.complete) {
      throw new BadRequestException(
        `Cannot complete a booking with status '${booking.status}'. Only in-progress bookings can be completed`,
      );
    }

    const now = new Date();

    const updateData: Record<string, any> = {
      status: 'completed',
      completedAt: now,
      updatedAt: now,
    };
    if (dto.providerNotes !== undefined) updateData.providerNotes = dto.providerNotes;
    if (dto.materialCostPaise !== undefined) updateData.materialCostPaise = dto.materialCostPaise;

    const [updated] = await db
      .update(bookings)
      .set(updateData)
      .where(eq(bookings.id, bookingId))
      .returning();

    if (!updated) throw new InternalServerErrorException('Failed to complete service');

    await this.updateServiceDueOnCompletion(
      booking.userId,
      booking.propertyId,
      booking.serviceId,
      now,
    );

    this.logger.log(`Booking ${bookingId} completed by technician ${technician.id}`);

    return {
      id: updated.id,
      status: updated.status,
      completedAt: updated.completedAt,
      message: 'Service completed successfully',
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 13. CREATE INSPECTION REPORT
  // ═══════════════════════════════════════════════════════════════════════════════
  async createInspection(
    userId: string,
    dto: CreateInspectionDto,
  ): Promise<InspectionResponse> {
    const technician = await this.findTechnicianByUser(userId);

    const booking = await this.findAssignedBooking(technician.id, dto.bookingId);

    if (booking.status !== 'completed') {
      throw new BadRequestException('Inspection can only be created for completed bookings');
    }

    const existingInspection = await db.query.inspectionReports.findFirst({
      where: eq(inspectionReports.bookingId, dto.bookingId),
    });
    if (existingInspection) {
      throw new ConflictException('Inspection report already exists for this booking');
    }

    const inspectionId = generateId('insp');

    const [inspection] = await db
      .insert(inspectionReports)
      .values({
        id: inspectionId,
        bookingId: dto.bookingId,
        propertyId: booking.propertyId,
        technicianId: technician.id,
        inspectedBy: technician.name,
        inspectionDate: new Date(),

        plumbingScore: dto.plumbingScore ?? null,
        electricalScore: dto.electricalScore ?? null,
        structuralScore: dto.structuralScore ?? null,
        pestControlScore: dto.pestControlScore ?? null,
        paintSealantScore: dto.paintSealantScore ?? null,
        overallScore: dto.overallScore,

        plumbingIssues: dto.plumbingIssues ?? null,
        electricalIssues: dto.electricalIssues ?? null,
        structuralIssues: dto.structuralIssues ?? null,
        pestIssues: dto.pestIssues ?? null,
        paintIssues: dto.paintIssues ?? null,

        overallCondition: dto.overallCondition,
        photos: dto.photos ?? [],
        remarks: dto.remarks ?? null,
        technicianNotes: dto.technicianNotes ?? null,
        isAdminOnly: true,
      })
      .returning();

    if (!inspection) {
      throw new InternalServerErrorException('Failed to create inspection report');
    }

    this.logger.log(
      `Inspection ${inspectionId} created for booking ${dto.bookingId} by technician ${technician.id}`,
    );

    return this.mapToInspectionResponse(inspection);
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 14. LIST MY INSPECTIONS
  // ═══════════════════════════════════════════════════════════════════════════════
  async listInspections(userId: string): Promise<InspectionResponse[]> {
    const technician = await this.findTechnicianByUser(userId);

    const results = await db.query.inspectionReports.findMany({
      where: eq(inspectionReports.technicianId, technician.id),
      orderBy: (r, { desc: d }) => [d(r.createdAt)],
    });

    return results.map((r) => this.mapToInspectionResponse(r));
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 15. GET SINGLE INSPECTION
  // ═══════════════════════════════════════════════════════════════════════════════
  async getInspection(userId: string, inspectionId: string): Promise<InspectionResponse> {
    const technician = await this.findTechnicianByUser(userId);

    const inspection = await db.query.inspectionReports.findFirst({
      where: and(
        eq(inspectionReports.id, inspectionId),
        eq(inspectionReports.technicianId, technician.id),
      ),
    });

    if (!inspection) {
      throw new NotFoundException('Inspection report not found');
    }

    return this.mapToInspectionResponse(inspection);
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 16. GET SERVICE REQUEST DETAIL
  // ═══════════════════════════════════════════════════════════════════════════════
  async getServiceRequest(userId: string, bookingId: string): Promise<TechnicianBookingResponse> {
    const technician = await this.findTechnicianByUser(userId);
    const booking = await this.findAssignedBooking(technician.id, bookingId);

    const service = await db.query.services.findFirst({
      where: eq(services.id, booking.serviceId),
    });
    const property = await db.query.properties.findFirst({
      where: eq(properties.id, booking.propertyId),
    });

    return {
      id: booking.id,
      status: booking.status,
      scheduledDate: booking.scheduledDate,
      scheduledSlot: booking.scheduledSlot,
      totalPricePaise: booking.totalPricePaise,
      notes: booking.notes,
      providerNotes: booking.providerNotes,
      completedAt: booking.completedAt,
      customer: {
        userId: booking.userId,
      },
      service: service
        ? {
            id: service.id,
            name: service.name,
            category: service.category,
            durationMinutes: service.durationMinutes,
          }
        : null,
      property: property
        ? {
            id: property.id,
            name: property.name,
            addressLine1: property.addressLine1,
            city: property.city,
            pincode: property.pincode,
          }
        : null,
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // 17. TECHNICIAN DASHBOARD
  // ═══════════════════════════════════════════════════════════════════════════════
  async getDashboard(userId: string) {
    const technician = await this.findTechnicianByUser(userId);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const [
      todayBookings,
      pendingBookings,
      completedThisMonth,
      totalInspections,
      kycRecord,
    ] = await Promise.all([
      db.query.bookings.findMany({
        where: and(
          eq(bookings.assignedTechnicianId, technician.id),
          sql`DATE(${bookings.scheduledDate}) = ${today.toISOString().split('T')[0]}::date`,
        ),
      }),
      db.query.bookings.findMany({
        where: and(
          eq(bookings.assignedTechnicianId, technician.id),
          eq(bookings.status, 'pending' as any),
        ),
      }),
      db.execute(
        sql`SELECT COUNT(*) as count FROM bookings 
         WHERE assigned_technician_id = ${technician.id} 
         AND status = 'completed'
         AND DATE_TRUNC('month', completed_at) = DATE_TRUNC('month', NOW())`
      ),
      db.execute(
        sql`SELECT COUNT(*) as count FROM inspection_reports WHERE technician_id = ${technician.id}`
      ),
      db.query.technicianKyc.findFirst({
        where: eq(technicianKyc.technicianId, technician.id),
      }),
    ]);

    return {
      technician: {
        id: technician.id,
        name: technician.name,
        domain: technician.domain,
        isActive: technician.isActive,
        isVerified: technician.isVerified,
        employeeId: technician.employeeId,
      },
      kycStatus: kycRecord?.status ?? 'not_submitted',
      stats: {
        todayBookings: todayBookings.length,
        pendingRequests: pendingBookings.length,
        completedThisMonth: Number((completedThisMonth as any)[0]?.count ?? 0),
        totalInspections: Number((totalInspections as any)[0]?.count ?? 0),
      },
      todaySchedule: todayBookings.map((b) => ({
        id: b.id,
        status: b.status,
        scheduledSlot: b.scheduledSlot,
        notes: b.notes,
      })),
      pendingRequests: pendingBookings.map((b) => ({
        id: b.id,
        scheduledDate: b.scheduledDate,
        scheduledSlot: b.scheduledSlot,
        notes: b.notes,
      })),
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // PRIVATE MAPPER HELPERS (These must stay inside the class!)
  // ═══════════════════════════════════════════════════════════════════════════════

  private async updateServiceDueOnCompletion(
    userId: string,
    propertyId: string,
    serviceId: string,
    completedAt: Date,
  ) {
    const service = await db.query.services.findFirst({
      where: eq(services.id, serviceId),
    });
    if (!service) return;

    const nextDue = new Date(completedAt);
    switch (service.frequency) {
      case 'monthly':
        nextDue.setMonth(nextDue.getMonth() + 1);
        break;
      case 'quarterly':
        nextDue.setMonth(nextDue.getMonth() + 3);
        break;
      case 'biannual':
        nextDue.setMonth(nextDue.getMonth() + 6);
        break;
      case 'annual':
        nextDue.setFullYear(nextDue.getFullYear() + 1);
        break;
      default:
        return;
    }

    const existing = await db.query.serviceDues.findFirst({
      where: and(
        eq(serviceDues.userId, userId),
        eq(serviceDues.propertyId, propertyId),
        eq(serviceDues.serviceId, serviceId),
      ),
    });

    if (existing) {
      await db
        .update(serviceDues)
        .set({
          lastServiceDate: completedAt,
          nextDueDate: nextDue,
          isOverdue: false,
          updatedAt: new Date(),
        })
        .where(eq(serviceDues.id, existing.id));
    } else {
      await db.insert(serviceDues).values({
        id: generateId('sdue'),
        userId,
        propertyId,
        serviceId,
        lastServiceDate: completedAt,
        nextDueDate: nextDue,
        isOverdue: false,
      });
    }
  }

  private mapToProfileResponse(technician: any): TechnicianProfileResponse {
    return {
      id: technician.id,
      userId: technician.userId,
      name: technician.name,
      phone: technician.phone,
      email: technician.email,
      domain: technician.domain,
      experienceYears: technician.experienceYears,
      city: technician.city,
      pincode: technician.pincode,
      employeeId: technician.employeeId,
      isActive: technician.isActive,
      isVerified: technician.isVerified,
      createdAt: technician.createdAt,
      updatedAt: technician.updatedAt,
    };
  }

  private mapToKycStatusResponse(technicianId: string, kyc: any): KycStatusResponse {
    if (!isValidKycStatus(kyc.status)) {
      this.logger.error(`Invalid KYC status: ${kyc.status} for technician ${technicianId}`);
      throw new InternalServerErrorException('Invalid KYC status in database');
    }

    return {
      technicianId,
      status: kyc.status,
      isAadhaarVerified: kyc.isAadhaarVerified,
      isPanVerified: kyc.isPanVerified,
      isPoliceVerified: kyc.isPoliceVerified,
      submittedAt: kyc.status !== 'not_submitted' ? kyc.updatedAt : null,
      reviewedAt: kyc.reviewedAt,
      reviewedBy: kyc.reviewedBy,
      rejectionReason: kyc.rejectionReason,
    };
  }

  private mapToInspectionResponse(inspection: any): InspectionResponse {
    return {
      id: inspection.id,
      bookingId: inspection.bookingId,
      propertyId: inspection.propertyId,
      technicianId: inspection.technicianId,
      inspectedBy: inspection.inspectedBy,
      inspectionDate: inspection.inspectionDate,
      plumbingScore: inspection.plumbingScore,
      electricalScore: inspection.electricalScore,
      structuralScore: inspection.structuralScore,
      pestControlScore: inspection.pestControlScore,
      paintSealantScore: inspection.paintSealantScore,
      overallScore: inspection.overallScore,
      overallCondition: inspection.overallCondition,
      photos: inspection.photos ?? [],
      remarks: inspection.remarks,
      technicianNotes: inspection.technicianNotes,
      createdAt: inspection.createdAt,
    };
  }
} // <--- This final bracket closes the entire TechnicianService class!