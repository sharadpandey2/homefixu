import {
  Injectable,
  ConflictException,
  BadRequestException,
  InternalServerErrorException,
  Logger,
} from '@nestjs/common';
import { eq } from 'drizzle-orm';
import { randomBytes } from 'crypto';

import { db } from '@homebuddy-12/db';
import {
  users,
  technicians,
  technicianKyc,
  technicianAvailability,
} from '@homebuddy-12/db/schema';
import { auth } from '@homebuddy-12/auth';

import type {
  TechnicianSignupDto,
  TechnicianSignupResponse,
} from './dto/technician-signup.dto';

const generateId = (prefix: string): string =>
  `${prefix}_${randomBytes(8).toString('hex')}`;

const normalizePhone = (phone: string): string =>
  phone.replace(/\D/g, '').slice(-10);

@Injectable()
export class TechnicianSignupService {
  private readonly logger = new Logger(TechnicianSignupService.name);

  // CHANGED: explicit constructor with a loud log so we can verify DI works
  constructor() {
    // eslint-disable-next-line no-console
    console.log('🟢 TechnicianSignupService CONSTRUCTED');
    // CHANGED: verify the auth import actually resolved at load time
    // eslint-disable-next-line no-console
    console.log('   auth import type:', typeof auth, '| has api?', !!auth?.api);
  }

  async signup(dto: TechnicianSignupDto): Promise<TechnicianSignupResponse> {
    const normalizedPhone = normalizePhone(dto.phone);

    // ─── Step 1: Pre-flight uniqueness checks ───
    const existingUser = await db.query.users.findFirst({
      where: eq(users.email, dto.email),
    });
    if (existingUser) {
      throw new ConflictException('This email is already registered');
    }

    const phoneTaken = await db.query.technicians.findFirst({
      where: eq(technicians.phone, normalizedPhone),
    });
    if (phoneTaken) {
      throw new ConflictException('This phone number is already registered');
    }

    // CHANGED: guard against auth being undefined at call time (belt-and-braces)
    if (!auth?.api?.signUpEmail) {
      this.logger.error(
        'Better Auth `auth.api.signUpEmail` is not available. ' +
        'Check that @homebuddy-12/auth package is built and exported correctly.',
      );
      throw new InternalServerErrorException(
        'Auth service is not available. Please contact support.',
      );
    }

    // ─── Step 2: Create Better Auth user ───
    let createdUserId: string;
    try {
      const result = await auth.api.signUpEmail({
        body: {
          email: dto.email,
          password: dto.password,
          name: dto.name,
        },
      });

      if (!result?.user?.id) {
        throw new InternalServerErrorException(
          'Auth provider did not return a user',
        );
      }
      createdUserId = result.user.id;
    } catch (err: any) {
      const msg = err?.message ?? 'Failed to create account';
      if (msg.toLowerCase().includes('already') || err?.status === 409) {
        throw new ConflictException('This email is already registered');
      }
      this.logger.error(`Better Auth signup failed: ${msg}`, err?.stack);
      throw new BadRequestException(msg);
    }

    // ─── Step 3: Set role + create profile tables in one transaction ───
    try {
      const technicianId = generateId('tech');

      await db.transaction(async (tx) => {
        await tx
          .update(users)
          .set({
            role: 'technician',
            phone: normalizedPhone,
            updatedAt: new Date(),
          })
          .where(eq(users.id, createdUserId));

        await tx.insert(technicians).values({
          id: technicianId,
          userId: createdUserId,
          name: dto.name,
          phone: normalizedPhone,
          email: dto.email,
          domain: dto.domain,
          experienceYears: dto.experienceYears,
          city: dto.city,
          pincode: dto.pincode,
          isActive: false,
          isVerified: false,
        });

        await tx.insert(technicianKyc).values({
          id: generateId('kyc'),
          technicianId,
          fullName: dto.name,
          status: 'not_submitted',
        });

        await tx.insert(technicianAvailability).values({
          id: generateId('avail'),
          technicianId,
          workMonday: true,
          workTuesday: true,
          workWednesday: true,
          workThursday: true,
          workFriday: true,
          workSaturday: true,
          workSunday: false,
          startTime: '09:00',
          endTime: '18:00',
        });
      });

      this.logger.log(
        `Technician signed up: userId=${createdUserId} technicianId=${technicianId} (${dto.email})`,
      );

      return {
        message:
          'Registration successful! You can now log in. Complete KYC to start accepting bookings.',
        userId: createdUserId,
        technicianId,
        role: 'technician',
        nextSteps: [
          'Log in with your email and password',
          'Submit KYC documents (Aadhaar, PAN, police verification)',
          'Wait for admin approval (typically 24-48 hours)',
          'Once verified, set your availability and start accepting bookings',
        ],
      };
    } catch (err) {
      this.logger.error(
        `Technician profile creation failed for user ${createdUserId}, rolling back`,
        err as Error,
      );

      // CHANGED: cascade deletion via the auth table (accounts FK → users)
      // Your DB schema should have ON DELETE CASCADE from accounts.userId → users.id
      try {
        await db.delete(users).where(eq(users.id, createdUserId));
      } catch (rollbackErr) {
        this.logger.error(
          `CRITICAL: rollback failed for user ${createdUserId} — manual cleanup required`,
          rollbackErr as Error,
        );
      }
      throw new InternalServerErrorException(
        'Failed to complete registration. Please try again.',
      );
    }
  }
}