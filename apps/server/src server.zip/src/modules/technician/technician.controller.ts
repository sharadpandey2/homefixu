import {
  Controller,
  Post,
  Get,
  Patch,
  Body,
  Param,
  Query,
  UseGuards,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { TechnicianService } from './technician.service';
import { TechnicianSignupService } from './technician-signup.service';
import { AuthGuard } from '../../auth/guards/auth.guard';
import { CurrentUser } from '../../auth/decorators/current-user.decorator';
import { TechnicianSignupDto } from './dto/technician-signup.dto';
import {
  UpdateTechnicianProfileDto,
  SubmitKycDto,
  UpdateAvailabilityDto,
  RejectBookingDto,
  CompleteBookingDto,
  CreateInspectionDto,
} from './dto/technician.dto';

@Controller('technician')
export class TechnicianController {
  constructor(
    private readonly technicianService: TechnicianService,
    private readonly technicianSignupService: TechnicianSignupService,
  ) {
    // === DIAGNOSTIC LOGS — REMOVE AFTER DEBUGGING ===
    console.log('🔵 TechnicianController CONSTRUCTED');
    console.log('  technicianService:', typeof this.technicianService, this.technicianService?.constructor?.name);
    console.log('  technicianSignupService:', typeof this.technicianSignupService, this.technicianSignupService?.constructor?.name);
  }

  @Post('signup')
  @HttpCode(HttpStatus.CREATED)
  async register(@Body() dto: TechnicianSignupDto) {
    // === DIAGNOSTIC LOG — REMOVE AFTER DEBUGGING ===
    console.log('🟡 register() called. signupService is:', this.technicianSignupService);
    return this.technicianSignupService.signup(dto);
  }

  @Get('profile')
  @UseGuards(AuthGuard)
  async getProfile(@CurrentUser('id') userId: string) {
    return this.technicianService.getProfile(userId);
  }

  @Patch('profile')
  @UseGuards(AuthGuard)
  async updateProfile(
    @CurrentUser('id') userId: string,
    @Body() dto: UpdateTechnicianProfileDto,
  ) {
    return this.technicianService.updateProfile(userId, dto);
  }

  @Post('kyc/submit')
  @UseGuards(AuthGuard)
  async submitKyc(
    @CurrentUser('id') userId: string,
    @Body() dto: SubmitKycDto,
  ) {
    return this.technicianService.submitKyc(userId, dto);
  }

  @Get('kyc/status')
  @UseGuards(AuthGuard)
  async getKycStatus(@CurrentUser('id') userId: string) {
    return this.technicianService.getKycStatus(userId);
  }

  @Get('availability')
  @UseGuards(AuthGuard)
  async getAvailability(@CurrentUser('id') userId: string) {
    return this.technicianService.getAvailability(userId);
  }

  @Patch('availability')
  @UseGuards(AuthGuard)
  async updateAvailability(
    @CurrentUser('id') userId: string,
    @Body() dto: UpdateAvailabilityDto,
  ) {
    return this.technicianService.updateAvailability(userId, dto);
  }

  @Get('schedule')
  @UseGuards(AuthGuard)
  async getSchedule(
    @CurrentUser('id') userId: string,
    @Query('status') status?: string,
    @Query('date') date?: string,
  ) {
    return this.technicianService.getSchedule(userId, status, date);
  }

  @Patch('bookings/:id/accept')
  @UseGuards(AuthGuard)
  async acceptBooking(
    @CurrentUser('id') userId: string,
    @Param('id') bookingId: string,
  ) {
    return this.technicianService.acceptBooking(userId, bookingId);
  }

  @Patch('bookings/:id/reject')
  @UseGuards(AuthGuard)
  async rejectBooking(
    @CurrentUser('id') userId: string,
    @Param('id') bookingId: string,
    @Body() dto: RejectBookingDto,
  ) {
    return this.technicianService.rejectBooking(userId, bookingId, dto);
  }

  @Patch('bookings/:id/start')
  @UseGuards(AuthGuard)
  async startService(
    @CurrentUser('id') userId: string,
    @Param('id') bookingId: string,
  ) {
    return this.technicianService.startService(userId, bookingId);
  }

  @Patch('bookings/:id/complete')
  @UseGuards(AuthGuard)
  async completeService(
    @CurrentUser('id') userId: string,
    @Param('id') bookingId: string,
    @Body() dto: CompleteBookingDto,
  ) {
    return this.technicianService.completeService(userId, bookingId, dto);
  }

  @Post('inspections')
  @UseGuards(AuthGuard)
  @HttpCode(HttpStatus.CREATED)
  async createInspection(
    @CurrentUser('id') userId: string,
    @Body() dto: CreateInspectionDto,
  ) {
    return this.technicianService.createInspection(userId, dto);
  }

  @Get('inspections')
  @UseGuards(AuthGuard)
  async listInspections(@CurrentUser('id') userId: string) {
    return this.technicianService.listInspections(userId);
  }

  @Get('inspections/:id')
  @UseGuards(AuthGuard)
  async getInspection(
    @CurrentUser('id') userId: string,
    @Param('id') inspectionId: string,
  ) {
    return this.technicianService.getInspection(userId, inspectionId);
  }

  @Get('service-requests/:id')
  @UseGuards(AuthGuard)
  async getServiceRequest(
    @CurrentUser('id') userId: string,
    @Param('id') bookingId: string,
  ) {
    return this.technicianService.getServiceRequest(userId, bookingId);
  }

  @Get('dashboard')
  @UseGuards(AuthGuard)
  async getDashboard(@CurrentUser('id') userId: string) {
    return this.technicianService.getDashboard(userId);
  }
}