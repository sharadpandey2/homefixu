import {
  Injectable,
  NotFoundException,
  BadRequestException,
  Logger,
} from '@nestjs/common';
import { eq, sql, desc } from 'drizzle-orm';
import { randomBytes } from 'crypto';

import { db } from '@homebuddy-12/db';
import {
  technicians,
  technicianKyc,
} from '@homebuddy-12/db/schema';

const generateEmployeeId = (): string =>
  `HB-TECH-${randomBytes(3).toString('hex').toUpperCase()}`;

@Injectable()
export class AdminService {
  private readonly logger = new Logger(AdminService.name);

  async listTechnicians(kycStatus?: string) {
    // Basic listing — refine pagination later
    const rows = await db
      .select({
        id: technicians.id,
        userId: technicians.userId,
        name: technicians.name,
        email: technicians.email,
        phone: technicians.phone,
        domain: technicians.domain,
        city: technicians.city,
        isVerified: technicians.isVerified,
        isActive: technicians.isActive,
        employeeId: technicians.employeeId,
        kycStatus: technicianKyc.status,
        createdAt: technicians.createdAt,
      })
      .from(technicians)
      .leftJoin(technicianKyc, eq(technicianKyc.technicianId, technicians.id))
      .orderBy(desc(technicians.createdAt));

    if (kycStatus) {
      return rows.filter((r) => r.kycStatus === kycStatus);
    }
    return rows;
  }

  async getTechnicianKyc(technicianId: string) {
    const tech = await db.query.technicians.findFirst({
      where: eq(technicians.id, technicianId),
    });
    if (!tech) throw new NotFoundException('Technician not found');

    const kyc = await db.query.technicianKyc.findFirst({
      where: eq(technicianKyc.technicianId, technicianId),
    });
    if (!kyc) throw new NotFoundException('KYC record not found');

    return { technician: tech, kyc };
  }

  async approveKyc(technicianId: string, adminId: string) {
    const kyc = await db.query.technicianKyc.findFirst({
      where: eq(technicianKyc.technicianId, technicianId),
    });
    if (!kyc) throw new NotFoundException('KYC record not found');

    if (kyc.status !== 'under_review') {
      throw new BadRequestException(
        `Cannot approve KYC with status '${kyc.status}'. Must be 'under_review'`,
      );
    }

    const employeeId = generateEmployeeId();
    const now = new Date();

    await db.transaction(async (tx) => {
      await tx
        .update(technicianKyc)
        .set({
          status: 'verified',
          isAadhaarVerified: true,
          isPanVerified: true,
          isPoliceVerified: true,
          reviewedBy: adminId,
          reviewedAt: now,
          updatedAt: now,
        })
        .where(eq(technicianKyc.technicianId, technicianId));

      await tx
        .update(technicians)
        .set({
          isVerified: true,
          isActive: true,
          employeeId,
          updatedAt: now,
        })
        .where(eq(technicians.id, technicianId));
    });

    this.logger.log(
      `KYC approved for technician ${technicianId} by admin ${adminId}, employeeId=${employeeId}`,
    );

    return { message: 'KYC approved', technicianId, employeeId };
  }

  async rejectKyc(technicianId: string, adminId: string, reason: string) {
    if (!reason || reason.trim().length < 5) {
      throw new BadRequestException('Rejection reason must be at least 5 characters');
    }

    const kyc = await db.query.technicianKyc.findFirst({
      where: eq(technicianKyc.technicianId, technicianId),
    });
    if (!kyc) throw new NotFoundException('KYC record not found');

    if (kyc.status !== 'under_review') {
      throw new BadRequestException(
        `Cannot reject KYC with status '${kyc.status}'. Must be 'under_review'`,
      );
    }

    await db
      .update(technicianKyc)
      .set({
        status: 'rejected',
        reviewedBy: adminId,
        reviewedAt: new Date(),
        rejectionReason: reason,
        updatedAt: new Date(),
      })
      .where(eq(technicianKyc.technicianId, technicianId));

    this.logger.log(
      `KYC rejected for technician ${technicianId} by admin ${adminId}`,
    );

    return { message: 'KYC rejected', technicianId };
  }

  async getStats() {
    const [userCounts, bookingCounts, pendingKyc] = await Promise.all([
      db.execute(sql`
        SELECT role, COUNT(*)::int as count
        FROM users
        GROUP BY role
      `),
      db.execute(sql`
        SELECT status, COUNT(*)::int as count
        FROM bookings
        GROUP BY status
      `),
      db.execute(sql`
        SELECT COUNT(*)::int as count
        FROM technician_kyc
        WHERE status = 'under_review'
      `),
    ]);

    return {
      users: (userCounts as any).rows ?? userCounts,
      bookings: (bookingCounts as any).rows ?? bookingCounts,
      pendingKyc: ((pendingKyc as any).rows ?? pendingKyc)[0]?.count ?? 0,
    };
  }
}