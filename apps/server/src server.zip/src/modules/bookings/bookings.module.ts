import { Module } from '@nestjs/common';
import { BookingsController } from './bookings.controller'; // ✅ NO .js
import { BookingsService } from './bookings.service';       // ✅ NO .js

@Module({
  controllers: [BookingsController],
  providers: [BookingsService],
  exports: [BookingsService],
})
export class BookingsModule {}