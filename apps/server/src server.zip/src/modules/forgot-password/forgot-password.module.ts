// ═══════════════════════════════════════════════════════════════════════════════
// FORGOT PASSWORD MODULE - 3 Endpoints
// POST /api/auth/forgot-password/send-otp
// POST /api/auth/forgot-password/verify-otp
// POST /api/auth/forgot-password/reset
// ═══════════════════════════════════════════════════════════════════════════════

import {
  Module,
  Controller,
  Injectable,
  Post,
  Body,
  HttpCode,
  HttpStatus,
  BadRequestException,
  NotFoundException,
  Logger,
} from '@nestjs/common';
import { eq, and, desc, sql } from 'drizzle-orm';
import { randomBytes, randomInt } from 'crypto';
import * as bcrypt from 'bcryptjs';

import { db } from '@homebuddy-12/db';
import { passwordResetOtps } from '@homebuddy-12/db/schema';
import { IsEmail, IsNotEmpty, IsString, MinLength } from 'class-validator';

// ═══ DTOs ═══

class SendOtpDto {
  @IsEmail()
  @IsNotEmpty()
  email!: string;
}

class VerifyOtpDto {
  @IsEmail()
  @IsNotEmpty()
  email!: string;

  @IsString()
  @IsNotEmpty()
  otpCode!: string;
}

class ResetPasswordDto {
  @IsEmail()
  @IsNotEmpty()
  email!: string;

  @IsString()
  @IsNotEmpty()
  otpCode!: string;

  @IsString()
  @MinLength(8, { message: 'Password must be at least 8 characters' })
  newPassword!: string;
}

// ═══ INTERFACES ═══

interface SendOtpResponse {
  message: string;
  expiresInMinutes: number;
}

interface VerifyOtpResponse {
  message: string;
  verified: boolean;
}

interface ResetPasswordResponse {
  message: string;
}

// ═══════════════════════════════════════════════════════════════════════════════
// SERVICE
// ═══════════════════════════════════════════════════════════════════════════════

const generateId = (prefix: string): string =>
  `${prefix}_${randomBytes(8).toString('hex')}`;

@Injectable()
class ForgotPasswordService {
  private readonly logger = new Logger(ForgotPasswordService.name);

  // OTP valid for 10 minutes
  private readonly OTP_EXPIRY_MINUTES = 10;
  // Max 5 OTP requests per email per hour (rate limiting)
  private readonly MAX_OTP_PER_HOUR = 5;

  // ─── 1. SEND OTP ──────────────────────────────────────────────────────────

  async sendOtp(dto: SendOtpDto): Promise<SendOtpResponse> {
    // Better Auth stores users in "user" table
    // Fix: Used Drizzle's sql template literal for raw queries
    const res = (await db.execute(
      sql`SELECT id, email FROM "user" WHERE email = ${dto.email} LIMIT 1`
    )) as any;
    
    // Handle different Postgres driver return formats (pg vs postgres.js)
    const user = res?.rows ? res.rows[0] : res[0];

    if (!user) {
      // Don't reveal if email exists — return success anyway (security best practice)
      return {
        message: 'If this email is registered, you will receive an OTP shortly',
        expiresInMinutes: this.OTP_EXPIRY_MINUTES,
      };
    }

    // Rate limiting: check how many OTPs sent in last hour
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
    const recentOtps = await db
      .select()
      .from(passwordResetOtps)
      .where(eq(passwordResetOtps.email, dto.email));

    const recentCount = recentOtps.filter(
      (otp) => otp.createdAt >= oneHourAgo,
    ).length;

    if (recentCount >= this.MAX_OTP_PER_HOUR) {
      throw new BadRequestException(
        'Too many OTP requests. Please try again after some time',
      );
    }

    // Generate 6-digit OTP
    const otpCode = randomInt(100000, 999999).toString();
    const expiresAt = new Date(Date.now() + this.OTP_EXPIRY_MINUTES * 60 * 1000);

    // Store OTP
    await db.insert(passwordResetOtps).values({
      id: generateId('otp'),
      email: dto.email,
      otpCode,
      expiresAt,
      isUsed: false,
    });

    // TODO: Send OTP via email service (Resend/SendGrid)
    // For now, log it (remove in production!)
    this.logger.warn(`[DEV ONLY] OTP for ${dto.email}: ${otpCode}`);

    return {
      message: 'If this email is registered, you will receive an OTP shortly',
      expiresInMinutes: this.OTP_EXPIRY_MINUTES,
    };
  }

  // ─── 2. VERIFY OTP ────────────────────────────────────────────────────────

  async verifyOtp(dto: VerifyOtpDto): Promise<VerifyOtpResponse> {
    const otp = await this.findValidOtp(dto.email, dto.otpCode);

    if (!otp) {
      throw new BadRequestException('Invalid or expired OTP');
    }

    return {
      message: 'OTP verified successfully',
      verified: true,
    };
  }

  // ─── 3. RESET PASSWORD ────────────────────────────────────────────────────

  async resetPassword(dto: ResetPasswordDto): Promise<ResetPasswordResponse> {
    // Verify OTP again (double-check)
    const otp = await this.findValidOtp(dto.email, dto.otpCode);
    if (!otp) {
      throw new BadRequestException('Invalid or expired OTP');
    }

    // Mark OTP as used
    await db
      .update(passwordResetOtps)
      .set({ isUsed: true })
      .where(eq(passwordResetOtps.id, otp.id));

    // Hash the password properly using bcryptjs
    const hashedPassword = await bcrypt.hash(dto.newPassword, 10);

    // Find user using Drizzle's sql literal
    const res = (await db.execute(
      sql`SELECT id FROM "user" WHERE email = ${dto.email} LIMIT 1`
    )) as any;
    
    const user = res?.rows ? res.rows[0] : res[0];

    if (!user) {
      throw new NotFoundException('User not found');
    }

    // Update password in account table
    await db.execute(
      sql`UPDATE "account" 
          SET "password" = ${hashedPassword}, "updated_at" = NOW() 
          WHERE "user_id" = ${user.id} AND "provider_id" = 'credential'`
    );

    this.logger.log(`Password reset for email: ${dto.email}`);

    return {
      message: 'Password reset successfully. Please login with your new password',
    };
  }

  // ─── HELPER ────────────────────────────────────────────────────────────────

  private async findValidOtp(email: string, otpCode: string) {
    const otps = await db
      .select()
      .from(passwordResetOtps)
      .where(
        and(
          eq(passwordResetOtps.email, email),
          eq(passwordResetOtps.otpCode, otpCode),
          eq(passwordResetOtps.isUsed, false),
        ),
      )
      .orderBy(desc(passwordResetOtps.createdAt))
      .limit(1);

    const otp = otps[0];
    if (!otp) return null;

    // Check expiry
    if (new Date() > otp.expiresAt) return null;

    return otp;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// CONTROLLER
// ═══════════════════════════════════════════════════════════════════════════════

@Controller('auth/forgot-password')
class ForgotPasswordController {
  constructor(private readonly forgotPasswordService: ForgotPasswordService) {}

  @Post('send-otp')
  @HttpCode(HttpStatus.OK)
  async sendOtp(@Body() dto: SendOtpDto) {
    return this.forgotPasswordService.sendOtp(dto);
  }

  @Post('verify-otp')
  @HttpCode(HttpStatus.OK)
  async verifyOtp(@Body() dto: VerifyOtpDto) {
    return this.forgotPasswordService.verifyOtp(dto);
  }

  @Post('reset')
  @HttpCode(HttpStatus.OK)
  async resetPassword(@Body() dto: ResetPasswordDto) {
    return this.forgotPasswordService.resetPassword(dto);
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MODULE
// ═══════════════════════════════════════════════════════════════════════════════

@Module({
  controllers: [ForgotPasswordController],
  providers: [ForgotPasswordService],
})
export class ForgotPasswordModule {}