import { All, Controller, Req, Res } from "@nestjs/common";
import type { Request, Response } from 'express'; // or wherever they come from
import { auth } from "@homebuddy-12/auth";
import { toNodeHandler } from "better-auth/node";

const betterAuthHandler = toNodeHandler(auth);

@Controller("api/auth")
export class AuthController {
  @All("*path")
  async handleAuth(
    @Req() req: Request,
    @Res() res: Response,
  ) {
    // Better Auth expects the full path under /api/auth
    return betterAuthHandler(req, res);
  }
}