import { Module, type MiddlewareConsumer, type NestModule, RequestMethod } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';

import { AuthController } from './app.controller';
import { AppService } from './app.service';
import { LoggerService } from './lib/logger';
import { StorageService } from './lib/storage.service';

import { CustomerModule } from './modules/customer/customer.module';
import { TechnicianModule } from './modules/technician/technician.module';
import { AdminModule } from './modules/admin/admin.module';

import { BetterAuthMiddleware } from './auth/better-auth.middleware';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ['.env', '.env.local'],
    }),

    ThrottlerModule.forRoot([{ ttl: 60000, limit: 10 }]),

    CustomerModule,
    TechnicianModule,
    AdminModule,
  ],
  controllers: [AuthController],
  providers: [AppService, LoggerService, StorageService],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    // Mount Better Auth under /api/auth/*
    // This MUST be mounted before any JSON body parser touches these routes,
    // because Better Auth reads the raw body itself.
    consumer
      .apply(BetterAuthMiddleware)
      .forRoutes({ path: 'api/auth/*path', method: RequestMethod.ALL });
  }
}