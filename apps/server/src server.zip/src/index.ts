import "reflect-metadata";
import { auth } from "@homebuddy-12/auth";
import { env } from "@homebuddy-12/env/server";
import { NestFactory } from "@nestjs/core";
import { toNodeHandler } from "better-auth/node";
import { AppModule } from "./app.module";

const authHandler = toNodeHandler(auth);

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.enableCors({
    origin: env.CORS_ORIGIN,
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
    credentials: true,
  });

  const expressApp = app.getHttpAdapter().getInstance();
  expressApp.all("/api/auth/*splat", authHandler);

  await app.listen(3000);
  console.log("Server is running on http://localhost:3000");
}
bootstrap();