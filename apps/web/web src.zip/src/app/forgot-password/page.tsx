"use client";

import { useState } from "react";
import { motion } from "motion/react";
import Link from "next/link";

export default function CustomerForgotPasswordPage() {
  const [step, setStep] = useState<"email" | "otp" | "reset">("email");
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSendOTP = async () => {
    if (!email) {
      alert("Please enter your email");
      return;
    }

    setIsSubmitting(true);
    try {
      // TODO: Call API to send OTP
      console.log("TODO: Send OTP to", email);
      
      await new Promise((resolve) => setTimeout(resolve, 1500));
      
      alert(`OTP sent to ${email}! Check your inbox.`);
      setStep("otp");
    } catch (error) {
      console.error("Failed to send OTP:", error);
      alert("Failed to send OTP. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (!otp || otp.length !== 6) {
      alert("Please enter the 6-digit OTP");
      return;
    }

    setIsSubmitting(true);
    try {
      // TODO: Call API to verify OTP
      console.log("TODO: Verify OTP", otp);
      
      await new Promise((resolve) => setTimeout(resolve, 1500));
      
      setStep("reset");
    } catch (error) {
      console.error("Failed to verify OTP:", error);
      alert("Invalid OTP. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetPassword = async () => {
    if (newPassword !== confirmPassword) {
      alert("Passwords don't match!");
      return;
    }

    if (newPassword.length < 8) {
      alert("Password must be at least 8 characters");
      return;
    }

    setIsSubmitting(true);
    try {
      // TODO: Call API to reset password
      console.log("TODO: Reset password");
      
      await new Promise((resolve) => setTimeout(resolve, 1500));
      
      alert("Password reset successful! You can now login with your new password.");
      window.location.href = "/login";
    } catch (error) {
      console.error("Failed to reset password:", error);
      alert("Failed to reset password. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-white font-bold text-xl">
              🏠
            </div>
            <h1 className="text-3xl font-bold text-white">HomeBuddy</h1>
          </Link>
          <h2 className="text-2xl font-bold text-white mb-2">Reset Password</h2>
          <p className="text-white/40">
            {step === "email" && "Enter your email to receive OTP"}
            {step === "otp" && "Enter the OTP sent to your email"}
            {step === "reset" && "Create a new password"}
          </p>
        </div>

        {/* Form Card */}
        <div className="rounded-2xl p-8 bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/[0.06]">
          {/* Step 1: Email */}
          {step === "email" && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-4"
            >
              <div>
                <label className="block text-sm font-medium text-white/60 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your.email@example.com"
                  className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.06] text-white placeholder:text-white/40 focus:outline-none focus:border-amber-500/50 transition-all"
                  onKeyPress={(e) => e.key === "Enter" && handleSendOTP()}
                />
              </div>

              <button
                onClick={handleSendOTP}
                disabled={isSubmitting || !email}
                className="w-full px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold hover:from-amber-600 hover:to-amber-700 transition-all disabled:opacity-50"
              >
                {isSubmitting ? "Sending..." : "Send OTP"}
              </button>
            </motion.div>
          )}

          {/* Step 2: OTP Verification */}
          {step === "otp" && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-4"
            >
              <div className="p-4 rounded-xl bg-green-500/10 border border-green-500/20 text-sm text-green-400">
                OTP sent to {email}
              </div>

              <div>
                <label className="block text-sm font-medium text-white/60 mb-2">
                  Enter 6-digit OTP
                </label>
                <input
                  type="text"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  placeholder="000000"
                  maxLength={6}
                  className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.06] text-white text-center text-2xl tracking-widest placeholder:text-white/40 focus:outline-none focus:border-amber-500/50 transition-all"
                  onKeyPress={(e) => e.key === "Enter" && handleVerifyOTP()}
                />
              </div>

              <button
                onClick={handleVerifyOTP}
                disabled={isSubmitting || otp.length !== 6}
                className="w-full px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold hover:from-amber-600 hover:to-amber-700 transition-all disabled:opacity-50"
              >
                {isSubmitting ? "Verifying..." : "Verify OTP"}
              </button>

              <button
                onClick={() => setStep("email")}
                className="w-full text-sm text-white/40 hover:text-white/60 transition-colors"
              >
                ← Back to email
              </button>
            </motion.div>
          )}

          {/* Step 3: Reset Password */}
          {step === "reset" && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-4"
            >
              <div>
                <label className="block text-sm font-medium text-white/60 mb-2">
                  New Password
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Minimum 8 characters"
                  className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.06] text-white placeholder:text-white/40 focus:outline-none focus:border-amber-500/50 transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-white/60 mb-2">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter your password"
                  className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.06] text-white placeholder:text-white/40 focus:outline-none focus:border-amber-500/50 transition-all"
                  onKeyPress={(e) => e.key === "Enter" && handleResetPassword()}
                />
                {confirmPassword && newPassword !== confirmPassword && (
                  <p className="text-xs text-red-400 mt-1">Passwords don't match</p>
                )}
              </div>

              <button
                onClick={handleResetPassword}
                disabled={
                  isSubmitting ||
                  !newPassword ||
                  !confirmPassword ||
                  newPassword !== confirmPassword
                }
                className="w-full px-6 py-3 rounded-xl bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold hover:from-green-600 hover:to-green-700 transition-all disabled:opacity-50"
              >
                {isSubmitting ? "Resetting..." : "Reset Password"}
              </button>
            </motion.div>
          )}
        </div>

        {/* Back to Login */}
        <p className="text-center text-sm text-white/40 mt-6">
          Remember your password?{" "}
          <Link
            href="/login"
            className="text-amber-400 hover:text-amber-300 font-medium"
          >
            Login here
          </Link>
        </p>
      </motion.div>
    </div>
  );
}