"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { authClient } from "@/lib/auth-client";

// ─── Must match backend enum in schema/core.ts (technicianDomainEnum) ───
const SERVICE_DOMAINS = [
  { id: "plumbing",       name: "Plumbing",         icon: "🔧" },
  { id: "electrical",     name: "Electrical",       icon: "⚡" },
  { id: "pest_control",   name: "Pest Control",     icon: "🐛" },
  { id: "hvac",           name: "HVAC",             icon: "❄️" },
  { id: "structural",     name: "Structural",       icon: "🏗️" },
  { id: "painting",       name: "Painting",         icon: "🎨" },
  { id: "waterproofing",  name: "Waterproofing",    icon: "💧" },
  { id: "appliance",      name: "Appliance Repair", icon: "🔌" },
] as const;

const EXPERIENCE_RANGES = [
  { value: "0-1",  label: "Less than 1 year" },
  { value: "1-3",  label: "1–3 years" },
  { value: "3-5",  label: "3–5 years" },
  { value: "5-10", label: "5–10 years" },
  { value: "10+",  label: "10+ years" },
] as const;

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:3000";

export default function TechnicianRegisterPage() {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    domain: "" as typeof SERVICE_DOMAINS[number]["id"] | "",
    experienceYears: "",
    city: "",
    pincode: "",
    agreeTerms: false,
    agreeBackgroundCheck: false,
  });

  const isStep1Valid =
    formData.name.trim().length >= 2 &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email) &&
    /^\+?\d[\d\s-]{8,14}$/.test(formData.phone) &&
    formData.password.length >= 8 &&
    formData.password === formData.confirmPassword;

  const isStep2Valid =
    !!formData.domain &&
    !!formData.experienceYears &&
    formData.city.trim().length > 0 &&
    /^\d{6}$/.test(formData.pincode);

  async function handleSubmit() {
    setSubmitError(null);

    if (!formData.agreeTerms || !formData.agreeBackgroundCheck) {
      setSubmitError("Please accept all terms and conditions");
      return;
    }

    setIsSubmitting(true);

    try {
      // Call our custom technician signup endpoint.
      // This creates the Better Auth user AND the technician profile atomically.
      const res = await fetch(`${API_URL}/technician/signup`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          password: formData.password,
          phone: formData.phone,
          domain: formData.domain,
          experienceYears: formData.experienceYears,
          city: formData.city,
          pincode: formData.pincode,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setSubmitError(
          data?.message ??
            (Array.isArray(data?.message) ? data.message.join(", ") : "Registration failed"),
        );
        return;
      }

      // Auto-login via Better Auth so they land on the dashboard logged in
      const { error: loginError } = await authClient.signIn.email({
        email: formData.email,
        password: formData.password,
      });

      if (loginError) {
        // Signup worked but login didn't — send them to login page
        router.push("/technician/login?registered=1");
        return;
      }

      router.push("/technician/dashboard");
    } catch (err) {
      console.error("Registration error:", err);
      setSubmitError("Network error. Please check your connection and try again.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-2xl"
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-white font-bold text-xl">
              🔧
            </div>
            <h1 className="text-3xl font-bold text-white">HomeBuddy</h1>
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Join as a Technician</h2>
          <p className="text-white/40">Start serving customers on HomeBuddy</p>
        </div>

        {/* Step Indicator */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {[1, 2, 3].map((step) => (
            <div key={step} className="flex items-center gap-2">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all ${
                  currentStep === step
                    ? "bg-amber-500 text-white"
                    : currentStep > step
                    ? "bg-green-500 text-white"
                    : "bg-white/10 text-white/40"
                }`}
              >
                {currentStep > step ? "✓" : step}
              </div>
              {step < 3 && (
                <div className={`w-16 h-1 rounded-full ${currentStep > step ? "bg-green-500" : "bg-white/10"}`} />
              )}
            </div>
          ))}
        </div>

        <div className="rounded-2xl p-8 bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/[0.06]">
          {/* ─── STEP 1: Personal info ─── */}
          {currentStep === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-4"
            >
              <h3 className="text-xl font-bold text-white mb-6">Personal Information</h3>

              <Field label="Full Name *">
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Rahul Sharma"
                  className={inputCls}
                />
              </Field>

              <Field label="Email Address *">
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="you@example.com"
                  className={inputCls}
                />
              </Field>

              <Field label="Phone Number *">
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+91 98765 43210"
                  className={inputCls}
                />
              </Field>

              <Field label="Password *">
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="Minimum 8 characters"
                  className={inputCls}
                />
              </Field>

              <Field label="Confirm Password *">
                <input
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  placeholder="Re-enter your password"
                  className={inputCls}
                />
                {formData.confirmPassword && formData.password !== formData.confirmPassword && (
                  <p className="text-xs text-red-400 mt-1">Passwords don&apos;t match</p>
                )}
              </Field>

              <button
                onClick={() => setCurrentStep(2)}
                disabled={!isStep1Valid}
                className={primaryBtn}
              >
                Continue to Professional Info
              </button>
            </motion.div>
          )}

          {/* ─── STEP 2: Professional info ─── */}
          {currentStep === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-4"
            >
              <h3 className="text-xl font-bold text-white mb-6">Professional Information</h3>

              <div>
                <label className="block text-sm font-medium text-white/60 mb-3">
                  Service Domain *
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {SERVICE_DOMAINS.map((d) => (
                    <button
                      key={d.id}
                      type="button"
                      onClick={() => setFormData({ ...formData, domain: d.id })}
                      className={`p-4 rounded-xl transition-all text-center ${
                        formData.domain === d.id
                          ? "bg-amber-500/20 border-2 border-amber-500/50 text-amber-400"
                          : "bg-white/[0.04] border border-white/[0.06] text-white/60 hover:bg-white/[0.08]"
                      }`}
                    >
                      <div className="text-2xl mb-1">{d.icon}</div>
                      <div className="text-xs font-medium">{d.name}</div>
                    </button>
                  ))}
                </div>
              </div>

              <Field label="Years of Experience *">
                <select
                  value={formData.experienceYears}
                  onChange={(e) => setFormData({ ...formData, experienceYears: e.target.value })}
                  className={inputCls}
                >
                  <option value="">Select experience</option>
                  {EXPERIENCE_RANGES.map((r) => (
                    <option key={r.value} value={r.value}>{r.label}</option>
                  ))}
                </select>
              </Field>

              <Field label="City *">
                <input
                  type="text"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  placeholder="e.g. Gurgaon"
                  className={inputCls}
                />
              </Field>

              <Field label="Pincode *">
                <input
                  type="text"
                  value={formData.pincode}
                  onChange={(e) => setFormData({ ...formData, pincode: e.target.value.replace(/\D/g, "") })}
                  placeholder="122001"
                  maxLength={6}
                  className={inputCls}
                />
              </Field>

              <div className="flex gap-3">
                <button onClick={() => setCurrentStep(1)} className={secondaryBtn}>
                  Back
                </button>
                <button onClick={() => setCurrentStep(3)} disabled={!isStep2Valid} className={primaryBtn}>
                  Continue to Terms
                </button>
              </div>
            </motion.div>
          )}

          {/* ─── STEP 3: Terms ─── */}
          {currentStep === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-4"
            >
              <h3 className="text-xl font-bold text-white mb-6">Review &amp; Confirm</h3>

              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] space-y-2 text-sm">
                <Row k="Name"       v={formData.name} />
                <Row k="Email"      v={formData.email} />
                <Row k="Phone"      v={formData.phone} />
                <Row k="Domain"     v={SERVICE_DOMAINS.find((d) => d.id === formData.domain)?.name ?? "—"} />
                <Row k="Experience" v={EXPERIENCE_RANGES.find((e) => e.value === formData.experienceYears)?.label ?? "—"} />
                <Row k="Location"   v={`${formData.city}, ${formData.pincode}`} />
              </div>

              <Checkbox
                checked={formData.agreeTerms}
                onChange={(v) => setFormData({ ...formData, agreeTerms: v })}
              >
                I agree to HomeBuddy&apos;s{" "}
                <Link href="/terms" className="text-amber-400 hover:underline">Terms of Service</Link> and{" "}
                <Link href="/privacy" className="text-amber-400 hover:underline">Privacy Policy</Link>
              </Checkbox>

              <Checkbox
                checked={formData.agreeBackgroundCheck}
                onChange={(v) => setFormData({ ...formData, agreeBackgroundCheck: v })}
              >
                I authorize HomeBuddy to conduct background verification and police checks as part of eKYC.
              </Checkbox>

              <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/20">
                <p className="text-sm text-blue-400">
                  After registration you&apos;ll be logged in immediately, but you must complete eKYC
                  (Aadhaar, PAN, police verification) and wait for admin approval before accepting jobs.
                </p>
              </div>

              <AnimatePresence>
                {submitError && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="p-4 rounded-xl bg-red-500/10 border border-red-500/20"
                  >
                    <p className="text-sm text-red-400">{submitError}</p>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="flex gap-3">
                <button onClick={() => setCurrentStep(2)} className={secondaryBtn} disabled={isSubmitting}>
                  Back
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={isSubmitting || !formData.agreeTerms || !formData.agreeBackgroundCheck}
                  className="flex-1 px-6 py-3 rounded-xl bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold hover:from-green-600 hover:to-green-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? "Creating account…" : "Complete Registration"}
                </button>
              </div>
            </motion.div>
          )}
        </div>

        <p className="text-center text-sm text-white/40 mt-6">
          Already have an account?{" "}
          <Link href="/technician/login" className="text-amber-400 hover:text-amber-300 font-medium">
            Sign in
          </Link>
        </p>
      </motion.div>
    </div>
  );
}

// ─── Small presentational helpers (kept in-file so this is drop-in) ───

const inputCls =
  "w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.06] text-white placeholder:text-white/40 focus:outline-none focus:border-amber-500/50 transition-all";

const primaryBtn =
  "w-full px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold hover:from-amber-600 hover:to-amber-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed mt-2";

const secondaryBtn =
  "flex-1 px-6 py-3 rounded-xl bg-white/[0.04] border border-white/[0.06] text-white font-semibold hover:bg-white/[0.08] transition-all";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm font-medium text-white/60 mb-2">{label}</label>
      {children}
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <p className="text-white/60">
      <span className="text-white font-medium">{k}:</span> {v}
    </p>
  );
}

function Checkbox({
  checked,
  onChange,
  children,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  children: React.ReactNode;
}) {
  return (
    <label className="flex items-start gap-3 p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] cursor-pointer hover:bg-white/[0.04] transition-all">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="w-5 h-5 mt-0.5 rounded border-2 border-white/20 bg-white/5 checked:bg-amber-500 checked:border-amber-500 cursor-pointer"
      />
      <span className="text-sm text-white/70 leading-relaxed">{children}</span>
    </label>
  );
}