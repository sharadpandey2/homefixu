"use client";

import { useState } from "react";
import { motion } from "motion/react";

// Types (aligned with customer booking schema)
interface ServiceRequest {
  id: string;
  booking_id: string;
  service_name: string;
  service_category: string;
  customer_name: string;
  customer_phone: string;
  property_address: string;
  property_city: string;
  scheduled_date: string;
  scheduled_slot: string;
  status: "pending" | "confirmed" | "in_progress" | "completed";
  total_price: number;
  special_instructions?: string;
}

// Sample data (TODO: Replace with API)
const SAMPLE_REQUESTS: ServiceRequest[] = [
  {
    id: "req_1",
    booking_id: "booking_123",
    service_name: "Monthly Plumbing Inspection",
    service_category: "Plumbing",
    customer_name: "Sharad Pandey",
    customer_phone: "+91 98765 43210",
    property_address: "Flat 301, Tower A, Green Valley Apartments, Sector 43",
    property_city: "Gurgaon, Haryana - 122001",
    scheduled_date: "2026-03-30",
    scheduled_slot: "14:00-16:00",
    status: "pending",
    total_price: 599,
    special_instructions: "Please call before arriving",
  },
  {
    id: "req_2",
    booking_id: "booking_124",
    service_name: "Electrical Safety Check",
    service_category: "Electrical",
    customer_name: "John Doe",
    customer_phone: "+91 98111 22333",
    property_address: "B-204, Golf Course Road",
    property_city: "Gurgaon, Haryana - 122002",
    scheduled_date: "2026-03-30",
    scheduled_slot: "10:00-12:00",
    status: "pending",
    total_price: 699,
  },
  {
    id: "req_3",
    booking_id: "booking_125",
    service_name: "Pest Control Treatment",
    service_category: "Pest Control",
    customer_name: "Amit Sharma",
    customer_phone: "+91 99999 11111",
    property_address: "Villa 12, DLF Phase 4",
    property_city: "Gurgaon, Haryana - 122009",
    scheduled_date: "2026-03-31",
    scheduled_slot: "09:00-11:00",
    status: "pending",
    total_price: 1299,
  },
];

const CONFIRMED_JOBS: ServiceRequest[] = [
  {
    id: "req_4",
    booking_id: "booking_126",
    service_name: "Tank Cleaning",
    service_category: "Sanitation",
    customer_name: "Priya Singh",
    customer_phone: "+91 98888 77777",
    property_address: "A-101, Cyber City",
    property_city: "Gurgaon, Haryana - 122018",
    scheduled_date: "2026-03-30",
    scheduled_slot: "16:00-18:00",
    status: "confirmed",
    total_price: 899,
  },
];

function ServiceRequestCard({
  request,
  onAccept,
  onReject,
  showActions = true,
}: {
  request: ServiceRequest;
  onAccept?: (id: string) => void;
  onReject?: (id: string) => void;
  showActions?: boolean;
}) {
  const getServiceIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case "plumbing":
        return "🔧";
      case "electrical":
        return "⚡";
      case "pest control":
        return "🐛";
      case "sanitation":
        return "💧";
      default:
        return "🔨";
    }
  };

  const formatDate = (date: string) => {
    const d = new Date(date);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    if (d.toDateString() === today.toDateString()) return "Today";
    if (d.toDateString() === tomorrow.toDateString()) return "Tomorrow";
    return d.toLocaleDateString("en-IN", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl p-6 bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/[0.06] hover:border-amber-500/20 transition-all"
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500/20 to-amber-600/10 flex items-center justify-center text-2xl">
            {getServiceIcon(request.service_category)}
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white mb-1">
              {request.service_name}
            </h3>
            <p className="text-sm text-white/40">{request.service_category}</p>
          </div>
        </div>
        <span className="text-lg font-bold text-amber-400">
          ₹{request.total_price}
        </span>
      </div>

      {/* Customer Info */}
      <div className="space-y-3 mb-4">
        <div className="flex items-center gap-2 text-sm text-white/70">
          <svg className="w-4 h-4 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
          <span className="font-medium">{request.customer_name}</span>
          <span className="text-white/40">• {request.customer_phone}</span>
        </div>

        <div className="flex items-start gap-2 text-sm text-white/70">
          <svg className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
          <div>
            <p>{request.property_address}</p>
            <p className="text-white/40 text-xs">{request.property_city}</p>
          </div>
        </div>

        <div className="flex items-center gap-4 text-sm text-white/70">
          <div className="flex items-center gap-2">
            <svg className="w-4 h-4 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <span className="font-medium">{formatDate(request.scheduled_date)}</span>
          </div>
          <div className="flex items-center gap-2">
            <svg className="w-4 h-4 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>{request.scheduled_slot}</span>
          </div>
        </div>

        {request.special_instructions && (
          <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20">
            <p className="text-xs text-blue-400 mb-1 font-semibold">Special Instructions:</p>
            <p className="text-sm text-white/70">{request.special_instructions}</p>
          </div>
        )}
      </div>

      {/* Actions */}
      {showActions && (
        <div className="flex gap-3 pt-4 border-t border-white/[0.06]">
          <button
            onClick={() => onReject?.(request.id)}
            className="flex-1 px-4 py-3 rounded-xl text-sm font-semibold text-red-400 hover:bg-red-500/10 border border-red-500/20 transition-all"
          >
            Reject
          </button>
          <button
            onClick={() => onAccept?.(request.id)}
            className="flex-1 px-4 py-3 rounded-xl text-sm font-semibold bg-gradient-to-r from-green-500 to-green-600 text-white hover:from-green-600 hover:to-green-700 transition-all"
          >
            Accept Job
          </button>
        </div>
      )}
    </motion.div>
  );
}

export default function TechnicianDashboard() {
  const [requests, setRequests] = useState(SAMPLE_REQUESTS);
  const [confirmedJobs, setConfirmedJobs] = useState(CONFIRMED_JOBS);

  // Stats
  const todayJobs = confirmedJobs.filter(
    (j) =>
      new Date(j.scheduled_date).toDateString() === new Date().toDateString()
  ).length;
  const pendingRequests = requests.length;
  const completedThisWeek = 12; // TODO: Fetch from API

  const handleAccept = (id: string) => {
    const request = requests.find((r) => r.id === id);
    if (!request) return;

    // TODO: Call API to accept request
    console.log("TODO: Accept request", id);

    // Move to confirmed
    setConfirmedJobs([...confirmedJobs, { ...request, status: "confirmed" }]);
    setRequests(requests.filter((r) => r.id !== id));
    alert("Request accepted! Added to your schedule.");
  };

  const handleReject = (id: string) => {
    if (window.confirm("Are you sure you want to reject this request?")) {
      // TODO: Call API to reject request
      console.log("TODO: Reject request", id);

      setRequests(requests.filter((r) => r.id !== id));
      alert("Request rejected.");
    }
  };

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold tracking-tight text-white mb-2">
          Technician Dashboard
        </h1>
        <p className="text-white/40">Manage your service requests and schedule</p>
      </motion.div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="rounded-2xl p-6 bg-gradient-to-br from-blue-500/10 to-blue-600/5 border border-blue-500/20"
        >
          <p className="text-sm text-blue-400 mb-2">Today's Jobs</p>
          <p className="text-4xl font-bold text-white">{todayJobs}</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="rounded-2xl p-6 bg-gradient-to-br from-amber-500/10 to-amber-600/5 border border-amber-500/20"
        >
          <p className="text-sm text-amber-400 mb-2">Pending Requests</p>
          <p className="text-4xl font-bold text-white">{pendingRequests}</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="rounded-2xl p-6 bg-gradient-to-br from-green-500/10 to-green-600/5 border border-green-500/20"
        >
          <p className="text-sm text-green-400 mb-2">Completed This Week</p>
          <p className="text-4xl font-bold text-white">{completedThisWeek}</p>
        </motion.div>
      </div>

      {/* New Requests Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.5 }}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white">
            New Service Requests
            {requests.length > 0 && (
              <span className="ml-3 px-3 py-1 rounded-full text-sm font-semibold bg-red-500 text-white">
                {requests.length}
              </span>
            )}
          </h2>
        </div>

        <div className="space-y-4">
          {requests.length === 0 ? (
            <div className="text-center py-12 rounded-2xl bg-white/[0.02] border border-white/[0.06]">
              <div className="text-6xl mb-4">✅</div>
              <h3 className="text-xl font-semibold text-white mb-2">
                All Caught Up!
              </h3>
              <p className="text-white/40">No new service requests at the moment</p>
            </div>
          ) : (
            requests.map((request) => (
              <ServiceRequestCard
                key={request.id}
                request={request}
                onAccept={handleAccept}
                onReject={handleReject}
              />
            ))
          )}
        </div>
      </motion.div>

      {/* Today's Confirmed Jobs */}
      {confirmedJobs.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.5 }}
        >
          <h2 className="text-xl font-bold text-white mb-4">
            Today's Confirmed Jobs
          </h2>
          <div className="space-y-4">
            {confirmedJobs.map((job) => (
              <ServiceRequestCard
                key={job.id}
                request={job}
                showActions={false}
              />
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}