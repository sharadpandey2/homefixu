"use client";

import { Suspense, useState } from "react";
import { motion } from "motion/react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { authClient } from "@/lib/auth-client";

function TechnicianLoginInner() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const justRegistered = searchParams.get("registered") === "1";

  const [formData, setFormData] = useState({ email: "", password: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  function validate() {
    const e: Record<string, string> = {};
    if (!formData.email.trim()) e.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) e.email = "Invalid email format";
    if (!formData.password) e.password = "Password is required";
    else if (formData.password.length < 8) e.password = "Password must be at least 8 characters";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;

    setIsLoading(true);
    setErrors({});

    try {
      // 1. Sign in via Better Auth
      const { error: authError } = await authClient.signIn.email({
        email: formData.email,
        password: formData.password,
      });

      if (authError) {
        setErrors({ submit: authError.message ?? "Invalid credentials" });
        setIsLoading(false);
        return;
      }

      // 2. Verify the role is 'technician' — otherwise sign out and block.
      // This prevents customers from accidentally (or deliberately) landing
      // on the technician dashboard via the technician login page.
      const session = await authClient.getSession();
      const role = (session?.data?.user as { role?: string } | undefined)?.role;

      if (role !== "technician") {
        await authClient.signOut();
        setErrors({
          submit:
            role === "admin"
              ? "This account is an admin account. Please use the admin login page."
              : role === "customer"
              ? "This account is a customer account. Please use the customer login page."
              : "This account is not a technician account.",
        });
        setIsLoading(false);
        return;
      }

      router.push("/technician/dashboard");
    } catch (err) {
      console.error("Login error:", err);
      setErrors({ submit: "Something went wrong. Please try again." });
      setIsLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 mb-4">
            <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Technician Portal</h1>
          <p className="text-white/40">Sign in to access your dashboard</p>
        </div>

        {justRegistered && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
            <p className="text-sm text-emerald-400">
              ✓ Registration successful! Please sign in with your credentials.
            </p>
          </div>
        )}

        <div className="rounded-2xl p-8 bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/[0.06]">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-white/60 mb-2">Email Address</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="technician@homebuddy.com"
                className={`w-full px-4 py-3 rounded-xl bg-white/[0.02] border ${
                  errors.email ? "border-red-500/50" : "border-white/[0.06]"
                } text-white placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors`}
              />
              {errors.email && <p className="text-xs text-red-400 mt-1">{errors.email}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-white/60 mb-2">Password</label>
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                placeholder="Enter your password"
                className={`w-full px-4 py-3 rounded-xl bg-white/[0.02] border ${
                  errors.password ? "border-red-500/50" : "border-white/[0.06]"
                } text-white placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors`}
              />
              {errors.password && <p className="text-xs text-red-400 mt-1">{errors.password}</p>}
            </div>

            {errors.submit && (
              <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20">
                <p className="text-sm text-red-400">{errors.submit}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full px-4 py-3 rounded-xl text-sm font-semibold bg-gradient-to-r from-amber-500 to-amber-600 text-white hover:from-amber-600 hover:to-amber-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Signing in...
                </span>
              ) : (
                "Sign In"
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <Link
              href="/technician/forgot-password"
              className="text-sm text-amber-400 hover:text-amber-300 transition-colors"
            >
              Forgot your password?
            </Link>
          </div>
        </div>

        <div className="mt-6 text-center space-y-3">
          <p className="text-sm text-white/40">
            New to HomeBuddy as a technician?{" "}
            <Link href="/technician/register" className="text-amber-400 hover:text-amber-300 font-semibold">
              Join Now
            </Link>
          </p>
          <p className="text-sm text-white/40">
            For customer login,{" "}
            <Link href="/login" className="text-amber-400 hover:text-amber-300">
              click here
            </Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}

export default function TechnicianLoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-zinc-950" />}>
      <TechnicianLoginInner />
    </Suspense>
  );
}