import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";

import "../index.css";
import Header from "@/components/header";
import { Providers } from "@/components/providers";
import { AuthLayoutWrapper } from "@/components/auth-layout-wrapper";
import { ChatWidget } from "@/components/chat/ChatWidget";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "homebuddy-12",
  description: "homebuddy-12",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>
        <Providers>
          <AuthLayoutWrapper header={<Header />}>
            {children}
          </AuthLayoutWrapper>
          {/* ChatWidget - Available on all pages */}
          <ChatWidget />
        </Providers>
      </body>
    </html>
  );
}