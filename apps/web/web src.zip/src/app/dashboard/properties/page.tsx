"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";

// Types
interface Property {
  id: string;
  name: string;
  type: "apartment" | "independent_house" | "villa" | "row_house" | "penthouse";
  addressLine1: string;
  city: string;
  state: string;
  pincode: string;
  areaValue: number;
  areaUnit: "bhk" | "sqft" | "gaz";
  yearBuilt?: number;
  floors?: number;
  isDefault: boolean;
  createdAt: string;
}

// Property Type Options
const PROPERTY_TYPES = [
  { value: "apartment", label: "Apartment", icon: "🏢" },
  { value: "independent_house", label: "Independent House", icon: "🏠" },
  { value: "villa", label: "Villa", icon: "🏰" },
  { value: "row_house", label: "Row House", icon: "🏘️" },
  { value: "penthouse", label: "Penthouse", icon: "🌆" },
] as const;

// Area Unit Options
const AREA_UNITS = [
  { value: "bhk", label: "BHK", description: "Bedroom Hall Kitchen" },
  { value: "sqft", label: "Square Feet", description: "sq ft" },
  { value: "gaz", label: "Gaz", description: "Indian measurement" },
] as const;

// BHK Options
const BHK_OPTIONS = ["1", "2", "3", "4", "5", "5+"];

// Indian States
const INDIAN_STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
  "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka",
  "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram",
  "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu",
  "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
  "Delhi", "Chandigarh", "Puducherry",
];

export default function PropertiesPage() {
  const [property, setProperty] = useState<Property>({
    id: "1",
    name: "My Home",
    type: "apartment",
    addressLine1: "Flat 301, Tower A, Green Valley Apartments",
    city: "Gurgaon",
    state: "Haryana",
    pincode: "122001",
    areaValue: 3,
    areaUnit: "bhk",
    yearBuilt: 2018,
    floors: 1,
    isDefault: true,
    createdAt: "2024-01-15",
  });

  const [isEditing, setIsEditing] = useState(false);
  const [editedProperty, setEditedProperty] = useState<Property>(property);
  const [hasChanges, setHasChanges] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const propertyType = PROPERTY_TYPES.find((t) => t.value === editedProperty.type);

  const formatArea = () => {
    if (editedProperty.areaUnit === "bhk") {
      return `${editedProperty.areaValue} BHK`;
    } else if (editedProperty.areaUnit === "sqft") {
      return `${editedProperty.areaValue.toLocaleString()} sq ft`;
    } else {
      return `${editedProperty.areaValue} Gaz`;
    }
  };

  const handleEdit = () => {
    setIsEditing(true);
    setEditedProperty(property);
    setHasChanges(false);
  };

  const handleChange = (updates: Partial<Property>) => {
    setEditedProperty({ ...editedProperty, ...updates });
    setHasChanges(true);
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};

    if (!editedProperty.name?.trim()) newErrors.name = "Property name is required";
    if (!editedProperty.addressLine1?.trim()) newErrors.addressLine1 = "Address is required";
    if (!editedProperty.city?.trim()) newErrors.city = "City is required";
    if (!editedProperty.state) newErrors.state = "State is required";
    if (!editedProperty.pincode?.trim() || !/^\d{6}$/.test(editedProperty.pincode)) {
      newErrors.pincode = "Valid 6-digit pincode required";
    }
    if (!editedProperty.areaValue || editedProperty.areaValue <= 0) {
      newErrors.areaValue = "Area value is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (!validate()) return;
    
    if (hasChanges) {
      if (window.confirm("Do you want to save your changes?")) {
        setProperty(editedProperty);
        setIsEditing(false);
        setHasChanges(false);
        alert("Property updated successfully!");
      }
    } else {
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    if (hasChanges) {
      if (window.confirm("You have unsaved changes. Do you want to discard them?")) {
        setEditedProperty(property);
        setIsEditing(false);
        setHasChanges(false);
        setErrors({});
      }
    } else {
      setIsEditing(false);
    }
  };

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-white mb-2">
              My Properties
            </h1>
            <p className="text-white/40">Manage your property details</p>
          </div>
          <div className="flex gap-3">
            {isEditing ? (
              <>
                <button
                  onClick={handleCancel}
                  className="px-6 py-3 rounded-xl bg-white/[0.04] text-white/70 font-semibold hover:bg-white/[0.08] transition-all"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold hover:from-amber-600 hover:to-amber-700 transition-all"
                >
                  Save Changes
                </button>
              </>
            ) : (
              <button
                onClick={handleEdit}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold hover:from-amber-600 hover:to-amber-700 transition-all"
              >
                ✏️ Edit Property
              </button>
            )}
          </div>
        </div>
      </motion.div>

      {/* Property Details Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.5 }}
        className={`rounded-2xl p-8 bg-gradient-to-br from-white/[0.04] to-white/[0.02] border ${
          isEditing ? "border-amber-500/30" : "border-white/[0.06]"
        } transition-all`}
      >
        <div className="space-y-6">
          {/* Property Name & Type */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-white/40 mb-2">
                Property Name
              </label>
              {isEditing ? (
                <input
                  type="text"
                  value={editedProperty.name}
                  onChange={(e) => handleChange({ name: e.target.value })}
                  className={`w-full px-4 py-3 rounded-xl bg-white/[0.02] border ${
                    errors.name ? "border-red-500/50" : "border-white/[0.06]"
                  } text-white text-lg font-semibold placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors`}
                />
              ) : (
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500/20 to-amber-600/10 flex items-center justify-center text-2xl">
                    {propertyType?.icon || "🏠"}
                  </div>
                  <div>
                    <p className="text-lg font-semibold text-white">{editedProperty.name}</p>
                    <p className="text-sm text-white/40">{propertyType?.label}</p>
                  </div>
                </div>
              )}
              {errors.name && (
                <p className="text-xs text-red-400 mt-1">{errors.name}</p>
              )}
            </div>

            {isEditing && (
              <div>
                <label className="block text-sm font-medium text-white/40 mb-2">
                  Property Type
                </label>
                <div className="grid grid-cols-5 gap-2">
                  {PROPERTY_TYPES.map((type) => (
                    <button
                      key={type.value}
                      onClick={() => handleChange({ type: type.value })}
                      className={`p-2 rounded-xl border transition-all ${
                        editedProperty.type === type.value
                          ? "bg-amber-500/20 border-amber-500/50 text-amber-400"
                          : "bg-white/[0.02] border-white/[0.06] text-white/60 hover:bg-white/[0.04]"
                      }`}
                    >
                      <div className="text-xl mb-1">{type.icon}</div>
                      <div className="text-[10px] font-medium">{type.label.split(" ")[0]}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Address */}
          <div>
            <label className="block text-sm font-medium text-white/40 mb-2">
              📍 Address
            </label>
            {isEditing ? (
              <input
                type="text"
                value={editedProperty.addressLine1}
                onChange={(e) => handleChange({ addressLine1: e.target.value })}
                placeholder="House/Flat No., Street, Area"
                className={`w-full px-4 py-3 rounded-xl bg-white/[0.02] border ${
                  errors.addressLine1 ? "border-red-500/50" : "border-white/[0.06]"
                } text-white placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors`}
              />
            ) : (
              <p className="text-white">{editedProperty.addressLine1}</p>
            )}
            {errors.addressLine1 && (
              <p className="text-xs text-red-400 mt-1">{errors.addressLine1}</p>
            )}
          </div>

          {/* City, State, Pincode */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-white/40 mb-2">
                City
              </label>
              {isEditing ? (
                <input
                  type="text"
                  value={editedProperty.city}
                  onChange={(e) => handleChange({ city: e.target.value })}
                  placeholder="e.g., Gurgaon"
                  className={`w-full px-4 py-3 rounded-xl bg-white/[0.02] border ${
                    errors.city ? "border-red-500/50" : "border-white/[0.06]"
                  } text-white placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors`}
                />
              ) : (
                <p className="text-white">{editedProperty.city}</p>
              )}
              {errors.city && (
                <p className="text-xs text-red-400 mt-1">{errors.city}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-white/40 mb-2">
                State
              </label>
              {isEditing ? (
                <select
                  value={editedProperty.state}
                  onChange={(e) => handleChange({ state: e.target.value })}
                  className={`w-full px-4 py-3 rounded-xl bg-white/[0.02] border ${
                    errors.state ? "border-red-500/50" : "border-white/[0.06]"
                  } text-white focus:border-amber-500/30 focus:outline-none transition-colors`}
                >
                  <option value="">Select State</option>
                  {INDIAN_STATES.map((state) => (
                    <option key={state} value={state}>
                      {state}
                    </option>
                  ))}
                </select>
              ) : (
                <p className="text-white">{editedProperty.state}</p>
              )}
              {errors.state && (
                <p className="text-xs text-red-400 mt-1">{errors.state}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-white/40 mb-2">
                Pincode
              </label>
              {isEditing ? (
                <input
                  type="text"
                  value={editedProperty.pincode}
                  onChange={(e) => handleChange({ pincode: e.target.value })}
                  placeholder="6-digit code"
                  maxLength={6}
                  className={`w-full px-4 py-3 rounded-xl bg-white/[0.02] border ${
                    errors.pincode ? "border-red-500/50" : "border-white/[0.06]"
                  } text-white placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors`}
                />
              ) : (
                <p className="text-white">{editedProperty.pincode}</p>
              )}
              {errors.pincode && (
                <p className="text-xs text-red-400 mt-1">{errors.pincode}</p>
              )}
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-white/[0.06]"></div>

          {/* Area */}
          <div>
            <label className="block text-sm font-medium text-white/40 mb-2">
              📐 Property Area
            </label>
            
            {isEditing ? (
              <div className="space-y-4">
                {/* Area Unit Selection */}
                <div className="grid grid-cols-3 gap-2">
                  {AREA_UNITS.map((unit) => (
                    <button
                      key={unit.value}
                      onClick={() =>
                        handleChange({ areaUnit: unit.value, areaValue: 0 })
                      }
                      className={`p-3 rounded-xl border transition-all ${
                        editedProperty.areaUnit === unit.value
                          ? "bg-amber-500/20 border-amber-500/50 text-amber-400"
                          : "bg-white/[0.02] border-white/[0.06] text-white/60 hover:bg-white/[0.04]"
                      }`}
                    >
                      <div className="font-semibold mb-0.5">{unit.label}</div>
                      <div className="text-[10px] text-white/40">{unit.description}</div>
                    </button>
                  ))}
                </div>

                {/* Area Value Input */}
                {editedProperty.areaUnit === "bhk" ? (
                  <div className="grid grid-cols-6 gap-2">
                    {BHK_OPTIONS.map((bhk) => (
                      <button
                        key={bhk}
                        onClick={() =>
                          handleChange({
                            areaValue: bhk === "5+" ? 6 : parseInt(bhk),
                          })
                        }
                        className={`p-3 rounded-xl border transition-all ${
                          editedProperty.areaValue === (bhk === "5+" ? 6 : parseInt(bhk))
                            ? "bg-amber-500/20 border-amber-500/50 text-amber-400"
                            : "bg-white/[0.02] border-white/[0.06] text-white/60 hover:bg-white/[0.04]"
                        }`}
                      >
                        <div className="font-bold">{bhk}</div>
                        <div className="text-[9px] text-white/40">BHK</div>
                      </button>
                    ))}
                  </div>
                ) : (
                  <input
                    type="number"
                    value={editedProperty.areaValue || ""}
                    onChange={(e) =>
                      handleChange({ areaValue: parseInt(e.target.value) || 0 })
                    }
                    placeholder={editedProperty.areaUnit === "sqft" ? "e.g., 1000" : "e.g., 100"}
                    className={`w-full px-4 py-3 rounded-xl bg-white/[0.02] border ${
                      errors.areaValue ? "border-red-500/50" : "border-white/[0.06]"
                    } text-white placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors`}
                  />
                )}
                {errors.areaValue && (
                  <p className="text-xs text-red-400 mt-1">{errors.areaValue}</p>
                )}
              </div>
            ) : (
              <p className="text-white text-lg font-semibold">{formatArea()}</p>
            )}
          </div>

          {/* Year Built & Floors */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-white/40 mb-2">
                📅 Year Built
              </label>
              {isEditing ? (
                <input
                  type="number"
                  value={editedProperty.yearBuilt || ""}
                  onChange={(e) =>
                    handleChange({
                      yearBuilt: e.target.value ? parseInt(e.target.value) : undefined,
                    })
                  }
                  placeholder="e.g., 2015"
                  min="1900"
                  max={new Date().getFullYear()}
                  className="w-full px-4 py-3 rounded-xl bg-white/[0.02] border border-white/[0.06] text-white placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors"
                />
              ) : (
                <p className="text-white">
                  {editedProperty.yearBuilt || "Not specified"}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-white/40 mb-2">
                🏢 Number of Floors
              </label>
              {isEditing ? (
                <input
                  type="number"
                  value={editedProperty.floors || ""}
                  onChange={(e) =>
                    handleChange({
                      floors: e.target.value ? parseInt(e.target.value) : undefined,
                    })
                  }
                  placeholder="e.g., 2"
                  min="1"
                  max="10"
                  className="w-full px-4 py-3 rounded-xl bg-white/[0.02] border border-white/[0.06] text-white placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors"
                />
              ) : (
                <p className="text-white">
                  {editedProperty.floors ? `${editedProperty.floors} Floor${editedProperty.floors > 1 ? "s" : ""}` : "Not specified"}
                </p>
              )}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Edit Mode Indicator */}
      <AnimatePresence>
        {isEditing && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="rounded-2xl p-4 bg-amber-500/10 border border-amber-500/20"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center">
                <svg
                  className="w-5 h-5 text-amber-400"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
              <div>
                <p className="text-sm font-medium text-amber-400">
                  Editing Mode Active
                </p>
                <p className="text-xs text-white/40">
                  Make your changes and click "Save Changes" when done
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}