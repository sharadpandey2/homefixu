"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import Link from "next/link";

// Types
interface Booking {
  id: string;
  serviceName: string;
  serviceCategory: string;
  propertyName: string;
  scheduledDate: string;
  scheduledSlot: string;
  status: "pending" | "confirmed" | "in_progress" | "completed" | "cancelled";
  totalPrice: number;
  providerName?: string;
  providerPhone?: string;
  completedAt?: string;
  notes?: string;
}

// Service Categories for Filters
const SERVICE_CATEGORIES = [
  "All Services",
  "Plumbing",
  "Electrical",
  "Pest Control",
  "Paint & Sealant",
  "Tank Cleaning",
  "CCTV",
  "Doorbell",
  "Interior Design",
];

// Time Slots for Reschedule
const TIME_SLOTS = [
  "09:00-11:00",
  "11:00-13:00",
  "13:00-15:00",
  "15:00-17:00",
  "17:00-19:00",
];

// Tab for filtering bookings
type BookingTab = "upcoming" | "past" | "all";

// Helper Functions
function formatDate(dateString: string) {
  const date = new Date(dateString);
  return date.toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function formatTime(slot: string) {
  return slot;
}

function getStatusColor(status: string) {
  switch (status) {
    case "confirmed":
      return "bg-green-500/15 text-green-400 border-green-500/30";
    case "pending":
      return "bg-amber-500/15 text-amber-400 border-amber-500/30";
    case "in_progress":
      return "bg-blue-500/15 text-blue-400 border-blue-500/30";
    case "completed":
      return "bg-purple-500/15 text-purple-400 border-purple-500/30";
    case "cancelled":
      return "bg-red-500/15 text-red-400 border-red-500/30";
    default:
      return "bg-white/10 text-white/40 border-white/20";
  }
}

function getServiceIcon(category: string) {
  switch (category.toLowerCase()) {
    case "plumbing":
      return "🔧";
    case "electrical":
      return "⚡";
    case "pest control":
      return "🐛";
    case "paint & sealant":
      return "🎨";
    case "tank cleaning":
      return "💧";
    case "cctv":
      return "📹";
    case "doorbell":
      return "🔔";
    case "interior design":
      return "✨";
    default:
      return "🏠";
  }
}

// Booking Card Component
function BookingCard({
  booking,
  onReschedule,
  onCancel,
  onViewDetails,
}: {
  booking: Booking;
  onReschedule: (booking: Booking) => void;
  onCancel: (booking: Booking) => void;
  onViewDetails: (booking: Booking) => void;
}) {
  const isPast = booking.status === "completed" || booking.status === "cancelled";
  const canReschedule = booking.status === "pending" || booking.status === "confirmed";

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="rounded-2xl p-5 bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/[0.06] hover:border-amber-500/20 transition-all"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500/20 to-amber-600/10 flex items-center justify-center text-2xl">
            {getServiceIcon(booking.serviceCategory)}
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white mb-1">
              {booking.serviceName}
            </h3>
            <p className="text-sm text-white/40">{booking.propertyName}</p>
          </div>
        </div>
        <span
          className={`px-3 py-1 rounded-full text-xs font-semibold border ${getStatusColor(
            booking.status
          )}`}
        >
          {booking.status.replace("_", " ")}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="flex items-center gap-2 text-sm text-white/60">
          <svg
            className="w-4 h-4"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
            />
          </svg>
          <span>{formatDate(booking.scheduledDate)}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-white/60">
          <svg
            className="w-4 h-4"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
          <span>{formatTime(booking.scheduledSlot)}</span>
        </div>
      </div>

      {booking.providerName && (
        <div className="mb-4 p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]">
          <p className="text-xs text-white/40 mb-1">Service Provider</p>
          <p className="text-sm text-white font-medium">{booking.providerName}</p>
          {booking.providerPhone && (
            <p className="text-xs text-white/40 mt-1">{booking.providerPhone}</p>
          )}
        </div>
      )}

      <div className="flex items-center justify-between pt-4 border-t border-white/[0.06]">
        <div className="text-lg font-bold text-white">₹{booking.totalPrice}</div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onViewDetails(booking)}
            className="px-4 py-2 rounded-lg text-sm font-medium text-white/70 hover:text-white hover:bg-white/[0.04] transition-all"
          >
            View Details
          </button>
          {canReschedule && (
            <>
              <button
                onClick={() => onReschedule(booking)}
                className="px-4 py-2 rounded-lg text-sm font-medium bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 transition-all"
              >
                Reschedule
              </button>
              <button
                onClick={() => onCancel(booking)}
                className="px-4 py-2 rounded-lg text-sm font-medium text-red-400 hover:bg-red-500/10 transition-all"
              >
                Cancel
              </button>
            </>
          )}
        </div>
      </div>
    </motion.div>
  );
}

// Reschedule Modal Component
function RescheduleModal({
  booking,
  onClose,
  onConfirm,
}: {
  booking: Booking;
  onClose: () => void;
  onConfirm: (date: string, slot: string) => void;
}) {
  const [selectedDate, setSelectedDate] = useState(booking.scheduledDate);
  const [selectedSlot, setSelectedSlot] = useState(booking.scheduledSlot);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleConfirm = async () => {
    setIsProcessing(true);
    await new Promise((resolve) => setTimeout(resolve, 1000)); // Simulate API call
    onConfirm(selectedDate, selectedSlot);
    setIsProcessing(false);
  };

  // Generate next 30 days
  const availableDates = Array.from({ length: 30 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() + i + 1);
    return date.toISOString().split("T")[0];
  });

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.95, y: 20 }}
        className="bg-gradient-to-br from-zinc-900 to-zinc-950 rounded-2xl border border-white/[0.06] p-6 max-w-md w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Reschedule Booking</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-white/[0.04] transition-colors"
          >
            <svg
              className="w-5 h-5 text-white/40"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        <div className="mb-6 p-4 rounded-xl bg-white/[0.02] border border-white/[0.04]">
          <p className="text-sm text-white/40 mb-1">Current Schedule</p>
          <p className="text-white font-medium">
            {formatDate(booking.scheduledDate)} • {booking.scheduledSlot}
          </p>
        </div>

        <div className="space-y-6">
          {/* Date Selection */}
          <div>
            <label className="block text-sm font-medium text-white/60 mb-3">
              Select New Date
            </label>
            <div className="grid grid-cols-3 gap-2 max-h-64 overflow-y-auto">
              {availableDates.map((date) => {
                const dateObj = new Date(date);
                const dayName = dateObj.toLocaleDateString("en-IN", {
                  weekday: "short",
                });
                const dayNum = dateObj.getDate();
                const month = dateObj.toLocaleDateString("en-IN", {
                  month: "short",
                });

                return (
                  <button
                    key={date}
                    onClick={() => setSelectedDate(date)}
                    className={`p-3 rounded-xl border transition-all ${
                      selectedDate === date
                        ? "bg-amber-500/20 border-amber-500/50 text-amber-400"
                        : "bg-white/[0.02] border-white/[0.06] text-white/60 hover:bg-white/[0.04]"
                    }`}
                  >
                    <div className="text-xs mb-1">{dayName}</div>
                    <div className="text-lg font-bold">{dayNum}</div>
                    <div className="text-xs">{month}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Time Slot Selection */}
          <div>
            <label className="block text-sm font-medium text-white/60 mb-3">
              Select Time Slot
            </label>
            <div className="space-y-2">
              {TIME_SLOTS.map((slot) => (
                <button
                  key={slot}
                  onClick={() => setSelectedSlot(slot)}
                  className={`w-full p-3 rounded-xl border transition-all ${
                    selectedSlot === slot
                      ? "bg-amber-500/20 border-amber-500/50 text-amber-400"
                      : "bg-white/[0.02] border-white/[0.06] text-white/60 hover:bg-white/[0.04]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{slot}</span>
                    {selectedSlot === slot && (
                      <svg
                        className="w-5 h-5"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-3 rounded-xl text-sm font-semibold text-white/70 hover:bg-white/[0.04] transition-all"
          >
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            disabled={isProcessing}
            className="flex-1 px-4 py-3 rounded-xl text-sm font-semibold bg-gradient-to-r from-amber-500 to-amber-600 text-white hover:from-amber-600 hover:to-amber-700 transition-all disabled:opacity-50"
          >
            {isProcessing ? "Rescheduling..." : "Confirm Reschedule"}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// Booking Details Modal
function BookingDetailsModal({
  booking,
  onClose,
}: {
  booking: Booking;
  onClose: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.95, y: 20 }}
        className="bg-gradient-to-br from-zinc-900 to-zinc-950 rounded-2xl border border-white/[0.06] p-6 max-w-lg w-full"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Booking Details</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-white/[0.04] transition-colors"
          >
            <svg
              className="w-5 h-5 text-white/40"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.02] border border-white/[0.04]">
            <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-amber-500/20 to-amber-600/10 flex items-center justify-center text-3xl">
              {getServiceIcon(booking.serviceCategory)}
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white">
                {booking.serviceName}
              </h3>
              <p className="text-sm text-white/40">{booking.serviceCategory}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.04]">
              <p className="text-xs text-white/40 mb-1">Property</p>
              <p className="text-sm text-white font-medium">
                {booking.propertyName}
              </p>
            </div>
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.04]">
              <p className="text-xs text-white/40 mb-1">Status</p>
              <span
                className={`inline-block px-2 py-1 rounded-full text-xs font-semibold border ${getStatusColor(
                  booking.status
                )}`}
              >
                {booking.status.replace("_", " ")}
              </span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.04]">
            <p className="text-xs text-white/40 mb-2">Scheduled For</p>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-white">
                <svg
                  className="w-4 h-4 text-amber-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
                <span className="font-medium">
                  {formatDate(booking.scheduledDate)}
                </span>
              </div>
              <div className="flex items-center gap-2 text-white">
                <svg
                  className="w-4 h-4 text-amber-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
                <span className="font-medium">{booking.scheduledSlot}</span>
              </div>
            </div>
          </div>

          {booking.providerName && (
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.04]">
              <p className="text-xs text-white/40 mb-2">Service Provider</p>
              <p className="text-white font-medium">{booking.providerName}</p>
              {booking.providerPhone && (
                <p className="text-sm text-white/40 mt-1">
                  {booking.providerPhone}
                </p>
              )}
            </div>
          )}

          {booking.notes && (
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.04]">
              <p className="text-xs text-white/40 mb-2">Notes</p>
              <p className="text-sm text-white/70">{booking.notes}</p>
            </div>
          )}

          {booking.completedAt && (
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.04]">
              <p className="text-xs text-white/40 mb-1">Completed On</p>
              <p className="text-sm text-white font-medium">
                {formatDate(booking.completedAt)}
              </p>
            </div>
          )}

          <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
            <div className="flex items-center justify-between">
              <p className="text-white/60">Total Amount</p>
              <p className="text-2xl font-bold text-white">
                ₹{booking.totalPrice}
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full mt-6 px-4 py-3 rounded-xl text-sm font-semibold bg-white/[0.04] text-white hover:bg-white/[0.08] transition-all"
        >
          Close
        </button>
      </motion.div>
    </motion.div>
  );
}

// Main Bookings Page
export default function BookingsPage() {
  const [activeTab, setActiveTab] = useState<BookingTab>("upcoming");
  const [selectedCategory, setSelectedCategory] = useState("All Services");
  const [searchQuery, setSearchQuery] = useState("");
  const [rescheduleBooking, setRescheduleBooking] = useState<Booking | null>(
    null
  );
  const [detailsBooking, setDetailsBooking] = useState<Booking | null>(null);
  const [cancelBooking, setCancelBooking] = useState<Booking | null>(null);

  // TODO: Replace with API call
  // const { data: bookings, isLoading } = useBookings();
  const [bookings, setBookings] = useState<Booking[]>([
    {
      id: "1",
      serviceName: "Monthly Plumbing Inspection",
      serviceCategory: "Plumbing",
      propertyName: "Home - Sector 43, Gurgaon",
      scheduledDate: "2026-04-02",
      scheduledSlot: "09:00-11:00",
      status: "confirmed",
      totalPrice: 599,
      providerName: "Ravi Kumar",
      providerPhone: "+91 98765 43210",
    },
    {
      id: "2",
      serviceName: "Electrical Safety Check",
      serviceCategory: "Electrical",
      propertyName: "Home - Sector 43, Gurgaon",
      scheduledDate: "2026-04-10",
      scheduledSlot: "14:00-16:00",
      status: "pending",
      totalPrice: 699,
    },
    {
      id: "3",
      serviceName: "Pest Control Treatment",
      serviceCategory: "Pest Control",
      propertyName: "Home - Sector 43, Gurgaon",
      scheduledDate: "2026-03-20",
      scheduledSlot: "11:00-13:00",
      status: "completed",
      totalPrice: 1299,
      providerName: "Pest Control Pro",
      providerPhone: "+91 98111 22333",
      completedAt: "2026-03-20",
      notes: "Treatment completed successfully. No pests found.",
    },
  ]);

  // Filter bookings
  const filteredBookings = bookings.filter((booking) => {
    const matchesTab =
      activeTab === "all" ||
      (activeTab === "upcoming" &&
        (booking.status === "pending" ||
          booking.status === "confirmed" ||
          booking.status === "in_progress")) ||
      (activeTab === "past" &&
        (booking.status === "completed" || booking.status === "cancelled"));

    const matchesCategory =
      selectedCategory === "All Services" ||
      booking.serviceCategory === selectedCategory;

    const matchesSearch =
      searchQuery === "" ||
      booking.serviceName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      booking.propertyName.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesTab && matchesCategory && matchesSearch;
  });

  const handleReschedule = (date: string, slot: string) => {
    if (!rescheduleBooking) return;

    // TODO: Call API to reschedule
    console.log("Reschedule booking:", rescheduleBooking.id, date, slot);

    setBookings(
      bookings.map((b) =>
        b.id === rescheduleBooking.id
          ? { ...b, scheduledDate: date, scheduledSlot: slot }
          : b
      )
    );

    setRescheduleBooking(null);
    alert("Booking rescheduled successfully!");
  };

  const handleCancel = (booking: Booking) => {
    setCancelBooking(booking);
  };

  const confirmCancel = () => {
    if (!cancelBooking) return;

    // TODO: Call API to cancel
    console.log("Cancel booking:", cancelBooking.id);

    setBookings(
      bookings.map((b) =>
        b.id === cancelBooking.id ? { ...b, status: "cancelled" } : b
      )
    );

    setCancelBooking(null);
    alert("Booking cancelled successfully!");
  };

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-white mb-2">
              My Bookings
            </h1>
            <p className="text-white/40">
              Manage your service bookings and appointments
            </p>
          </div>
          <Link href="/dashboard/services" as={"/dashboard/services" as never}>
            <button className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold hover:from-amber-600 hover:to-amber-700 transition-all">
              + Book Service
            </button>
          </Link>
        </div>
      </motion.div>

      {/* Tabs */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.5 }}
        className="flex items-center gap-2 p-1 rounded-2xl bg-white/[0.02] border border-white/[0.06] w-fit"
      >
        {(["upcoming", "past", "all"] as BookingTab[]).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`relative px-6 py-2.5 rounded-xl text-sm font-medium transition-all ${
              activeTab === tab
                ? "text-white"
                : "text-white/50 hover:text-white/70"
            }`}
          >
            {activeTab === tab && (
              <motion.div
                layoutId="activeTab"
                className="absolute inset-0 rounded-xl bg-amber-500/20 border border-amber-500/30"
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
              />
            )}
            <span className="relative z-10 capitalize">{tab}</span>
          </button>
        ))}
      </motion.div>

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.5 }}
        className="flex flex-col sm:flex-row gap-4"
      >
        {/* Search */}
        <div className="flex-1 relative">
          <svg
            className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
          <input
            type="text"
            placeholder="Search bookings..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-xl bg-white/[0.02] border border-white/[0.06] text-white placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors"
          />
        </div>

        {/* Category Filter */}
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="px-4 py-3 rounded-xl bg-white/[0.02] border border-white/[0.06] text-white focus:border-amber-500/30 focus:outline-none transition-colors"
        >
          {SERVICE_CATEGORIES.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>
      </motion.div>

      {/* Bookings List */}
      <motion.div layout className="space-y-4">
        <AnimatePresence mode="popLayout">
          {filteredBookings.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center py-12 rounded-2xl bg-white/[0.02] border border-white/[0.06]"
            >
              <div className="text-6xl mb-4">📅</div>
              <h3 className="text-xl font-semibold text-white mb-2">
                No bookings found
              </h3>
              <p className="text-white/40 mb-6">
                {searchQuery || selectedCategory !== "All Services"
                  ? "Try adjusting your filters"
                  : "Book a service to get started"}
              </p>
              <Link
                href="/dashboard/services"
                as={"/dashboard/services" as never}
              >
                <button className="px-6 py-3 rounded-xl bg-amber-500/10 text-amber-400 font-semibold hover:bg-amber-500/20 transition-all">
                  Browse Services
                </button>
              </Link>
            </motion.div>
          ) : (
            filteredBookings.map((booking) => (
              <BookingCard
                key={booking.id}
                booking={booking}
                onReschedule={(b) => setRescheduleBooking(b)}
                onCancel={(b) => handleCancel(b)}
                onViewDetails={(b) => setDetailsBooking(b)}
              />
            ))
          )}
        </AnimatePresence>
      </motion.div>

      {/* Modals */}
      <AnimatePresence>
        {rescheduleBooking && (
          <RescheduleModal
            booking={rescheduleBooking}
            onClose={() => setRescheduleBooking(null)}
            onConfirm={handleReschedule}
          />
        )}

        {detailsBooking && (
          <BookingDetailsModal
            booking={detailsBooking}
            onClose={() => setDetailsBooking(null)}
          />
        )}

        {cancelBooking && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setCancelBooking(null)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              className="bg-gradient-to-br from-zinc-900 to-zinc-950 rounded-2xl border border-white/[0.06] p-6 max-w-md w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="text-center mb-6">
                <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center mx-auto mb-4">
                  <svg
                    className="w-8 h-8 text-red-500"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">
                  Cancel Booking?
                </h3>
                <p className="text-white/40">
                  Are you sure you want to cancel this booking? This action
                  cannot be undone.
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setCancelBooking(null)}
                  className="flex-1 px-4 py-3 rounded-xl text-sm font-semibold text-white/70 hover:bg-white/[0.04] transition-all"
                >
                  Keep Booking
                </button>
                <button
                  onClick={confirmCancel}
                  className="flex-1 px-4 py-3 rounded-xl text-sm font-semibold bg-red-500 text-white hover:bg-red-600 transition-all"
                >
                  Yes, Cancel
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}