"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";

// SOS Emergency Types
interface EmergencyCategory {
  id: string;
  name: string;
  icon: string;
  description: string;
  examples: string[];
  color: string;
  borderColor: string;
  textColor: string;
}

interface RecentSOS {
  id: string;
  type: string;
  icon: string;
  status: "resolved" | "active" | "cancelled";
  date: string;
  responseTime: string;
}

// Emergency Categories
const EMERGENCY_CATEGORIES: EmergencyCategory[] = [
  {
    id: "health",
    name: "Health Emergency",
    icon: "🏥",
    description: "Medical emergencies requiring immediate assistance",
    examples: ["Cardiac arrest", "Severe injury", "Unconscious person", "Allergic reaction"],
    color: "from-red-500/10 to-red-600/5",
    borderColor: "border-red-500/30",
    textColor: "text-red-400",
  },
  {
    id: "plumbing",
    name: "Burst Pipe / Flood",
    icon: "💧",
    description: "Urgent plumbing failures causing water damage",
    examples: ["Burst pipe", "Severe water leak", "Overflowing tank", "Drain blockage"],
    color: "from-blue-500/10 to-blue-600/5",
    borderColor: "border-blue-500/30",
    textColor: "text-blue-400",
  },
  {
    id: "electrical",
    name: "Electrical Fault",
    icon: "⚡",
    description: "Dangerous electrical failures needing urgent repair",
    examples: ["Short circuit", "Sparking wires", "Power outage", "Electrical fire risk"],
    color: "from-yellow-500/10 to-yellow-600/5",
    borderColor: "border-yellow-500/30",
    textColor: "text-yellow-400",
  },
  {
    id: "structural",
    name: "Structural Damage",
    icon: "🏚️",
    description: "Immediate structural threats to your home",
    examples: ["Ceiling collapse risk", "Wall crack", "Gas leak", "Fire hazard"],
    color: "from-orange-500/10 to-orange-600/5",
    borderColor: "border-orange-500/30",
    textColor: "text-orange-400",
  },
];

// Recent SOS history
const RECENT_SOS: RecentSOS[] = [
  {
    id: "sos-001",
    type: "Burst Pipe",
    icon: "💧",
    status: "resolved",
    date: "Mar 15, 2026",
    responseTime: "12 min",
  },
  {
    id: "sos-002",
    type: "Electrical Fault",
    icon: "⚡",
    status: "resolved",
    date: "Feb 2, 2026",
    responseTime: "18 min",
  },
];

// SOS Button Component
function SOSButton({ onActivate }: { onActivate: () => void }) {
  const [holdProgress, setHoldProgress] = useState(0);
  const [isHolding, setIsHolding] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startTimeRef = useRef<number | null>(null);
  const HOLD_DURATION = 3000; // 3 seconds

  const startHold = useCallback(() => {
    if (isCompleted) return;
    setIsHolding(true);
    startTimeRef.current = Date.now();
    intervalRef.current = setInterval(() => {
      const elapsed = Date.now() - (startTimeRef.current ?? Date.now());
      const progress = Math.min((elapsed / HOLD_DURATION) * 100, 100);
      setHoldProgress(progress);
      if (progress >= 100) {
        clearInterval(intervalRef.current!);
        setIsCompleted(true);
        setIsHolding(false);
        onActivate();
      }
    }, 16);
  }, [isCompleted, onActivate]);

  const stopHold = useCallback(() => {
    if (isCompleted) return;
    setIsHolding(false);
    setHoldProgress(0);
    if (intervalRef.current) clearInterval(intervalRef.current);
  }, [isCompleted]);

  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  return (
    <div className="flex flex-col items-center gap-6">
      {/* Pulse rings behind button */}
      <div className="relative flex items-center justify-center">
        {/* Outer pulse rings */}
        {isHolding && (
          <>
            <motion.div
              className="absolute rounded-full border-2 border-red-500/20"
              animate={{ scale: [1, 1.8], opacity: [0.4, 0] }}
              transition={{ repeat: Infinity, duration: 1.2, ease: "easeOut" }}
              style={{ width: 220, height: 220 }}
            />
            <motion.div
              className="absolute rounded-full border-2 border-red-500/30"
              animate={{ scale: [1, 1.5], opacity: [0.5, 0] }}
              transition={{ repeat: Infinity, duration: 1.2, delay: 0.3, ease: "easeOut" }}
              style={{ width: 220, height: 220 }}
            />
          </>
        )}

        {/* Progress ring SVG */}
        <svg
          className="absolute"
          width={220}
          height={220}
          style={{ transform: "rotate(-90deg)" }}
        >
          {/* Background ring */}
          <circle
            cx={110}
            cy={110}
            r={100}
            fill="none"
            stroke="rgba(255,255,255,0.04)"
            strokeWidth={6}
          />
          {/* Progress ring */}
          <circle
            cx={110}
            cy={110}
            r={100}
            fill="none"
            stroke={isCompleted ? "#22c55e" : "#ef4444"}
            strokeWidth={6}
            strokeLinecap="round"
            strokeDasharray={`${2 * Math.PI * 100}`}
            strokeDashoffset={`${2 * Math.PI * 100 * (1 - holdProgress / 100)}`}
            style={{ transition: "stroke-dashoffset 0.016s linear" }}
          />
        </svg>

        {/* Main SOS Button */}
        <motion.button
          onMouseDown={startHold}
          onMouseUp={stopHold}
          onMouseLeave={stopHold}
          onTouchStart={startHold}
          onTouchEnd={stopHold}
          animate={
            isCompleted
              ? { scale: 1, backgroundColor: "#16a34a" }
              : isHolding
              ? { scale: 0.95 }
              : { scale: 1 }
          }
          whileHover={!isCompleted ? { scale: 1.03 } : {}}
          className="relative w-44 h-44 rounded-full flex flex-col items-center justify-center gap-2 cursor-pointer select-none z-10 shadow-2xl"
          style={{
            background: isCompleted
              ? "linear-gradient(135deg, #15803d, #166534)"
              : "linear-gradient(135deg, #dc2626, #991b1b)",
            boxShadow: isHolding
              ? "0 0 60px rgba(239,68,68,0.5), 0 0 120px rgba(239,68,68,0.2)"
              : isCompleted
              ? "0 0 60px rgba(34,197,94,0.4)"
              : "0 8px 40px rgba(239,68,68,0.3)",
          }}
        >
          <span className="text-5xl">{isCompleted ? "✅" : "🆘"}</span>
          <span className="text-white font-black text-xl tracking-widest">
            {isCompleted ? "CALLED" : "SOS"}
          </span>
          {!isCompleted && (
            <span className="text-red-200 text-xs font-medium">Hold 3 sec</span>
          )}
        </motion.button>
      </div>

      {/* Progress label */}
      <AnimatePresence mode="wait">
        {isHolding && !isCompleted && (
          <motion.p
            key="holding"
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            className="text-red-400 font-semibold text-sm animate-pulse"
          >
            Hold to confirm... {Math.round(holdProgress)}%
          </motion.p>
        )}
        {isCompleted && (
          <motion.p
            key="completed"
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-green-400 font-semibold text-sm"
          >
            Emergency call initiated!
          </motion.p>
        )}
        {!isHolding && !isCompleted && (
          <motion.p
            key="idle"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-white/30 text-sm text-center"
          >
            Press and hold for 3 seconds to activate
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}

// Emergency Category Card
function CategoryCard({ category }: { category: EmergencyCategory }) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`rounded-2xl p-5 bg-gradient-to-br ${category.color} border ${category.borderColor} hover:scale-[1.02] transition-all relative overflow-hidden group`}
    >
      <div className="flex items-start gap-4">
        <div
          className={`w-12 h-12 rounded-xl bg-white/[0.05] flex items-center justify-center text-2xl flex-shrink-0 group-hover:scale-110 transition-transform`}
        >
          {category.icon}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className={`font-bold text-white mb-1`}>{category.name}</h3>
          <p className="text-sm text-white/50">{category.description}</p>
        </div>
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="mt-4 pt-4 border-t border-white/[0.06]">
              <p className={`text-xs font-semibold ${category.textColor} mb-2`}>
                Common Scenarios:
              </p>
              <div className="grid grid-cols-2 gap-1">
                {category.examples.map((ex, idx) => (
                  <div key={idx} className="flex items-center gap-1.5 text-xs text-white/50">
                    <div className={`w-1 h-1 rounded-full bg-current ${category.textColor}`} />
                    {ex}
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className={`mt-3 text-xs ${category.textColor} hover:opacity-80 transition-opacity flex items-center gap-1`}
      >
        {isExpanded ? "Show Less" : "See Examples"}
        <svg
          className={`w-3.5 h-3.5 transition-transform ${isExpanded ? "rotate-180" : ""}`}
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
    </motion.div>
  );
}

// Active SOS Modal
function ActiveSOSModal({ onDismiss }: { onDismiss: () => void }) {
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTime = (s: number) => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="w-full max-w-sm rounded-3xl bg-gradient-to-br from-red-900/60 to-black border border-red-500/30 p-8 text-center shadow-2xl"
      >
        {/* Animated pulse indicator */}
        <div className="flex justify-center mb-6">
          <div className="relative">
            <motion.div
              className="absolute inset-0 rounded-full bg-red-500/30"
              animate={{ scale: [1, 1.6], opacity: [0.5, 0] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
            />
            <div className="relative w-20 h-20 rounded-full bg-red-600 flex items-center justify-center text-4xl">
              📞
            </div>
          </div>
        </div>

        <h2 className="text-2xl font-black text-white mb-1">SOS Activated</h2>
        <p className="text-red-300 text-sm mb-6">Connecting to emergency response team...</p>

        {/* Timer */}
        <div className="mb-6 p-4 rounded-2xl bg-white/[0.04] border border-white/[0.06]">
          <p className="text-xs text-white/40 mb-1">Call Duration</p>
          <p className="text-3xl font-mono font-bold text-white">{formatTime(elapsed)}</p>
        </div>

        {/* Info */}
        <div className="space-y-2 mb-6">
          <div className="flex items-center justify-between text-sm p-3 rounded-xl bg-white/[0.03] border border-white/[0.04]">
            <span className="text-white/40">Avg. Response Time</span>
            <span className="text-amber-400 font-semibold">~15 min</span>
          </div>
          <div className="flex items-center justify-between text-sm p-3 rounded-xl bg-white/[0.03] border border-white/[0.04]">
            <span className="text-white/40">Location Shared</span>
            <span className="text-green-400 font-semibold">✓ Enabled</span>
          </div>
        </div>

        <button
          onClick={onDismiss}
          className="w-full py-3 rounded-xl bg-white/[0.06] text-white/60 font-semibold hover:bg-white/[0.10] transition-all text-sm"
        >
          Cancel SOS Request
        </button>
      </motion.div>
    </motion.div>
  );
}

// Main SOS Page
export default function SOSPage() {
  const [showModal, setShowModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const handleActivate = () => {
    setShowModal(true);
  };

  return (
    <>
      <AnimatePresence>
        {showModal && (
          <ActiveSOSModal onDismiss={() => setShowModal(false)} />
        )}
      </AnimatePresence>

      <div className="mx-auto max-w-4xl space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center gap-3 mb-2">
            <span className="text-3xl">🆘</span>
            <h1 className="text-3xl font-bold tracking-tight text-white">
              SOS Emergency
            </h1>
          </div>
          <p className="text-white/40">
            Instant emergency assistance for health crises and urgent home failures
          </p>
        </motion.div>

        {/* Alert Banner */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="p-4 rounded-2xl bg-gradient-to-r from-red-500/10 to-red-600/5 border border-red-500/20 flex items-start gap-3"
        >
          <span className="text-xl flex-shrink-0">⚠️</span>
          <div>
            <p className="text-sm font-semibold text-red-400 mb-1">Mobile App Feature</p>
            <p className="text-xs text-white/50">
              The SOS button is available on the HomeBuddy mobile app. Hold it for 3 seconds to trigger an emergency call. This page provides a preview and history of your SOS usage.
            </p>
          </div>
        </motion.div>

        {/* Stats Row */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.5 }}
          className="grid grid-cols-3 gap-4"
        >
          <div className="p-4 rounded-2xl bg-gradient-to-br from-red-500/10 to-red-600/5 border border-red-500/20 text-center">
            <p className="text-2xl font-bold text-white">24/7</p>
            <p className="text-xs text-red-400 mt-1">Always Available</p>
          </div>
          <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/10 to-amber-600/5 border border-amber-500/20 text-center">
            <p className="text-2xl font-bold text-white">~15<span className="text-base font-normal"> min</span></p>
            <p className="text-xs text-amber-400 mt-1">Avg. Response</p>
          </div>
          <div className="p-4 rounded-2xl bg-gradient-to-br from-green-500/10 to-green-600/5 border border-green-500/20 text-center">
            <p className="text-2xl font-bold text-white">Free</p>
            <p className="text-xs text-green-400 mt-1">All Plans</p>
          </div>
        </motion.div>

        {/* Two Column Layout */}
        <div className="grid gap-8 lg:grid-cols-5">
          {/* Left: SOS Button */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="lg:col-span-2"
          >
            <div className="rounded-2xl p-8 bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/[0.06] flex flex-col items-center">
              <p className="text-sm font-semibold text-white/60 mb-6 text-center">
                Tap & hold to activate emergency call
              </p>

              <SOSButton onActivate={handleActivate} />

              <div className="mt-8 w-full space-y-2">
                <div className="flex items-center gap-2 text-xs text-white/40 p-2.5 rounded-xl bg-white/[0.02] border border-white/[0.04]">
                  <span>📍</span>
                  <span>Your location will be shared automatically</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-white/40 p-2.5 rounded-xl bg-white/[0.02] border border-white/[0.04]">
                  <span>📞</span>
                  <span>Direct call to response team on activation</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-white/40 p-2.5 rounded-xl bg-white/[0.02] border border-white/[0.04]">
                  <span>🔒</span>
                  <span>3-second hold prevents accidental triggers</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right: Categories + History */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.25, duration: 0.5 }}
            className="lg:col-span-3 space-y-6"
          >
            {/* Emergency Category Selector */}
            <div>
              <h2 className="text-sm font-semibold text-white/60 mb-3 uppercase tracking-wider">
                Emergency Type
              </h2>
              <div className="space-y-3">
                {EMERGENCY_CATEGORIES.map((cat) => (
                  <CategoryCard key={cat.id} category={cat} />
                ))}
              </div>
            </div>
          </motion.div>
        </div>

        {/* SOS History */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35, duration: 0.5 }}
        >
          <h2 className="text-sm font-semibold text-white/60 mb-3 uppercase tracking-wider">
            SOS History
          </h2>
          {RECENT_SOS.length === 0 ? (
            <div className="text-center py-10 rounded-2xl bg-white/[0.02] border border-white/[0.06]">
              <p className="text-4xl mb-3">🛡️</p>
              <p className="text-white/40 text-sm">No SOS events recorded. Stay safe!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {RECENT_SOS.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center gap-4 p-4 rounded-2xl bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/[0.06]"
                >
                  <div className="w-12 h-12 rounded-xl bg-white/[0.04] flex items-center justify-center text-2xl flex-shrink-0">
                    {item.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-semibold text-sm">{item.type}</p>
                    <p className="text-white/40 text-xs">{item.date}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold border ${
                        item.status === "resolved"
                          ? "bg-green-500/10 text-green-400 border-green-500/20"
                          : item.status === "active"
                          ? "bg-red-500/10 text-red-400 border-red-500/20"
                          : "bg-white/[0.04] text-white/40 border-white/[0.06]"
                      }`}
                    >
                      {item.status.toUpperCase()}
                    </span>
                    <p className="text-white/30 text-xs mt-1">Response: {item.responseTime}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>

        {/* Footer info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.45, duration: 0.5 }}
          className="p-6 rounded-2xl bg-gradient-to-br from-amber-500/10 to-amber-600/5 border border-amber-500/20 text-center"
        >
          <h3 className="text-lg font-bold text-white mb-2">How SOS Works</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-4">
            {[
              { step: "1", icon: "👆", label: "Hold 3 Seconds", desc: "Press and hold the SOS button in the mobile app" },
              { step: "2", icon: "📞", label: "Call Initiated", desc: "Active call placed to HomeBuddy emergency team" },
              { step: "3", icon: "🚀", label: "Help Dispatched", desc: "Team dispatched to your registered address" },
            ].map((s) => (
              <div key={s.step} className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-xl">
                  {s.icon}
                </div>
                <p className="text-white font-semibold text-sm">{s.label}</p>
                <p className="text-white/40 text-xs">{s.desc}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </>
  );
}