"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";

// Types based on database schema
interface HealthReport {
  id: string;
  user_id: string;
  property_id: string;
  status: "generating" | "ready" | "failed";
  overall_score: number; // 0-100
  category_scores: CategoryScore[];
  risk_flags: RiskFlag[];
  recommendations: Recommendation[];
  summary: string;
  report_period_start: string;
  report_period_end: string;
  created_at: string;
}

interface CategoryScore {
  category: string;
  score: number;
  label: string;
  issues: string[];
}

interface RiskFlag {
  severity: "low" | "medium" | "high" | "critical";
  title: string;
  description: string;
  category: string;
}

interface Recommendation {
  priority: "low" | "medium" | "high" | "urgent";
  title: string;
  description: string;
  estimated_cost: number;
  category: string;
}

// Sample report for demonstration (TODO: Replace with API data)
const SAMPLE_REPORT: HealthReport = {
  id: "report_1",
  user_id: "user_123",
  property_id: "property_1",
  status: "ready",
  overall_score: 73,
  category_scores: [
    {
      category: "Plumbing",
      score: 85,
      label: "Good",
      issues: ["Minor tap leak in kitchen", "Water pressure slightly low"],
    },
    {
      category: "Electrical",
      score: 72,
      label: "Fair",
      issues: ["2 old switches need replacement", "Circuit breaker outdated"],
    },
    {
      category: "Structural",
      score: 90,
      label: "Excellent",
      issues: [],
    },
    {
      category: "Pest Control",
      score: 65,
      label: "Needs Attention",
      issues: ["Minor ant infestation in kitchen", "Termite signs in wooden door"],
    },
    {
      category: "Paint & Sealant",
      score: 58,
      label: "Poor",
      issues: ["Exterior paint peeling", "Bathroom sealant deteriorating"],
    },
  ],
  risk_flags: [
    {
      severity: "high",
      title: "Electrical Circuit Overload Risk",
      description: "Main circuit breaker is outdated (15+ years old). Risk of electrical fire during peak usage.",
      category: "Electrical",
    },
    {
      severity: "medium",
      title: "Termite Damage Detected",
      description: "Early signs of termite infestation found in main door frame. Could spread to other wooden structures.",
      category: "Pest Control",
    },
    {
      severity: "low",
      title: "Water Seepage Risk",
      description: "Bathroom sealant deteriorating. May cause water damage to walls if not addressed.",
      category: "Paint & Sealant",
    },
  ],
  recommendations: [
    {
      priority: "urgent",
      title: "Replace Main Circuit Breaker",
      description: "Immediately replace the 15-year-old circuit breaker to prevent electrical hazards.",
      estimated_cost: 3500,
      category: "Electrical",
    },
    {
      priority: "high",
      title: "Professional Termite Treatment",
      description: "Book professional anti-termite treatment to prevent structural damage.",
      estimated_cost: 2500,
      category: "Pest Control",
    },
    {
      priority: "medium",
      title: "Bathroom Resealing",
      description: "Reseal bathroom tiles and corners to prevent water seepage.",
      estimated_cost: 1200,
      category: "Paint & Sealant",
    },
    {
      priority: "low",
      title: "Replace Kitchen Tap",
      description: "Fix minor tap leak in kitchen to save water.",
      estimated_cost: 800,
      category: "Plumbing",
    },
  ],
  summary: "Your home is in fair condition with an overall health score of 73/100. The structural integrity is excellent, and plumbing is in good shape. However, immediate attention is required for the electrical system due to an outdated circuit breaker that poses a fire risk. Pest control treatment is recommended to address early termite signs. Regular maintenance will help improve your home's health score to 85+ within 6 months.",
  report_period_start: "2026-01-01",
  report_period_end: "2026-03-31",
  created_at: "2026-03-31T18:30:00Z",
};

// Helper function to get score color
function getScoreColor(score: number) {
  if (score >= 80) return "text-green-400";
  if (score >= 60) return "text-amber-400";
  if (score >= 40) return "text-orange-400";
  return "text-red-400";
}

// Helper function to get severity color
function getSeverityColor(severity: string) {
  switch (severity) {
    case "critical":
      return "bg-red-500/20 text-red-400 border-red-500/30";
    case "high":
      return "bg-orange-500/20 text-orange-400 border-orange-500/30";
    case "medium":
      return "bg-amber-500/20 text-amber-400 border-amber-500/30";
    case "low":
      return "bg-blue-500/20 text-blue-400 border-blue-500/30";
    default:
      return "bg-white/10 text-white/40 border-white/20";
  }
}

// Helper function to get priority color
function getPriorityColor(priority: string) {
  switch (priority) {
    case "urgent":
      return "bg-red-500/20 text-red-400 border-red-500/30";
    case "high":
      return "bg-orange-500/20 text-orange-400 border-orange-500/30";
    case "medium":
      return "bg-amber-500/20 text-amber-400 border-amber-500/30";
    case "low":
      return "bg-blue-500/20 text-blue-400 border-blue-500/30";
    default:
      return "bg-white/10 text-white/40 border-white/20";
  }
}

export default function HealthReportsPage() {
  const [selectedTab, setSelectedTab] = useState<"overview" | "risks" | "recommendations">("overview");
  const [report] = useState<HealthReport>(SAMPLE_REPORT);

  const handleDownloadPDF = () => {
    // TODO: Call API to generate and download PDF
    console.log("TODO: Download PDF report");
    alert("PDF download will be implemented with backend integration");
  };

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-white mb-2">
              Home Health Report
            </h1>
            <p className="text-white/40">
              Generated from technician inspections • {new Date(report.report_period_start).toLocaleDateString("en-IN", { month: "short", year: "numeric" })} - {new Date(report.report_period_end).toLocaleDateString("en-IN", { month: "short", year: "numeric" })}
            </p>
          </div>
          <button
            onClick={handleDownloadPDF}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold hover:from-amber-600 hover:to-amber-700 transition-all flex items-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            Download PDF
          </button>
        </div>
      </motion.div>

      {/* Overall Score Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.5 }}
        className="rounded-2xl p-8 bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/[0.06]"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Score Ring */}
          <div className="flex flex-col items-center justify-center">
            <div className="relative w-48 h-48 mb-4">
              <svg className="w-full h-full -rotate-90">
                <circle
                  cx="96"
                  cy="96"
                  r="88"
                  stroke="currentColor"
                  strokeWidth="12"
                  fill="none"
                  className="text-white/10"
                />
                <circle
                  cx="96"
                  cy="96"
                  r="88"
                  stroke="currentColor"
                  strokeWidth="12"
                  fill="none"
                  strokeDasharray={`${2 * Math.PI * 88}`}
                  strokeDashoffset={`${2 * Math.PI * 88 * (1 - report.overall_score / 100)}`}
                  className={getScoreColor(report.overall_score)}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <div className={`text-6xl font-bold ${getScoreColor(report.overall_score)}`}>
                  {report.overall_score}
                </div>
                <div className="text-sm text-white/40">out of 100</div>
              </div>
            </div>
            <h3 className="text-xl font-bold text-white mb-1">Overall Health Score</h3>
            <p className="text-sm text-white/40 text-center">
              {report.overall_score >= 80
                ? "Excellent Condition"
                : report.overall_score >= 60
                  ? "Good Condition"
                  : report.overall_score >= 40
                    ? "Needs Attention"
                    : "Poor Condition"}
            </p>
          </div>

          {/* Summary */}
          <div className="md:col-span-2">
            <h3 className="text-xl font-bold text-white mb-4">AI-Generated Summary</h3>
            <p className="text-white/70 leading-relaxed mb-6">{report.summary}</p>
            
            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]">
                <p className="text-sm text-white/40 mb-1">Risk Flags</p>
                <p className="text-2xl font-bold text-white">{report.risk_flags.length}</p>
              </div>
              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]">
                <p className="text-sm text-white/40 mb-1">Recommendations</p>
                <p className="text-2xl font-bold text-white">{report.recommendations.length}</p>
              </div>
              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]">
                <p className="text-sm text-white/40 mb-1">Estimated Cost</p>
                <p className="text-2xl font-bold text-white">
                  ₹{report.recommendations.reduce((sum, r) => sum + r.estimated_cost, 0).toLocaleString()}
                </p>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Tabs */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.5 }}
        className="flex items-center gap-2 p-1 rounded-2xl bg-white/[0.02] border border-white/[0.06] w-fit"
      >
        {(["overview", "risks", "recommendations"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setSelectedTab(tab)}
            className={`relative px-6 py-2.5 rounded-xl text-sm font-medium transition-all ${
              selectedTab === tab
                ? "text-white"
                : "text-white/50 hover:text-white/70"
            }`}
          >
            {selectedTab === tab && (
              <motion.div
                layoutId="activeTab"
                className="absolute inset-0 rounded-xl bg-amber-500/20 border border-amber-500/30"
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
              />
            )}
            <span className="relative z-10 capitalize">{tab}</span>
          </button>
        ))}
      </motion.div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        {selectedTab === "overview" && (
          <motion.div
            key="overview"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            {/* Category Scores */}
            <div className="rounded-2xl p-6 bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/[0.06]">
              <h2 className="text-xl font-bold text-white mb-6">Category Breakdown</h2>
              <div className="space-y-4">
                {report.category_scores.map((category, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-white font-medium">{category.category}</span>
                        <span className="text-sm text-white/40 ml-2">• {category.label}</span>
                      </div>
                      <span className={`text-lg font-bold ${getScoreColor(category.score)}`}>
                        {category.score}/100
                      </span>
                    </div>
                    <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden">
                      <div
                        className={`h-full ${getScoreColor(category.score)} bg-current transition-all`}
                        style={{ width: `${category.score}%` }}
                      />
                    </div>
                    {category.issues.length > 0 && (
                      <div className="ml-4 space-y-1">
                        {category.issues.map((issue, i) => (
                          <p key={i} className="text-sm text-white/40">
                            • {issue}
                          </p>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {selectedTab === "risks" && (
          <motion.div
            key="risks"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="rounded-2xl p-6 bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/[0.06]"
          >
            <h2 className="text-xl font-bold text-white mb-6">Risk Flags & Vulnerabilities</h2>
            <div className="space-y-4">
              {report.risk_flags.map((risk, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-lg font-semibold text-white">{risk.title}</h3>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold border ${getSeverityColor(
                        risk.severity
                      )}`}
                    >
                      {risk.severity.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-sm text-white/60 mb-2">{risk.description}</p>
                  <p className="text-xs text-white/40">Category: {risk.category}</p>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {selectedTab === "recommendations" && (
          <motion.div
            key="recommendations"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="rounded-2xl p-6 bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/[0.06]"
          >
            <h2 className="text-xl font-bold text-white mb-6">Priority Recommendations</h2>
            <div className="space-y-4">
              {report.recommendations.map((rec, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-lg font-semibold text-white">{rec.title}</h3>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold border ${getPriorityColor(
                        rec.priority
                      )}`}
                    >
                      {rec.priority.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-sm text-white/60 mb-3">{rec.description}</p>
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-white/40">Category: {rec.category}</p>
                    <p className="text-sm font-semibold text-amber-400">
                      Est. Cost: ₹{rec.estimated_cost.toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Info Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.5 }}
        className="rounded-2xl p-6 bg-blue-500/10 border border-blue-500/20"
      >
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
            <svg
              className="w-6 h-6 text-blue-400"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-blue-400 mb-2">
              How Health Reports Work
            </h3>
            <p className="text-sm text-white/60 leading-relaxed">
              Our technicians conduct thorough inspections during each service visit. This report is generated from <strong>3 months of inspection data</strong> collected by professionals. The AI analyzes patterns, identifies risks, and provides actionable recommendations to keep your home in top condition. Reports are generated quarterly and updated as new inspection data becomes available.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}