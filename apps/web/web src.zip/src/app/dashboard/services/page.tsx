"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import Link from "next/link";

// Service Type
interface Service {
  id: string;
  name: string;
  category: string;
  description: string;
  icon: string;
  basePrice: number;
  frequency: string;
  duration: string;
  includes: string[];
  excludes?: string[];
  isPopular?: boolean;
  isFree?: boolean;
}

// All 9 Services from HomeBuddy Document
const SERVICES: Service[] = [
  {
    id: "plumbing",
    name: "Plumbing Inspection",
    category: "Plumbing",
    description: "Comprehensive plumbing check including pipes, taps, drainage, and leakage detection",
    icon: "🔧",
    basePrice: 599,
    frequency: "Every Month",
    duration: "1-2 hours",
    includes: [
      "Labour charges included",
      "Pipe & tap inspection",
      "Leakage detection",
      "Drainage check",
      "Water pressure testing",
    ],
    excludes: [
      "Material costs (pipes, taps, fittings)",
      "Parts replacement charges",
    ],
    isPopular: true,
  },
  {
    id: "electrical",
    name: "Electrical Safety Check",
    category: "Electrical",
    description: "Complete electrical system inspection for safety and performance optimization",
    icon: "⚡",
    basePrice: 699,
    frequency: "Every Month",
    duration: "1-2 hours",
    includes: [
      "Labour charges included",
      "Wiring inspection",
      "Switch & socket check",
      "Circuit breaker testing",
      "Voltage testing",
    ],
    excludes: [
      "Material costs (switches, sockets, wiring)",
      "Electrical components",
    ],
    isPopular: true,
  },
  {
    id: "pest-control",
    name: "Pest Control Treatment",
    category: "Pest Control",
    description: "Professional pest control treatment for complete home protection",
    icon: "🐛",
    basePrice: 1299,
    frequency: "Every 6 Months",
    duration: "2-3 hours",
    includes: [
      "All materials included",
      "Complete treatment",
      "Kitchen treatment",
      "Bathroom treatment",
      "Bedroom treatment",
      "6-month warranty",
    ],
  },
  {
    id: "paint-sealant",
    name: "Paint & Sealant",
    category: "Paint & Sealant",
    description: "Complete painting and waterproofing solution for your home",
    icon: "🎨",
    basePrice: 4999,
    frequency: "Once a Year",
    duration: "Full day",
    includes: [
      "All materials included",
      "Paint & primer",
      "Sealant application",
      "Labour charges",
      "Surface preparation",
      "1-year warranty",
    ],
  },
  {
    id: "smart-doorbell",
    name: "Smart Doorbell",
    category: "Smart Home",
    description: "AI-powered smart doorbell with 24/7 monitoring and quick commerce integration",
    icon: "🔔",
    basePrice: 0,
    frequency: "Always On",
    duration: "Instant setup",
    includes: [
      "Free with ads",
      "24/7 monitoring",
      "Ring detection",
      "Visitor detection",
      "Quick commerce integration",
      "Real-time power status",
    ],
    isFree: true,
  },
  {
    id: "cctv",
    name: "CCTV Installation",
    category: "Security",
    description: "Professional CCTV installation service for complete home security",
    icon: "📹",
    basePrice: 0,
    frequency: "On Demand",
    duration: "3-4 hours",
    includes: [
      "Free installation labour",
      "Professional setup",
      "Camera positioning",
      "DVR/NVR configuration",
    ],
    excludes: [
      "CCTV equipment cost",
      "Cameras, DVR/NVR",
      "Cables & accessories",
    ],
  },
  {
    id: "tank-cleaning",
    name: "Water Tank Cleaning",
    category: "Sanitation",
    description: "Professional water tank cleaning for safe and hygienic water supply",
    icon: "💧",
    basePrice: 899,
    frequency: "Every 6 Months",
    duration: "2-3 hours",
    includes: [
      "Complete tank cleaning",
      "Descaling & scrubbing",
      "Disinfection",
      "Water quality check",
      "Before/after photos",
    ],
  },
  {
    id: "ai-interior",
    name: "AI Interior Designer",
    category: "Design",
    description: "Personal AI-powered interior design suggestions for your home",
    icon: "✨",
    basePrice: 499,
    frequency: "On Demand",
    duration: "Instant",
    includes: [
      "AI-powered designs",
      "Room layout ideas",
      "Color palette suggestions",
      "Furniture arrangement",
      "3D visualizations",
      "Personalized recommendations",
    ],
    isPopular: true,
  },
  {
    id: "health-report",
    name: "Home Health Report",
    category: "Analytics",
    description: "Comprehensive AI-generated health report based on 3 months of inspection data",
    icon: "📊",
    basePrice: 0,
    frequency: "Every 3 Months",
    duration: "Auto-generated",
    includes: [
      "Included in subscription",
      "Overall health score (0-100)",
      "Category-wise breakdown",
      "Risk flags & alerts",
      "Priority recommendations",
      "Cost estimates",
      "Historical trends",
    ],
    isFree: true,
  },
];

// Categories for filtering
const CATEGORIES = [
  "All Services",
  "Plumbing",
  "Electrical",
  "Pest Control",
  "Paint & Sealant",
  "Smart Home",
  "Security",
  "Sanitation",
  "Design",
  "Analytics",
];

// Service Card Component
function ServiceCard({ service }: { service: Service }) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="rounded-2xl p-6 bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/[0.06] hover:border-amber-500/20 transition-all relative overflow-hidden group"
    >
      {/* Badges */}
      <div className="absolute top-4 right-4 flex gap-2">
        {service.isPopular && (
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
            POPULAR
          </span>
        )}
        {service.isFree && (
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-green-500/20 text-green-400 border border-green-500/30">
            FREE
          </span>
        )}
      </div>

      {/* Icon & Title */}
      <div className="flex items-start gap-4 mb-4">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-600/10 flex items-center justify-center text-4xl group-hover:scale-110 transition-transform">
          {service.icon}
        </div>
        <div className="flex-1">
          <h3 className="text-xl font-bold text-white mb-1">{service.name}</h3>
          <p className="text-sm text-white/40">{service.category}</p>
        </div>
      </div>

      {/* Description */}
      <p className="text-sm text-white/60 mb-4">{service.description}</p>

      {/* Details Grid */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]">
          <p className="text-xs text-white/40 mb-1">Frequency</p>
          <p className="text-sm text-white font-medium">{service.frequency}</p>
        </div>
        <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]">
          <p className="text-xs text-white/40 mb-1">Duration</p>
          <p className="text-sm text-white font-medium">{service.duration}</p>
        </div>
      </div>

      {/* Includes/Excludes */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="mb-4 overflow-hidden"
          >
            <div className="space-y-3">
              {/* Includes */}
              <div>
                <p className="text-xs font-semibold text-green-400 mb-2">
                  ✓ What's Included
                </p>
                <div className="space-y-1">
                  {service.includes.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-white/60">
                      <svg
                        className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Excludes */}
              {service.excludes && service.excludes.length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-red-400 mb-2">
                    ✗ Not Included
                  </p>
                  <div className="space-y-1">
                    {service.excludes.map((item, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-white/60">
                        <svg
                          className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5"
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path
                            fillRule="evenodd"
                            d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                            clipRule="evenodd"
                          />
                        </svg>
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Expand/Collapse Button */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full mb-4 text-xs text-amber-400 hover:text-amber-300 transition-colors flex items-center justify-center gap-1"
      >
        {isExpanded ? "Show Less" : "Show Details"}
        <svg
          className={`w-4 h-4 transition-transform ${isExpanded ? "rotate-180" : ""}`}
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {/* Price & Book Button */}
      <div className="flex items-center justify-between pt-4 border-t border-white/[0.06]">
        <div>
          {service.isFree ? (
            <span className="text-2xl font-bold text-green-400">FREE</span>
          ) : service.basePrice === 0 ? (
            <span className="text-sm text-white/40">Installation Free*</span>
          ) : (
            <div>
              <span className="text-2xl font-bold text-white">₹{service.basePrice}</span>
              <span className="text-sm text-white/40 ml-2">/{service.frequency.toLowerCase()}</span>
            </div>
          )}
        </div>
        <Link href={`/dashboard/services/${service.id}/book` as never}>
          <button className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold hover:from-amber-600 hover:to-amber-700 transition-all">
            Book Now
          </button>
        </Link>
      </div>
    </motion.div>
  );
}

// Main Services Catalog Page
export default function ServicesPage() {
  const [selectedCategory, setSelectedCategory] = useState("All Services");
  const [searchQuery, setSearchQuery] = useState("");
  const [priceFilter, setPriceFilter] = useState<"all" | "free" | "paid">("all");

  // Filter services
  const filteredServices = SERVICES.filter((service) => {
    const matchesCategory =
      selectedCategory === "All Services" || service.category === selectedCategory;

    const matchesSearch =
      searchQuery === "" ||
      service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.category.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesPrice =
      priceFilter === "all" ||
      (priceFilter === "free" && service.isFree) ||
      (priceFilter === "paid" && !service.isFree);

    return matchesCategory && matchesSearch && matchesPrice;
  });

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold tracking-tight text-white mb-2">
          Service Catalog
        </h1>
        <p className="text-white/40">
          Professional home services tailored for Indian homeowners
        </p>
      </motion.div>

      {/* Stats Cards */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.5 }}
        className="grid grid-cols-1 sm:grid-cols-3 gap-4"
      >
        <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/10 to-amber-600/5 border border-amber-500/20">
          <p className="text-sm text-amber-400 mb-1">Total Services</p>
          <p className="text-3xl font-bold text-white">{SERVICES.length}</p>
        </div>
        <div className="p-4 rounded-2xl bg-gradient-to-br from-green-500/10 to-green-600/5 border border-green-500/20">
          <p className="text-sm text-green-400 mb-1">Free Services</p>
          <p className="text-3xl font-bold text-white">
            {SERVICES.filter((s) => s.isFree).length}
          </p>
        </div>
        <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500/10 to-blue-600/5 border border-blue-500/20">
          <p className="text-sm text-blue-400 mb-1">Starting From</p>
          <p className="text-3xl font-bold text-white">₹0</p>
        </div>
      </motion.div>

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.5 }}
        className="space-y-4"
      >
        {/* Search & Price Filter */}
        <div className="flex flex-col sm:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <svg
              className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
            <input
              type="text"
              placeholder="Search services..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-xl bg-white/[0.02] border border-white/[0.06] text-white placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors"
            />
          </div>

          {/* Price Filter */}
          <div className="flex gap-2 p-1 rounded-xl bg-white/[0.02] border border-white/[0.06] w-fit">
            {(["all", "free", "paid"] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setPriceFilter(filter)}
                className={`relative px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  priceFilter === filter
                    ? "text-white"
                    : "text-white/50 hover:text-white/70"
                }`}
              >
                {priceFilter === filter && (
                  <motion.div
                    layoutId="priceFilter"
                    className="absolute inset-0 rounded-lg bg-amber-500/20 border border-amber-500/30"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
                <span className="relative z-10 capitalize">{filter}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {CATEGORIES.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
                selectedCategory === category
                  ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                  : "bg-white/[0.02] text-white/60 border border-white/[0.06] hover:bg-white/[0.04]"
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </motion.div>

      {/* Services Grid */}
      <motion.div layout className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <AnimatePresence mode="popLayout">
          {filteredServices.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="col-span-full text-center py-12 rounded-2xl bg-white/[0.02] border border-white/[0.06]"
            >
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold text-white mb-2">
                No services found
              </h3>
              <p className="text-white/40 mb-6">
                Try adjusting your search or filters
              </p>
              <button
                onClick={() => {
                  setSearchQuery("");
                  setSelectedCategory("All Services");
                  setPriceFilter("all");
                }}
                className="px-6 py-3 rounded-xl bg-amber-500/10 text-amber-400 font-semibold hover:bg-amber-500/20 transition-all"
              >
                Clear Filters
              </button>
            </motion.div>
          ) : (
            filteredServices.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))
          )}
        </AnimatePresence>
      </motion.div>

      {/* Footer CTA */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.5 }}
        className="mt-12 text-center p-8 rounded-2xl bg-gradient-to-br from-amber-500/10 to-amber-600/5 border border-amber-500/20"
      >
        <h3 className="text-2xl font-bold text-white mb-2">
          Need Help Choosing?
        </h3>
        <p className="text-white/60 mb-6">
          Our experts can help you select the right services for your home
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href={"/dashboard/subscription" as never}>
            <button className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold hover:from-amber-600 hover:to-amber-700 transition-all">
              View Plans
            </button>
          </Link>
          <Link href={"/dashboard/settings" as never}>
            <button className="px-6 py-3 rounded-xl bg-white/[0.04] text-white font-semibold hover:bg-white/[0.08] transition-all">
              Contact Support
            </button>
          </Link>
        </div>
      </motion.div>
    </div>
  );
}