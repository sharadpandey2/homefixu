"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "motion/react";
import { authClient } from "@/lib/auth-client"; // Adjust path if your auth-client is elsewhere

// ─── Mock Data (re
//place with API calls later) ───────────────────────────────────
const HEALTH_SCORE = 78;
const CATEGORY_SCORES = [
  { name: "Plumbing", score: 85, color: "#3B8BD4" },
  { name: "Electrical", score: 72, color: "#E8A741" },
  { name: "Pest Control", score: 90, color: "#1D9E75" },
  { name: "Paint & Sealant", score: 65, color: "#D85A30" },
  { name: "Tank", score: 80, color: "#534AB7" },
  { name: "Structure", score: 75, color: "#D4537E" },
];

const UPCOMING_BOOKINGS = [
  { id: "1", service: "Plumbing Inspection", date: "Apr 2, 2026", time: "09:00-11:00", status: "confirmed" },
  { id: "2", service: "Pest Control", date: "Apr 10, 2026", time: "14:00-16:00", status: "pending" },
];

const SERVICE_DUES = [
  { service: "Electrical", dueDate: "Apr 5, 2026", daysLeft: 10, frequency: "Monthly" },
  { service: "Tank Cleaning", dueDate: "Apr 15, 2026", daysLeft: 20, frequency: "6 Months" },
  { service: "Paint & Sealant", dueDate: "Jun 1, 2026", daysLeft: 67, frequency: "Yearly" },
];

const RECENT_ACTIVITY = [
  { text: "Plumbing service completed", time: "2 days ago", type: "success" },
  { text: "Health report generated", time: "1 week ago", type: "info" },
  { text: "Payment of \u20B9999 received", time: "1 week ago", type: "payment" },
  { text: "Electrical inspection due soon", time: "3 days ago", type: "warning" },
];

const QUICK_SERVICES = [
  { name: "Plumbing", icon: "\uD83D\uDD27", href: "/dashboard/services", color: "#3B8BD4" },
  { name: "Electrical", icon: "\u26A1", href: "/dashboard/services", color: "#E8A741" },
  { name: "Pest Control", icon: "\uD83D\uDC1B", href: "/dashboard/services", color: "#1D9E75" },
  { name: "Paint", icon: "\uD83C\uDFA8", href: "/dashboard/services", color: "#D85A30" },
  { name: "Doorbell", icon: "\uD83D\uDD14", href: "/dashboard/doorbell", color: "#534AB7" },
  { name: "CCTV", icon: "\uD83D\uDCF9", href: "/dashboard/cctv", color: "#D4537E" },
  { name: "Tank Clean", icon: "\uD83D\uDCA7", href: "/dashboard/services", color: "#0F6E56" },
  { name: "AI Interior", icon: "\u2728", href: "/dashboard/interior", color: "#993556" },
];

// ─── Score Ring Component ────────────────────────────────────────────────────────
function ScoreRing({ score, size = 160 }: { score: number; size?: number }) {
  const stroke = 10;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;
  const scoreColor = score >= 80 ? "#1D9E75" : score >= 60 ? "#E8A741" : "#E24B4A";

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none"
          stroke="rgba(255,255,255,0.06)" strokeWidth={stroke} />
        <motion.circle cx={size / 2} cy={size / 2} r={radius} fill="none"
          stroke={scoreColor} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1.5, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <motion.span className="text-4xl font-extrabold text-white"
          initial={{ opacity: 0, scale: 0.5 }} animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5, duration: 0.5 }}>
          {score}
        </motion.span>
        <span className="text-xs font-medium text-white/40">out of 100</span>
      </div>
    </div>
  );
}

// ─── Category Bar ────────────────────────────────────────────────────────────────
function CategoryBar({ name, score, color, delay }: { name: string; score: number; color: string; delay: number }) {
  return (
    <motion.div className="flex items-center gap-3"
      initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
      transition={{ delay, duration: 0.4 }}>
      <span className="w-20 text-xs text-white/50 truncate">{name}</span>
      <div className="flex-1 h-2 rounded-full bg-white/[0.06] overflow-hidden">
        <motion.div className="h-full rounded-full"
          style={{ background: color }}
          initial={{ width: 0 }}
          animate={{ width: `${score}%` }}
          transition={{ delay: delay + 0.2, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        />
      </div>
      <span className="w-8 text-right text-xs font-semibold text-white/70">{score}</span>
    </motion.div>
  );
}

// ─── Card Wrapper ────────────────────────────────────────────────────────────────
function Card({ children, className = "", delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      className={`rounded-2xl p-5 ${className}`}
      style={{
        background: "linear-gradient(135deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0.02) 100%)",
        border: "1px solid rgba(255,255,255,0.06)",
      }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}

// ─── Main Dashboard ──────────────────────────────────────────────────────────────
export default function DashboardPage() {
  const { data: session } = authClient.useSession();
  const userName = session?.user?.name?.split(" ")[0] ?? "there";
  const [sosActive, setSosActive] = useState(false);
  const [sosTimer, setSosTimer] = useState<NodeJS.Timeout | null>(null);

  function handleSosDown() {
    const timer = setTimeout(() => {
      setSosActive(true);
      // TODO: trigger SOS API call
    }, 3000);
    setSosTimer(timer);
  }

  function handleSosUp() {
    if (sosTimer) {
      clearTimeout(sosTimer);
      setSosTimer(null);
    }
  }

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      {/* Greeting */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}>
        <h1 className="text-2xl font-bold tracking-tight text-white">
          Good {new Date().getHours() < 12 ? "morning" : new Date().getHours() < 17 ? "afternoon" : "evening"}, {userName}
        </h1>
        <p className="mt-1 text-sm text-white/40">Here&apos;s your home health overview</p>
      </motion.div>

      {/* Top row: Health Score + SOS */}
      <div className="grid gap-5 lg:grid-cols-3">
        {/* Health Score Card */}
        <Card className="lg:col-span-2" delay={0.1}>
          <div className="flex flex-col gap-6 sm:flex-row sm:items-center">
            <div className="flex flex-col items-center">
              <ScoreRing score={HEALTH_SCORE} />
              <p className="mt-2 text-xs font-medium text-white/40">Home health score</p>
            </div>
            <div className="flex-1 space-y-3">
              <h3 className="text-sm font-semibold text-white/60 uppercase tracking-wider">Category breakdown</h3>
              {CATEGORY_SCORES.map((cat, i) => (
                <CategoryBar key={cat.name} {...cat} delay={0.2 + i * 0.08} />
              ))}
            </div>
          </div>
        </Card>

        {/* SOS Button Card */}
        <Card delay={0.2}>
          <div className="flex h-full flex-col items-center justify-center gap-4 py-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white/40">Emergency</h3>
            <motion.button
              className="relative flex h-28 w-28 items-center justify-center rounded-full text-white"
              style={{
                background: sosActive
                  ? "linear-gradient(135deg, #E24B4A, #A32D2D)"
                  : "linear-gradient(135deg, #E24B4A80, #A32D2D80)",
                boxShadow: sosActive
                  ? "0 0 40px rgba(226,75,74,0.5), 0 0 80px rgba(226,75,74,0.2)"
                  : "0 0 20px rgba(226,75,74,0.15)",
              }}
              onPointerDown={handleSosDown}
              onPointerUp={handleSosUp}
              onPointerLeave={handleSosUp}
              whileTap={{ scale: 0.95 }}
              animate={sosActive ? { scale: [1, 1.05, 1] } : {}}
              transition={sosActive ? { repeat: Infinity, duration: 0.8 } : {}}
            >
              {/* Pulse rings */}
              <motion.div className="absolute inset-0 rounded-full border-2 border-red-500/30"
                animate={{ scale: [1, 1.5], opacity: [0.5, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />
              <motion.div className="absolute inset-0 rounded-full border-2 border-red-500/20"
                animate={{ scale: [1, 1.8], opacity: [0.3, 0] }}
                transition={{ duration: 1.5, delay: 0.3, repeat: Infinity }}
              />
              <div className="text-center">
                <span className="text-2xl font-extrabold">SOS</span>
                <p className="text-[10px] text-white/60 mt-0.5">Hold 3 sec</p>
              </div>
            </motion.button>
            <p className="text-center text-xs text-white/30">
              {sosActive ? "Emergency triggered! Help is on the way." : "Press and hold for 3 seconds"}
            </p>
          </div>
        </Card>
      </div>

      {/* Quick Services */}
      <Card delay={0.3}>
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-white/40">Quick services</h3>
        <div className="grid grid-cols-4 gap-3 sm:grid-cols-8">
          {QUICK_SERVICES.map((svc, i) => (
            <Link key={svc.name} href={svc.href as never} className="no-underline">
              <motion.div
                className="flex flex-col items-center gap-2 rounded-xl p-3 transition-colors hover:bg-white/[0.04]"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.4 + i * 0.05, duration: 0.3 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-xl text-lg"
                  style={{ background: `${svc.color}15`, border: `1px solid ${svc.color}25` }}>
                  {svc.icon}
                </div>
                <span className="text-[11px] font-medium text-white/50 text-center leading-tight">{svc.name}</span>
              </motion.div>
            </Link>
          ))}
        </div>
      </Card>

      {/* Middle row: Upcoming Bookings + Service Dues */}
      <div className="grid gap-5 lg:grid-cols-2">
        {/* Upcoming Bookings */}
        <Card delay={0.4}>
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white/40">Upcoming bookings</h3>
            <Link href={"/dashboard/bookings" as never} className="text-xs font-medium text-amber-400/70 no-underline hover:text-amber-300">
              View all
            </Link>
          </div>
          <div className="space-y-3">
            {UPCOMING_BOOKINGS.map((booking, i) => (
              <motion.div key={booking.id}
                className="flex items-center justify-between rounded-xl p-3"
                style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.04)" }}
                initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + i * 0.1, duration: 0.4 }}>
                <div>
                  <p className="text-sm font-medium text-white">{booking.service}</p>
                  <p className="text-xs text-white/35">{booking.date} \u00B7 {booking.time}</p>
                </div>
                <span className={`rounded-lg px-2.5 py-1 text-[11px] font-semibold ${
                  booking.status === "confirmed"
                    ? "bg-emerald-500/15 text-emerald-400"
                    : "bg-amber-500/15 text-amber-400"
                }`}>
                  {booking.status}
                </span>
              </motion.div>
            ))}
            {UPCOMING_BOOKINGS.length === 0 && (
              <p className="py-6 text-center text-sm text-white/25">No upcoming bookings</p>
            )}
          </div>
        </Card>

        {/* Service Dues */}
        <Card delay={0.5}>
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white/40">Service dues</h3>
            <Link href={"/dashboard/services" as never} className="text-xs font-medium text-amber-400/70 no-underline hover:text-amber-300">
              View all
            </Link>
          </div>
          <div className="space-y-3">
            {SERVICE_DUES.map((due, i) => (
              <motion.div key={due.service}
                className="flex items-center justify-between rounded-xl p-3"
                style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.04)" }}
                initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 + i * 0.1, duration: 0.4 }}>
                <div>
                  <p className="text-sm font-medium text-white">{due.service}</p>
                  <p className="text-xs text-white/35">{due.frequency} \u00B7 Due: {due.dueDate}</p>
                </div>
                <span className={`rounded-lg px-2.5 py-1 text-[11px] font-semibold ${
                  due.daysLeft <= 7
                    ? "bg-red-500/15 text-red-400"
                    : due.daysLeft <= 14
                      ? "bg-amber-500/15 text-amber-400"
                      : "bg-white/[0.06] text-white/40"
                }`}>
                  {due.daysLeft}d left
                </span>
              </motion.div>
            ))}
          </div>
        </Card>
      </div>

      {/* Bottom row: Recent Activity + Subscription */}
      <div className="grid gap-5 lg:grid-cols-3">
        {/* Recent Activity */}
        <Card className="lg:col-span-2" delay={0.6}>
          <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-white/40">Recent activity</h3>
          <div className="space-y-3">
            {RECENT_ACTIVITY.map((activity, i) => (
              <motion.div key={i}
                className="flex items-center gap-3"
                initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 + i * 0.08, duration: 0.4 }}>
                <div className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg ${
                  activity.type === "success" ? "bg-emerald-500/15" :
                  activity.type === "info" ? "bg-blue-500/15" :
                  activity.type === "payment" ? "bg-amber-500/15" :
                  "bg-red-500/15"
                }`}>
                  {activity.type === "success" && (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#34d399" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
                  )}
                  {activity.type === "info" && (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                  )}
                  {activity.type === "payment" && (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                  )}
                  {activity.type === "warning" && (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#f87171" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/></svg>
                  )}
                </div>
                <div className="flex-1">
                  <p className="text-sm text-white/70">{activity.text}</p>
                </div>
                <span className="text-xs text-white/25">{activity.time}</span>
              </motion.div>
            ))}
          </div>
        </Card>

        {/* Subscription Card */}
        <Card delay={0.7}>
          <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-white/40">Your plan</h3>
          <div className="flex flex-col items-center gap-3 py-2">
            <div className="rounded-xl px-4 py-1.5 text-xs font-bold uppercase tracking-wider"
              style={{ background: "linear-gradient(135deg, rgba(232,167,65,0.2), rgba(232,167,65,0.08))", color: "#E8A741" }}>
              Pro Plan
            </div>
            <div className="text-center">
              <span className="text-3xl font-extrabold text-white">\u20B9999</span>
              <span className="text-sm text-white/30">/mo</span>
            </div>
            <div className="w-full space-y-2 mt-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-white/40">Services used</span>
                <span className="text-white/70">3 / 5</span>
              </div>
              <div className="h-1.5 rounded-full bg-white/[0.06] overflow-hidden">
                <motion.div className="h-full rounded-full"
                  style={{ background: "linear-gradient(90deg, #E8A741, #D4872D)" }}
                  initial={{ width: 0 }}
                  animate={{ width: "60%" }}
                  transition={{ delay: 0.9, duration: 0.8 }}
                />
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-white/40">Renews</span>
                <span className="text-white/70">Apr 15, 2026</span>
              </div>
            </div>
            <Link href={"/dashboard/settings" as never}
              className="mt-2 w-full rounded-xl py-2.5 text-center text-xs font-semibold text-amber-400/80 no-underline transition-colors hover:bg-amber-500/10"
              style={{ border: "1px solid rgba(232,167,65,0.2)" }}>
              Manage subscription
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
}