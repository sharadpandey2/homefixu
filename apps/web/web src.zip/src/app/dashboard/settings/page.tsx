"use client";

import { useState, useEffect } from "react";
import { motion } from "motion/react";

// Types based on Better Auth users table from document
interface User {
  id: string;
  name: string;
  email: string;
  email_verified: boolean;
  phone?: string;
  image?: string;
  created_at: string;
  updated_at: string;
}

interface NotificationSettings {
  emailNotifications: boolean;
  smsNotifications: boolean;
  pushNotifications: boolean;
  bookingReminders: boolean;
  reportReady: boolean;
  packageExpiry: boolean;
}

export default function SettingsPage() {
  // User state - will be fetched from Better Auth session
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Form states
  const [profileData, setProfileData] = useState({
    name: "",
    phone: "",
  });
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [profileErrors, setProfileErrors] = useState<Record<string, string>>({});

  // Password change state
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [passwordErrors, setPasswordErrors] = useState<Record<string, string>>({});

  // Email verification state
  const [isVerifyingEmail, setIsVerifyingEmail] = useState(false);
  const [verificationSent, setVerificationSent] = useState(false);

  // Notification settings
  const [notifications, setNotifications] = useState<NotificationSettings>({
    emailNotifications: true,
    smsNotifications: false,
    pushNotifications: true,
    bookingReminders: true,
    reportReady: true,
    packageExpiry: true,
  });

  // Fetch user data from Better Auth session
  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    setIsLoading(true);
    try {
      // Fetch actual user from Better Auth session
      const response = await fetch('/api/auth/get-session');
      const data = await response.json();
      
      if (data && data.user) {
        const userData: User = {
          id: data.user.id,
          name: data.user.name,
          email: data.user.email,
          email_verified: data.user.email_verified || false,
          phone: data.user.phone || "",
          image: data.user.image,
          created_at: data.user.created_at || new Date().toISOString(),
          updated_at: data.user.updated_at || new Date().toISOString(),
        };
        
        setUser(userData);
        setProfileData({
          name: userData.name,
          phone: userData.phone || "",
        });
      } else {
        console.error("No user session found");
        // Redirect to login if no session
        window.location.href = '/login';
      }
      
      setIsLoading(false);
    } catch (error) {
      console.error("Failed to fetch user:", error);
      setIsLoading(false);
      // Optionally redirect to login on error
      // window.location.href = '/login';
    }
  };

  // Profile update handlers
  const handleProfileEdit = () => {
    setIsEditingProfile(true);
  };

  const validateProfile = () => {
    const errors: Record<string, string> = {};
    if (!profileData.name.trim()) {
      errors.name = "Name is required";
    }
    if (profileData.phone && !/^\+?[\d\s-]{10,15}$/.test(profileData.phone)) {
      errors.phone = "Invalid phone number";
    }
    setProfileErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleProfileSave = async () => {
    if (!validateProfile()) return;

    try {
      // TODO: Call API to update user profile
      // const response = await fetch('/api/users/update-profile', {
      //   method: 'PATCH',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(profileData),
      // });
      
      console.log("TODO: Update profile via API", profileData);
      
      setUser({ ...user!, ...profileData, updated_at: new Date().toISOString() });
      setIsEditingProfile(false);
      alert("Profile updated successfully!");
    } catch (error) {
      console.error("Failed to update profile:", error);
      alert("Failed to update profile. Please try again.");
    }
  };

  const handleProfileCancel = () => {
    setProfileData({
      name: user?.name || "",
      phone: user?.phone || "",
    });
    setIsEditingProfile(false);
    setProfileErrors({});
  };

  // Email verification handlers
  const handleSendVerification = async () => {
    setIsVerifyingEmail(true);
    try {
      // TODO: Call Better Auth email verification endpoint
      // const response = await fetch('/api/auth/send-verification-email', {
      //   method: 'POST',
      // });
      
      console.log("TODO: Send verification email via Better Auth");
      
      setTimeout(() => {
        setVerificationSent(true);
        setIsVerifyingEmail(false);
        alert("Verification email sent! Check your inbox.");
      }, 1000);
    } catch (error) {
      console.error("Failed to send verification:", error);
      setIsVerifyingEmail(false);
      alert("Failed to send verification email. Please try again.");
    }
  };

  // Password change handlers
  const validatePassword = () => {
    const errors: Record<string, string> = {};
    if (!passwordData.currentPassword) {
      errors.currentPassword = "Current password is required";
    }
    if (!passwordData.newPassword) {
      errors.newPassword = "New password is required";
    } else if (passwordData.newPassword.length < 8) {
      errors.newPassword = "Password must be at least 8 characters";
    }
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      errors.confirmPassword = "Passwords do not match";
    }
    setPasswordErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handlePasswordChange = async () => {
    if (!validatePassword()) return;

    setIsChangingPassword(true);
    try {
      // TODO: Call Better Auth password change endpoint
      // const response = await fetch('/api/auth/reset-password', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({
      //     currentPassword: passwordData.currentPassword,
      //     newPassword: passwordData.newPassword,
      //   }),
      // });
      
      console.log("TODO: Change password via Better Auth");
      
      setTimeout(() => {
        setPasswordData({
          currentPassword: "",
          newPassword: "",
          confirmPassword: "",
        });
        setIsChangingPassword(false);
        alert("Password changed successfully!");
      }, 1000);
    } catch (error) {
      console.error("Failed to change password:", error);
      setIsChangingPassword(false);
      alert("Failed to change password. Please check your current password.");
    }
  };

  // Notification handlers
  const handleNotificationToggle = async (key: keyof NotificationSettings) => {
    const newSettings = {
      ...notifications,
      [key]: !notifications[key],
    };
    setNotifications(newSettings);

    try {
      // TODO: Call API to save notification preferences to database
      // await fetch('/api/users/update-notifications', {
      //   method: 'PATCH',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(newSettings),
      // });
      
      console.log("TODO: Save notifications to database", newSettings);
    } catch (error) {
      console.error("Failed to update notifications:", error);
    }
  };

  // Logout handler
  const handleLogout = async () => {
    if (window.confirm("Are you sure you want to logout?")) {
      try {
        // TODO: Call Better Auth logout endpoint
        // await fetch('/api/auth/sign-out', { method: 'POST' });
        // window.location.href = '/login';
        
        console.log("TODO: Logout via /api/auth/sign-out and redirect to /login");
        alert("Logout functionality - will redirect to /login");
      } catch (error) {
        console.error("Failed to logout:", error);
      }
    }
  };

  if (isLoading) {
    return (
      <div className="mx-auto max-w-4xl">
        <div className="flex items-center justify-center py-12">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-amber-500/20 border-t-amber-500 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-white/40">Loading settings...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="mx-auto max-w-4xl">
        <div className="text-center py-12">
          <p className="text-white/40">Failed to load user data. Please refresh.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold tracking-tight text-white mb-2">
          Settings
        </h1>
        <p className="text-white/40">Manage your account and preferences</p>
      </motion.div>

      {/* Profile Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.5 }}
        className="rounded-2xl p-6 bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/[0.06]"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-white">Profile</h2>
          {!isEditingProfile && (
            <button
              onClick={handleProfileEdit}
              className="px-4 py-2 rounded-xl text-sm font-medium text-amber-400 hover:bg-amber-500/10 transition-all"
            >
              Edit
            </button>
          )}
        </div>

        <div className="space-y-4">
          {/* Name */}
          <div>
            <label className="block text-sm font-medium text-white/40 mb-2">
              Full Name
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileData.name}
                onChange={(e) =>
                  setProfileData({ ...profileData, name: e.target.value })
                }
                className={`w-full px-4 py-3 rounded-xl bg-white/[0.02] border ${
                  profileErrors.name ? "border-red-500/50" : "border-white/[0.06]"
                } text-white placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors`}
              />
            ) : (
              <p className="text-white">{user.name}</p>
            )}
            {profileErrors.name && (
              <p className="text-xs text-red-400 mt-1">{profileErrors.name}</p>
            )}
          </div>

          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-white/40 mb-2">
              Email Address
            </label>
            <div className="flex items-center justify-between">
              <p className="text-white">{user.email}</p>
              {user.email_verified ? (
                <span className="px-3 py-1 rounded-full text-xs font-semibold bg-green-500/20 text-green-400 border border-green-500/30">
                  ✓ Verified
                </span>
              ) : (
                <button
                  onClick={handleSendVerification}
                  disabled={isVerifyingEmail || verificationSent}
                  className="px-4 py-2 rounded-xl text-sm font-medium bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 transition-all disabled:opacity-50"
                >
                  {isVerifyingEmail
                    ? "Sending..."
                    : verificationSent
                      ? "Sent!"
                      : "Verify Email"}
                </button>
              )}
            </div>
            {!user.email_verified && (
              <p className="text-xs text-amber-400 mt-1">
                Please verify your email to enable all features
              </p>
            )}
          </div>

          {/* Phone */}
          <div>
            <label className="block text-sm font-medium text-white/40 mb-2">
              Phone Number (Optional)
            </label>
            {isEditingProfile ? (
              <input
                type="tel"
                value={profileData.phone}
                onChange={(e) =>
                  setProfileData({ ...profileData, phone: e.target.value })
                }
                placeholder="+91 98765 43210"
                className={`w-full px-4 py-3 rounded-xl bg-white/[0.02] border ${
                  profileErrors.phone ? "border-red-500/50" : "border-white/[0.06]"
                } text-white placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors`}
              />
            ) : (
              <p className="text-white">{user.phone || "Not provided"}</p>
            )}
            {profileErrors.phone && (
              <p className="text-xs text-red-400 mt-1">{profileErrors.phone}</p>
            )}
          </div>

          {/* Edit Actions */}
          {isEditingProfile && (
            <div className="flex gap-3 pt-4">
              <button
                onClick={handleProfileCancel}
                className="flex-1 px-4 py-3 rounded-xl text-sm font-semibold text-white/70 hover:bg-white/[0.04] transition-all"
              >
                Cancel
              </button>
              <button
                onClick={handleProfileSave}
                className="flex-1 px-4 py-3 rounded-xl text-sm font-semibold bg-gradient-to-r from-amber-500 to-amber-600 text-white hover:from-amber-600 hover:to-amber-700 transition-all"
              >
                Save Changes
              </button>
            </div>
          )}
        </div>
      </motion.div>

      {/* Password Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.5 }}
        className="rounded-2xl p-6 bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/[0.06]"
      >
        <h2 className="text-xl font-bold text-white mb-6">Change Password</h2>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-white/40 mb-2">
              Current Password
            </label>
            <input
              type="password"
              value={passwordData.currentPassword}
              onChange={(e) =>
                setPasswordData({ ...passwordData, currentPassword: e.target.value })
              }
              className={`w-full px-4 py-3 rounded-xl bg-white/[0.02] border ${
                passwordErrors.currentPassword
                  ? "border-red-500/50"
                  : "border-white/[0.06]"
              } text-white placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors`}
            />
            {passwordErrors.currentPassword && (
              <p className="text-xs text-red-400 mt-1">
                {passwordErrors.currentPassword}
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-white/40 mb-2">
              New Password
            </label>
            <input
              type="password"
              value={passwordData.newPassword}
              onChange={(e) =>
                setPasswordData({ ...passwordData, newPassword: e.target.value })
              }
              className={`w-full px-4 py-3 rounded-xl bg-white/[0.02] border ${
                passwordErrors.newPassword
                  ? "border-red-500/50"
                  : "border-white/[0.06]"
              } text-white placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors`}
            />
            {passwordErrors.newPassword && (
              <p className="text-xs text-red-400 mt-1">
                {passwordErrors.newPassword}
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-white/40 mb-2">
              Confirm New Password
            </label>
            <input
              type="password"
              value={passwordData.confirmPassword}
              onChange={(e) =>
                setPasswordData({ ...passwordData, confirmPassword: e.target.value })
              }
              className={`w-full px-4 py-3 rounded-xl bg-white/[0.02] border ${
                passwordErrors.confirmPassword
                  ? "border-red-500/50"
                  : "border-white/[0.06]"
              } text-white placeholder:text-white/30 focus:border-amber-500/30 focus:outline-none transition-colors`}
            />
            {passwordErrors.confirmPassword && (
              <p className="text-xs text-red-400 mt-1">
                {passwordErrors.confirmPassword}
              </p>
            )}
          </div>

          <button
            onClick={handlePasswordChange}
            disabled={isChangingPassword}
            className="w-full px-4 py-3 rounded-xl text-sm font-semibold bg-white/[0.04] text-white hover:bg-white/[0.08] transition-all disabled:opacity-50"
          >
            {isChangingPassword ? "Changing Password..." : "Change Password"}
          </button>
        </div>
      </motion.div>

      {/* Notification Preferences */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.5 }}
        className="rounded-2xl p-6 bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/[0.06]"
      >
        <h2 className="text-xl font-bold text-white mb-6">Notifications</h2>

        <div className="space-y-4">
          <label className="flex items-center justify-between p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] cursor-pointer hover:bg-white/[0.04] transition-all">
            <div>
              <p className="text-sm font-medium text-white">Email Notifications</p>
              <p className="text-xs text-white/40">Receive updates via email</p>
            </div>
            <input
              type="checkbox"
              checked={notifications.emailNotifications}
              onChange={() => handleNotificationToggle("emailNotifications")}
              className="w-5 h-5 rounded bg-white/[0.06] border-white/[0.10] text-amber-500 focus:ring-2 focus:ring-amber-500/50"
            />
          </label>

          <label className="flex items-center justify-between p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] cursor-pointer hover:bg-white/[0.04] transition-all">
            <div>
              <p className="text-sm font-medium text-white">SMS Notifications</p>
              <p className="text-xs text-white/40">Receive updates via SMS</p>
            </div>
            <input
              type="checkbox"
              checked={notifications.smsNotifications}
              onChange={() => handleNotificationToggle("smsNotifications")}
              className="w-5 h-5 rounded bg-white/[0.06] border-white/[0.10] text-amber-500 focus:ring-2 focus:ring-amber-500/50"
            />
          </label>

          <label className="flex items-center justify-between p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] cursor-pointer hover:bg-white/[0.04] transition-all">
            <div>
              <p className="text-sm font-medium text-white">Push Notifications</p>
              <p className="text-xs text-white/40">Receive push notifications</p>
            </div>
            <input
              type="checkbox"
              checked={notifications.pushNotifications}
              onChange={() => handleNotificationToggle("pushNotifications")}
              className="w-5 h-5 rounded bg-white/[0.06] border-white/[0.10] text-amber-500 focus:ring-2 focus:ring-amber-500/50"
            />
          </label>

          <div className="border-t border-white/[0.06] pt-4 mt-4">
            <p className="text-sm font-medium text-white/60 mb-3">
              Notification Types
            </p>

            <label className="flex items-center justify-between p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] cursor-pointer hover:bg-white/[0.04] transition-all mb-3">
              <div>
                <p className="text-sm font-medium text-white">Booking Reminders</p>
                <p className="text-xs text-white/40">
                  Reminders for upcoming service bookings
                </p>
              </div>
              <input
                type="checkbox"
                checked={notifications.bookingReminders}
                onChange={() => handleNotificationToggle("bookingReminders")}
                className="w-5 h-5 rounded bg-white/[0.06] border-white/[0.10] text-amber-500 focus:ring-2 focus:ring-amber-500/50"
              />
            </label>

            <label className="flex items-center justify-between p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] cursor-pointer hover:bg-white/[0.04] transition-all mb-3">
              <div>
                <p className="text-sm font-medium text-white">Report Ready</p>
                <p className="text-xs text-white/40">
                  When your home health report is ready
                </p>
              </div>
              <input
                type="checkbox"
                checked={notifications.reportReady}
                onChange={() => handleNotificationToggle("reportReady")}
                className="w-5 h-5 rounded bg-white/[0.06] border-white/[0.10] text-amber-500 focus:ring-2 focus:ring-amber-500/50"
              />
            </label>

            <label className="flex items-center justify-between p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] cursor-pointer hover:bg-white/[0.04] transition-all">
              <div>
                <p className="text-sm font-medium text-white">Package Expiry</p>
                <p className="text-xs text-white/40">
                  10 days before subscription expires
                </p>
              </div>
              <input
                type="checkbox"
                checked={notifications.packageExpiry}
                onChange={() => handleNotificationToggle("packageExpiry")}
                className="w-5 h-5 rounded bg-white/[0.06] border-white/[0.10] text-amber-500 focus:ring-2 focus:ring-amber-500/50"
              />
            </label>
          </div>
        </div>
      </motion.div>

      {/* Danger Zone */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.5 }}
        className="rounded-2xl p-6 bg-gradient-to-br from-red-500/10 to-red-600/5 border border-red-500/20"
      >
        <h2 className="text-xl font-bold text-white mb-4">Danger Zone</h2>
        <button
          onClick={handleLogout}
          className="w-full px-4 py-3 rounded-xl text-sm font-semibold bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-all"
        >
          Logout
        </button>
      </motion.div>
    </div>
  );
}