"use client";

import { motion, useScroll, useTransform } from "motion/react";
import { useRef, useState } from "react";
import Link from "next/link";

const SERVICES = [
  { num: "01", title: "Electrical", tag: "Safety audit" },
  { num: "02", title: "Plumbing", tag: "Leak detection" },
  { num: "03", title: "HVAC", tag: "Climate systems" },
  { num: "04", title: "Structural", tag: "Foundation check" },
  { num: "05", title: "Pest Control", tag: "Prevention plan" },
  { num: "06", title: "Security", tag: "Access audit" },
];

const PLANS = [
  {
    name: "1 BHK",
    price: "₹17,999",
    freq: "/inspection",
    sqft: "300 – 600 sq ft",
    items: ["All 6 services", "Quarterly AI report", "Email support", "Health score card"],
  },
  {
    name: "2 BHK",
    price: "₹29,999",
    freq: "/inspection",
    sqft: "600 – 1,300 sq ft",
    items: ["All 6 services", "Monthly AI report", "Priority support", "Analytics dashboard", "Trend tracking"],
    hot: true,
  },
  {
    name: "3 BHK",
    price: "₹51,999",
    freq: "/inspection",
    sqft: "1,300 – 2,100 sq ft",
    items: ["All 6 services", "Weekly AI report", "Dedicated manager", "API access", "Room-by-room breakdown"],
  },
];

export default function HomePage() {
  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const titleY = useTransform(scrollYProgress, [0, 1], ["0%", "18%"]);
  const [open, setOpen] = useState(false);

  return (
    <main
      className="bg-[#F5F0E8] text-[#111] overflow-x-hidden"
      style={{ fontFamily: "'Figtree Variable', 'Figtree', sans-serif" }}
    >
      {/* NAV */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 md:px-10 py-4 bg-[#F5F0E8]/90 backdrop-blur-sm border-b border-[#111]/10">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 bg-[#F07020] flex items-center justify-center font-black text-white text-sm">H</div>
          <span className="font-black text-base tracking-tight">HomeBuddy</span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-[#111]/50">
          {["Services", "How It Works", "Pricing"].map((l) => (
            <a key={l} href={`#${l.toLowerCase().replace(/ /g, "-")}`} className="hover:text-[#111] transition-colors">{l}</a>
          ))}
        </div>
        <div className="hidden md:flex items-center gap-3">
          {/* Technician Login button */}
          <Link
            href="/technician/login"
            className="text-sm font-semibold border border-[#111]/20 text-[#111]/60 hover:border-[#F07020] hover:text-[#F07020] px-4 py-2 transition-colors flex items-center gap-1.5"
          >
            <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M9.5 2.5L11.5 4.5L4.5 11.5H2.5V9.5L9.5 2.5Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
              <path d="M8 4L10 6" stroke="currentColor" strokeWidth="1.5"/>
            </svg>
            Technician Login
          </Link>
          <Link href="/login" className="text-sm font-semibold text-[#111]/50 hover:text-[#111] px-4 py-2 transition-colors">Sign In</Link>
          <Link href="/login" className="text-sm font-black bg-[#111] text-[#F5F0E8] px-5 py-2.5 hover:bg-[#F07020] transition-colors">
            Get Started →
          </Link>
        </div>
        <button className="md:hidden flex flex-col gap-1.5" onClick={() => setOpen(!open)}>
          <span className={`block w-6 h-0.5 bg-[#111] transition-all origin-center ${open ? "rotate-45 translate-y-2" : ""}`} />
          <span className={`block w-6 h-0.5 bg-[#111] transition-all ${open ? "opacity-0" : ""}`} />
          <span className={`block w-6 h-0.5 bg-[#111] transition-all origin-center ${open ? "-rotate-45 -translate-y-2" : ""}`} />
        </button>
      </nav>

      {open && (
        <div className="fixed inset-0 z-40 bg-[#F5F0E8] pt-20 px-6 flex flex-col">
          {["Services", "How It Works", "Pricing"].map((l) => (
            <a key={l} href={`#${l.toLowerCase().replace(/ /g, "-")}`} onClick={() => setOpen(false)}
              className="border-b border-[#111]/10 py-5 text-2xl font-black">{l}</a>
          ))}
          <Link href="/technician/login" onClick={() => setOpen(false)}
            className="mt-6 text-center border-2 border-[#F07020] text-[#F07020] font-black py-3.5 text-base flex items-center justify-center gap-2">
            <svg width="14" height="14" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M9.5 2.5L11.5 4.5L4.5 11.5H2.5V9.5L9.5 2.5Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
              <path d="M8 4L10 6" stroke="currentColor" strokeWidth="1.5"/>
            </svg>
            Technician Login
          </Link>
          <Link href="/login" onClick={() => setOpen(false)}
            className="mt-3 text-center bg-[#111] text-[#F5F0E8] font-black py-4 text-lg">Get Started →</Link>
        </div>
      )}

      {/* HERO */}
      <section ref={heroRef} className="relative min-h-screen flex flex-col justify-center px-6 md:px-10 pt-28 pb-20 overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none overflow-hidden">
          <span className="text-[20vw] font-black text-[#111]/[0.04] leading-none whitespace-nowrap">HOME</span>
        </div>
        <div className="absolute top-0 right-0 w-1 h-full bg-[#F07020] hidden md:block" />

        <motion.div style={{ y: titleY }} className="relative max-w-6xl mx-auto w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 border border-[#F07020] px-3 py-1 mb-8"
          >
            <span className="w-2 h-2 bg-[#F07020] rounded-full animate-pulse" />
            <span className="text-xs font-bold tracking-widest text-[#F07020] uppercase">AI-Powered Home Health</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.1 }}
            className="text-[13vw] md:text-[9vw] font-black leading-[0.88] tracking-tighter mb-8 uppercase"
          >
            Know Your<br />
            <span className="text-[#F07020]">Home.</span><br />
            Fix It.
          </motion.h1>

          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.25 }}
            className="flex flex-col md:flex-row items-start md:items-end gap-8 md:gap-16"
          >
            <p className="text-base md:text-lg text-[#111]/50 max-w-md leading-relaxed font-medium">
              Book professional home inspections, track 12+ services, and get AI-generated health reports every 3 months — automatically.
            </p>
            <div className="flex items-center gap-4">
              <Link href="/login"
                className="font-black text-sm bg-[#F07020] text-white px-8 py-4 hover:bg-[#111] transition-colors uppercase tracking-wide">
                Start Free →
              </Link>
              <a href="#how-it-works" className="text-sm font-semibold text-[#111]/50 hover:text-[#111] transition-colors underline underline-offset-4">
                See how
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6, delay: 0.5 }}
            className="mt-16 md:mt-24 flex gap-12 border-t border-[#111]/15 pt-8"
          >
            {[["2,400+", "Homes Served"], ["98%", "Satisfaction Rate"], ["12+", "Service Types"], ["3mo", "Report Cycle"]].map(([v, l]) => (
              <div key={l} className="hidden md:block first:block">
                <div className="text-2xl md:text-3xl font-black">{v}</div>
                <div className="text-xs text-[#111]/40 font-medium mt-0.5 uppercase tracking-wider">{l}</div>
              </div>
            ))}
          </motion.div>
        </motion.div>
      </section>

      {/* TICKER */}
      <div className="bg-[#F07020] py-3 overflow-hidden border-y border-[#111]/10">
        <motion.div
          animate={{ x: ["0%", "-50%"] }}
          transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
          className="flex gap-0 whitespace-nowrap"
        >
          {Array.from({ length: 8 }).map((_, i) => (
            <span key={i} className="text-white font-black text-sm uppercase tracking-widest px-8">
              Electrical · Plumbing · HVAC · Structural · Pest Control · Security · Waterproofing · Painting ·&nbsp;
            </span>
          ))}
        </motion.div>
      </div>

      {/* SERVICES */}
      <section id="services" className="px-6 md:px-10 py-24 md:py-36 max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 gap-6">
          <h2 className="text-5xl md:text-7xl font-black uppercase leading-none tracking-tighter">
            What<br />We Fix
          </h2>
          <p className="text-[#111]/50 text-sm font-medium max-w-xs leading-relaxed">
            Every corner of your home, inspected by certified professionals and tracked in your dashboard.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 border border-[#111]/10">
          {SERVICES.map((s, i) => (
            <motion.div
              key={s.num}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.07 }}
              className="group p-8 border-b border-r border-[#111]/10 hover:bg-[#F07020] transition-colors duration-200 cursor-pointer"
            >
              <div className="text-xs font-black text-[#111]/30 group-hover:text-white/60 mb-6 uppercase tracking-widest transition-colors">{s.num}</div>
              <div className="text-2xl font-black mb-2 group-hover:text-white transition-colors">{s.title}</div>
              <div className="text-sm text-[#111]/50 group-hover:text-white/70 font-medium transition-colors">{s.tag}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how-it-works" className="bg-[#111] text-[#F5F0E8] px-6 md:px-10 py-24 md:py-36">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-5xl md:text-7xl font-black uppercase leading-none tracking-tighter mb-16">
            3 Steps.<br />
            <span className="text-[#F07020]">That's It.</span>
          </h2>
          <div className="grid md:grid-cols-3 gap-px bg-[#F5F0E8]/10">
            {[
              { n: "01", t: "Book", d: "Choose from 12+ services. Pick a date that works for you. Done in 60 seconds." },
              { n: "02", t: "Inspect", d: "A certified professional visits your home and runs a full diagnostic." },
              { n: "03", t: "Report", d: "Every 3 months, our AI compiles all data into your Home Health Report." },
            ].map((step, i) => (
              <motion.div
                key={step.n}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.12 }}
                className="bg-[#111] p-10 relative group overflow-hidden"
              >
                <div className="absolute -bottom-4 -right-2 text-8xl font-black text-white/[0.03] group-hover:text-[#F07020]/10 transition-colors select-none">
                  {step.n}
                </div>
                <div className="text-[#F07020] font-black text-sm uppercase tracking-widest mb-6">{step.n}</div>
                <div className="text-3xl font-black mb-4 uppercase">{step.t}</div>
                <p className="text-[#F5F0E8]/50 text-sm leading-relaxed font-medium">{step.d}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* REPORT */}
      <section className="px-6 md:px-10 py-24 md:py-36 max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 md:gap-20 items-center">
          <motion.div initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.7 }}>
            <div className="text-xs font-black text-[#F07020] uppercase tracking-widest mb-4">AI Reports</div>
            <h2 className="text-5xl md:text-6xl font-black uppercase leading-none tracking-tighter mb-6">
              Your Home's<br />Score Card
            </h2>
            <p className="text-[#111]/50 text-base leading-relaxed font-medium mb-8 max-w-sm">
              Every quarter, our AI analyses all your service data and gives you a score — with risk flags, priority repairs, and a 12-month trend.
            </p>
            <ul className="space-y-2">
              {["Room-by-room breakdown", "Risk score 0 – 100", "Priority repair list", "Historical trend tracking"].map((f) => (
                <li key={f} className="flex items-center gap-3 text-sm font-semibold text-[#111]/60">
                  <span className="w-4 h-4 bg-[#F07020] flex-shrink-0" />
                  {f}
                </li>
              ))}
            </ul>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.7, delay: 0.15 }}
            className="border-2 border-[#111] p-8"
          >
            <div className="flex items-start justify-between mb-8 border-b border-[#111]/10 pb-6">
              <div>
                <div className="text-xs font-black uppercase tracking-widest text-[#111]/40 mb-1">Q1 2025</div>
                <div className="text-lg font-black">Sharma Residence</div>
                <div className="text-sm text-[#111]/50 font-medium">Sector 21, Noida</div>
              </div>
              <div className="text-right">
                <div className="text-5xl font-black text-[#F07020]">84</div>
                <div className="text-xs text-[#111]/40 font-bold uppercase tracking-wider">Health Score</div>
              </div>
            </div>
            <div className="space-y-5">
              {[
                { l: "Electrical", v: 92, c: "bg-[#111]" },
                { l: "Plumbing", v: 78, c: "bg-[#F0C040]" },
                { l: "HVAC", v: 85, c: "bg-[#111]" },
                { l: "Structural", v: 71, c: "bg-[#F07020]" },
              ].map((item) => (
                <div key={item.l}>
                  <div className="flex justify-between text-sm font-bold mb-2">
                    <span>{item.l}</span><span>{item.v}</span>
                  </div>
                  <div className="h-1 bg-[#111]/10">
                    <motion.div
                      initial={{ width: 0 }} whileInView={{ width: `${item.v}%` }} viewport={{ once: true }}
                      transition={{ duration: 1, ease: "easeOut" }}
                      className={`h-full ${item.c}`}
                    />
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 pt-6 border-t border-[#111]/10">
              <div className="text-xs font-black uppercase tracking-widest text-[#111]/40 mb-2">AI Recommendation</div>
              <p className="text-sm text-[#111]/60 font-medium leading-relaxed">
                Schedule structural inspection within 30 days. Minor cracks detected near east wall.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" className="px-6 md:px-10 py-24 md:py-36 bg-[#EDEAE0]">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
            <h2 className="text-5xl md:text-7xl font-black uppercase leading-none tracking-tighter">
              Simple<br />Pricing
            </h2>
            <p className="text-[#111]/50 text-sm font-medium max-w-xs leading-relaxed">
              One-time inspection price based on your home size. No hidden charges.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            {PLANS.map((plan, i) => (
              <motion.div key={plan.name} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className={`p-8 border-2 relative ${plan.hot ? "bg-[#111] border-[#111] text-[#F5F0E8]" : "border-[#111]/20 bg-transparent hover:border-[#111] transition-colors"}`}
              >
                {plan.hot && (
                  <div className="absolute -top-3 left-8 bg-[#F07020] text-white text-xs font-black px-3 py-0.5 uppercase tracking-widest">Popular</div>
                )}
                <div className={`text-xs font-black uppercase tracking-widest mb-1 ${plan.hot ? "text-[#F07020]" : "text-[#111]/40"}`}>{plan.name}</div>
                {/* sqft badge */}
                <div className={`text-[11px] font-bold mb-6 ${plan.hot ? "text-[#F5F0E8]/40" : "text-[#111]/30"}`}>{plan.sqft}</div>
                <div className="flex items-end gap-1 mb-8">
                  <span className="text-4xl font-black">{plan.price}</span>
                  <span className={`text-xs font-medium mb-1.5 ${plan.hot ? "text-[#F5F0E8]/50" : "text-[#111]/40"}`}>{plan.freq}</span>
                </div>
                <ul className="space-y-3 mb-8">
                  {plan.items.map((item) => (
                    <li key={item} className={`flex items-center gap-3 text-sm font-semibold ${plan.hot ? "text-[#F5F0E8]/70" : "text-[#111]/60"}`}>
                      <span className={`w-3 h-3 flex-shrink-0 ${plan.hot ? "bg-[#F07020]" : "bg-[#111]/30"}`} />
                      {item}
                    </li>
                  ))}
                </ul>
                <Link href="/login"
                  className={`block text-center py-3.5 font-black text-sm uppercase tracking-wider transition-colors ${
                    plan.hot ? "bg-[#F07020] text-white hover:bg-white hover:text-[#111]" : "bg-[#111] text-[#F5F0E8] hover:bg-[#F07020]"
                  }`}
                >
                  Get Started →
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-[#F07020] px-6 md:px-10 py-24 md:py-32 text-white overflow-hidden relative">
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none overflow-hidden">
          <span className="text-[22vw] font-black text-white/[0.06] leading-none whitespace-nowrap">BUDDY</span>
        </div>
        <div className="relative max-w-6xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-10">
          <h2 className="text-5xl md:text-7xl font-black uppercase leading-none tracking-tighter">
            Ready to<br />Know Your<br />Home?
          </h2>
          <div className="flex flex-col gap-4">
            <p className="text-white/70 font-medium max-w-xs">Join 2,400+ homeowners. No credit card required. Cancel anytime.</p>
            <Link href="/login"
              className="inline-block bg-white text-[#F07020] font-black text-base uppercase tracking-widest px-10 py-4 hover:bg-[#111] hover:text-white transition-colors w-fit">
              Start Free →
            </Link>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#111] text-[#F5F0E8] px-6 md:px-10 py-10 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 bg-[#F07020] flex items-center justify-center font-black text-white text-xs">H</div>
          <span className="font-black text-sm">HomeBuddy</span>
        </div>
        <p className="text-[#F5F0E8]/30 text-xs font-medium">© 2025 HomeBuddy. All rights reserved.</p>
        <div className="flex gap-6">
          {["Privacy", "Terms", "Contact"].map((l) => (
            <a key={l} href="#" className="text-xs font-semibold text-[#F5F0E8]/40 hover:text-[#F07020] transition-colors">{l}</a>
          ))}
        </div>
      </footer>
    </main>
  );
}