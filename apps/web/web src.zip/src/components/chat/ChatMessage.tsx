// apps/web/src/components/chat/ChatMessage.tsx
'use client';

import { motion } from 'framer-motion';
import { User, Sparkle } from '@phosphor-icons/react';
import type { ChatMessage as ChatMessageType } from '@/lib/stores/useChatStore';

interface ChatMessageProps {
  message: ChatMessageType;
}

export function ChatMessage({ message }: ChatMessageProps) {
  const isUser = message.role === 'user';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`flex gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
    >
      {/* Avatar */}
      <div
        className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
          isUser
            ? 'bg-gradient-to-br from-amber-500 to-orange-600'
            : 'bg-gradient-to-br from-purple-500 to-indigo-600'
        }`}
      >
        {isUser ? (
          <User className="w-4 h-4 text-white" weight="bold" />
        ) : (
          <Sparkle className="w-4 h-4 text-white" weight="fill" />
        )}
      </div>

      {/* Message Bubble */}
      <div
        className={`max-w-[75%] rounded-2xl px-4 py-3 ${
          isUser
            ? 'bg-gradient-to-br from-amber-500/20 to-orange-600/20 border border-amber-500/30'
            : 'bg-white/10 backdrop-blur-xl border border-white/20'
        }`}
      >
        <p className="text-sm text-white/90 leading-relaxed whitespace-pre-wrap">
          {message.content}
        </p>
        <p className="text-xs text-white/40 mt-1">
          {new Date(message.timestamp).toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
          })}
        </p>
      </div>
    </motion.div>
  );
}