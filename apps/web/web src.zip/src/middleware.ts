import { NextRequest, NextResponse } from "next/server";

// ═══════════════════════════════════════════════════════════════════════════
// ROUTE PROTECTION MIDDLEWARE
// Runs on every request matching the matcher below.
// Reads the Better Auth session cookie and either:
//   - redirects unauthenticated users to the appropriate login page
//   - fetches the session from the API and checks the role matches the route
//
// NOTE ON SECURITY: The middleware is a UX convenience. The real gate is on
// the Nest API (AuthGuard + RolesGuard). Never trust this alone — a user
// could craft cookies or hit the API directly. Backend guards are what stop
// actual data exfiltration.
// ═══════════════════════════════════════════════════════════════════════════

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:3000";

// Route groups → required role
// Note: login/register pages are NOT in here; they're public.
const PROTECTED_ROUTES: { prefix: string; role: "customer" | "technician" | "admin"; loginPath: string }[] = [
  { prefix: "/dashboard",             role: "customer",   loginPath: "/login" },
  { prefix: "/technician/dashboard",  role: "technician", loginPath: "/technician/login" },
  { prefix: "/technician/schedule",   role: "technician", loginPath: "/technician/login" },
  { prefix: "/technician/requests",   role: "technician", loginPath: "/technician/login" },
  { prefix: "/technician/ekyc",       role: "technician", loginPath: "/technician/login" },
  { prefix: "/technician/reports",    role: "technician", loginPath: "/technician/login" },
  { prefix: "/technician/settings",   role: "technician", loginPath: "/technician/login" },
  { prefix: "/technician/completed",  role: "technician", loginPath: "/technician/login" },
  { prefix: "/admin",                 role: "admin",      loginPath: "/admin/login" },
];

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Skip public routes explicitly
  if (pathname === "/admin/login") return NextResponse.next();

  const matched = PROTECTED_ROUTES.find((r) => pathname.startsWith(r.prefix));
  if (!matched) return NextResponse.next();

  // Cheap existence check first — if no session cookie at all, redirect
  // without bothering the API. Better Auth default cookie name:
  //   better-auth.session_token
  const hasCookie = req.cookies
    .getAll()
    .some((c) => c.name.includes("session_token") || c.name.includes("better-auth"));

  if (!hasCookie) {
    return NextResponse.redirect(new URL(matched.loginPath, req.url));
  }

  // Fetch session from API to get the role.
  // We forward the cookie header so Better Auth can validate the session.
  try {
    const res = await fetch(`${API_URL}/api/auth/get-session`, {
      headers: { cookie: req.headers.get("cookie") ?? "" },
      cache: "no-store",
    });

    if (!res.ok) {
      return NextResponse.redirect(new URL(matched.loginPath, req.url));
    }

    const session = (await res.json()) as { user?: { role?: string } } | null;
    const role = session?.user?.role;

    if (!role) {
      return NextResponse.redirect(new URL(matched.loginPath, req.url));
    }

    if (role !== matched.role) {
      // Logged in, but as the wrong role. Send them to their own home.
      const home =
        role === "admin" ? "/admin/dashboard" :
        role === "technician" ? "/technician/dashboard" :
        "/dashboard";
      return NextResponse.redirect(new URL(home, req.url));
    }

    return NextResponse.next();
  } catch {
    // API unreachable — fail closed, send to login.
    return NextResponse.redirect(new URL(matched.loginPath, req.url));
  }
}

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/technician/:path*",
    "/admin/:path*",
  ],
};