import { initQueryClient } from "@ts-rest/react-query";
import { contract } from "@homebuddy-12/api";

export const api = initQueryClient(contract, {
  baseUrl: process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:3000",
  baseHeaders: {},
  credentials: "include",
});