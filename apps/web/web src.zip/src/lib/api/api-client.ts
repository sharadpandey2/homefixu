import type {
  DashboardData,
  ApiResponse,
  Booking,
  ServiceDue,
  Activity,
  Notification,
  SOSRequest,
} from "./types";

// Base API URL - adjust based on your environment
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001/api";

class ApiClient {
  private async fetch<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers: {
          "Content-Type": "application/json",
          ...options.headers,
        },
        credentials: "include", // Include cookies for session
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: data.message || "An error occurred",
        };
      }

      return {
        success: true,
        data: data.data || data,
      };
    } catch (error) {
      console.error("API Error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Network error",
      };
    }
  }

  // Dashboard
  async getDashboardData(): Promise<ApiResponse<DashboardData>> {
    return this.fetch<DashboardData>("/dashboard");
  }

  // Bookings
  async getUpcomingBookings(limit: number = 5): Promise<ApiResponse<Booking[]>> {
    return this.fetch<Booking[]>(`/bookings/upcoming?limit=${limit}`);
  }

  async getBookingById(id: string): Promise<ApiResponse<Booking>> {
    return this.fetch<Booking>(`/bookings/${id}`);
  }

  async createBooking(data: {
    serviceId: string;
    scheduledAt: string;
    notes?: string;
  }): Promise<ApiResponse<Booking>> {
    return this.fetch<Booking>("/bookings", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async cancelBooking(id: string): Promise<ApiResponse<void>> {
    return this.fetch<void>(`/bookings/${id}/cancel`, {
      method: "POST",
    });
  }

  async rescheduleBooking(
    id: string,
    scheduledAt: string
  ): Promise<ApiResponse<Booking>> {
    return this.fetch<Booking>(`/bookings/${id}/reschedule`, {
      method: "POST",
      body: JSON.stringify({ scheduledAt }),
    });
  }

  // Service Dues
  async getServiceDues(): Promise<ApiResponse<ServiceDue[]>> {
    return this.fetch<ServiceDue[]>("/services/dues");
  }

  async scheduleServiceDue(dueId: string): Promise<ApiResponse<Booking>> {
    return this.fetch<Booking>(`/services/dues/${dueId}/schedule`, {
      method: "POST",
    });
  }

  // Activity
  async getRecentActivity(limit: number = 10): Promise<ApiResponse<Activity[]>> {
    return this.fetch<Activity[]>(`/activity?limit=${limit}`);
  }

  // Notifications
  async getNotifications(
    unreadOnly: boolean = false
  ): Promise<ApiResponse<Notification[]>> {
    return this.fetch<Notification[]>(
      `/notifications?unreadOnly=${unreadOnly}`
    );
  }

  async markNotificationAsRead(id: string): Promise<ApiResponse<void>> {
    return this.fetch<void>(`/notifications/${id}/read`, {
      method: "POST",
    });
  }

  async markAllNotificationsAsRead(): Promise<ApiResponse<void>> {
    return this.fetch<void>("/notifications/read-all", {
      method: "POST",
    });
  }

  // SOS
  async createSOS(data: {
    type: string;
    description: string;
    location?: string;
  }): Promise<ApiResponse<SOSRequest>> {
    return this.fetch<SOSRequest>("/sos", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async getActiveSOSRequests(): Promise<ApiResponse<SOSRequest[]>> {
    return this.fetch<SOSRequest[]>("/sos/active");
  }

  async cancelSOS(id: string): Promise<ApiResponse<void>> {
    return this.fetch<void>(`/sos/${id}/cancel`, {
      method: "POST",
    });
  }

  // Health Score
  async getHealthScore(): Promise<ApiResponse<any>> {
    return this.fetch<any>("/health/score");
  }

  async refreshHealthScore(): Promise<ApiResponse<any>> {
    return this.fetch<any>("/health/score/refresh", {
      method: "POST",
    });
  }

  // Services
  async getAvailableServices(): Promise<ApiResponse<any[]>> {
    return this.fetch<any[]>("/services");
  }

  async getServiceById(id: string): Promise<ApiResponse<any>> {
    return this.fetch<any>(`/services/${id}`);
  }

  // Payments
  async getPaymentHistory(): Promise<ApiResponse<any[]>> {
    return this.fetch<any[]>("/payments/history");
  }

  async createPaymentOrder(data: {
    bookingId: string;
    amount: number;
  }): Promise<ApiResponse<any>> {
    return this.fetch<any>("/payments/create-order", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async verifyPayment(data: {
    orderId: string;
    paymentId: string;
    signature: string;
  }): Promise<ApiResponse<any>> {
    return this.fetch<any>("/payments/verify", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }
}

// Export singleton instance
export const apiClient = new ApiClient();

// Export class for testing
export default ApiClient;