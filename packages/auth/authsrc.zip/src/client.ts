import { createAuthClient } from "better-auth/react";
import { adminClient } from "better-auth/client/plugins";

// Better Auth's inferred client type references non-exported internal types
// (InferSignUpEmailCtx, InferUserUpdateCtx) which trips TS2883 under
// declaration emit. We annotate as `any` to opt out of inference — runtime
// behavior is unaffected. Consumers still get runtime typing at call sites.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const authClient: any = createAuthClient({
  baseURL: process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:3000",
  plugins: [adminClient()],
});

export const signIn = authClient.signIn;
export const signUp = authClient.signUp;
export const signOut = authClient.signOut;
export const useSession = authClient.useSession;
export const getSession = authClient.getSession;
export const admin = authClient.admin;