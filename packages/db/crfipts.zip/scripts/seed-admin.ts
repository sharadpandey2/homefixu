// ═══════════════════════════════════════════════════════════════════════════
// SEED ADMIN USER — standalone script (no workspace imports needed)
// Usage: pnpm tsx packages/db/scripts/seed-admin.ts
//
// Reads: SEED_ADMIN_EMAIL, SEED_ADMIN_PASSWORD, SEED_ADMIN_NAME, DATABASE_URL
// ═══════════════════════════════════════════════════════════════════════════

import { scrypt, randomBytes } from "crypto";
import { neon } from "@neondatabase/serverless";

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("❌ DATABASE_URL is not set");
  process.exit(1);
}

const email = process.env.SEED_ADMIN_EMAIL ?? "admin@homebuddy.local";
const password = process.env.SEED_ADMIN_PASSWORD ?? "ChangeMe123!";
const name = process.env.SEED_ADMIN_NAME ?? "Admin";

// Better Auth uses scrypt for password hashing (not bcrypt).
// This matches their internal implementation so the password works with signIn.
async function hashPassword(pwd: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const salt = randomBytes(16).toString("hex");
    scrypt(pwd, salt, 64, (err, derived) => {
      if (err) reject(err);
      else resolve(`${salt}:${derived.toString("hex")}`);
    });
  });
}

function generateId(): string {
  return randomBytes(16).toString("hex");
}

async function main() {
  const sql = neon(DATABASE_URL!);

  console.log(`\n🌱 Seeding admin: ${email}\n`);

  // Check if user already exists
  const existing = await sql`SELECT id, role FROM users WHERE email = ${email} LIMIT 1`;

  if (existing.length > 0) {
    const user = existing[0]!;
    if (user.role === "admin") {
      console.log(`✓ Admin already exists (userId=${user.id}). Nothing to do.`);
      return;
    }
    // Promote existing user
    await sql`UPDATE users SET role = 'admin' WHERE id = ${user.id}`;
    console.log(`✓ Promoted existing user ${user.id} to admin.`);
    return;
  }

  // Create new admin user + credential account
  const userId = generateId();
  const accountId = generateId();
  const hashedPassword = await hashPassword(password);
  const now = new Date();

  await sql`
    INSERT INTO users (id, name, email, role, email_verified, created_at, updated_at)
    VALUES (${userId}, ${name}, ${email}, 'admin', true, ${now}, ${now})
  `;

  await sql`
    INSERT INTO accounts (id, account_id, provider_id, user_id, password, created_at, updated_at)
    VALUES (${accountId}, ${userId}, 'credential', ${userId}, ${hashedPassword}, ${now}, ${now})
  `;

  console.log(`✓ Admin created: ${userId}`);
  console.log(`  Email:    ${email}`);
  console.log(`  Password: ${password}`);
  console.log(`\n⚠️  Change this password after first login.\n`);
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("❌ Seed failed:", err);
    process.exit(1);
  });